package com.atnt.framework.utility;

import java.io.IOException;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class WebServiceUtil {
	
	public static String executeHttp(String targetURL, String port ) throws IOException {	
		CloseableHttpClient httpclient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
        try {
            HttpHost target = new HttpHost(targetURL, Integer.parseInt(port), "https");
            HttpHost proxy = new HttpHost("127.0.0.1", 8080, "http");

            RequestConfig config = RequestConfig.custom()
                    .setProxy(proxy)
                    .build();
            HttpGet request = new HttpGet("/");
            request.setConfig(config);

            System.out.println("Executing request " + request.getRequestLine() + " to " + target + " via " + proxy);

            response = httpclient.execute(target, request);
            try {
                System.out.println("----------------------------------------");
                System.out.println(response.getStatusLine());
                EntityUtils.consume(response.getEntity());
            } finally {
                response.close();
            }
        } finally {
            httpclient.close();
        }
		return EntityUtils.toString(response.getEntity());
	}	
	
	
	public static void main(String[] args){
		
		
	}
}