package com.atnt.framework.exception;

public class InValidOSException extends Exception {

	private static final long serialVersionUID = 1L;

	public InValidOSException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InValidOSException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
}
