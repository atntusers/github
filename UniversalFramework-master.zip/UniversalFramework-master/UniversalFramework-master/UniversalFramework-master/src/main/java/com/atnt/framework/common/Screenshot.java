package com.atnt.framework.common;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Calendar;

import jxl.write.WritableSheet;
import jxl.write.WriteException;

import com.atnt.framework.dto.handler.*;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter;
import org.testng.annotations.Test;

public class Screenshot extends TestListenerAdapter {
    private final String ESCAPE_PROPERTY = "org.uncommons.reportng.escape-output";

    private volatile static WriteExcel we;

    private volatile static int i = 1;
    private volatile static WritableSheet sheet;

    private String testName = null;
    private String group;

    public Screenshot() {

        we = WriteExcel.getInstance();

        /*
         * String channel =
         * EnvirnomentHandler.getInstance().getEnvirnoment().getChannel();
         * if("android".equalsIgnoreCase(channel)){ driver =
         * appium.getAndroidDriver(); } else
         * if("IOS".equalsIgnoreCase(channel)){ driver = appium.getIOSDriver();
         * } else{ driver = selenium.getDriver(); }
         */

        String filepath = "src/test/resources/Report.xls";
        filepath = System.getProperty("user.dir") + "/" + filepath;
        we.setOutputFile(filepath);
        try {
            sheet = we.getSheet();
        } catch (WriteException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.testng.TestListenerAdapter#onTestFailure(org.testng.ITestResult)
     */
    @Override
    public void onTestFailure(ITestResult tr) {

        synchronized (this) {

            // WebDriver driver = (WebDriver) tr.getAttribute("driver");

            System.out.println("value of testname is   " + testName);
            if (testName != tr.getMethod().getMethodName()) {
                Reporter.log("-Failed-", true);
                Reporter.log("Test method name is:- "
                        + tr.getMethod().getMethodName(), true);
                Reporter.log("Test name is:- "
                        + tr.getMethod().getConstructorOrMethod().getMethod()
                                .getAnnotation(Test.class).testName(), true);
                try {

                    group = Arrays.toString(
                            tr.getMethod().getConstructorOrMethod().getMethod()
                                    .getAnnotation(Test.class).groups())
                            .replace("[", "");
                    group = group.replace("]", "");
                    testName = tr.getMethod().getMethodName();

                    we.createContent(sheet, 1, i, group);
                    we.createContent(sheet, 2, i, tr.getMethod()
                            .getConstructorOrMethod().getMethod()
                            .getAnnotation(Test.class).testName());

                    we.createContent(sheet, 3, i, tr.getMethod()
                            .getConstructorOrMethod().getMethod()
                            .getAnnotation(Test.class).description());

                    we.createContent(sheet, 4, i, "Fail");
                    i++;
                } catch (Exception e) {

                    e.printStackTrace();
                }

                System.out.println("value of testname is in if condition   "
                        + testName);
            }

            System.setProperty(ESCAPE_PROPERTY, "false");
            boolean islocal = EnvirnomentHandler.getInstance().getEnvirnoment()
                    .isLocal();

            if (islocal) {

                WebDriver driver = (WebDriver) tr.getTestContext()
                        .getAttribute("driver");
                /* WebDriver augmentedDriver = new Augmenter().augment(driver); */

                File file = new File("");
                Calendar lCDateTime = Calendar.getInstance();
                String a = lCDateTime.getTimeInMillis() + ".png";
                Reporter.setCurrentTestResult(tr);
                try {
                    System.out.println(file.getCanonicalPath());

                    if (driver != null) {
                        File scrFile = ((TakesScreenshot) driver)
                                .getScreenshotAs(OutputType.FILE);
                        String f = file.getCanonicalPath() + File.separator
                                + "target" + File.separator
                                + "surefire-reports" + File.separator
                                + lCDateTime.getTimeInMillis() + ".png";
                        File dest = new File(f);

                        FileUtils.copyFile(scrFile, dest);
                        // FileUtils.copyFile(scrFile, new File(f));
                        StringBuilder href = new StringBuilder();
                        href.append("<a href=");
                      //  href.append("'.." + File.separator + "surefire-reports");
                        href.append(file.getCanonicalPath() + File.separator
                                + "target" + File.separator + "surefire-reports");
                        href.append(File.separator + a
                                + " target=\"_blank\">ScreenShot_");
                        href.append(tr.getName() + "</a>");
                        System.out
                                .println("-------------------------------------------");

                        Reporter.log(href.toString());

                        Reporter.setCurrentTestResult(null);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.testng.TestListenerAdapter#onTestSkipped(org.testng.ITestResult)
     */
    @Override
    public void onTestSkipped(ITestResult tr) {

        synchronized (this) {

            Reporter.log("-Skipped-", true);
            Reporter.log("Test Method name is:- "
                    + tr.getMethod().getMethodName(), true);
            Reporter.log("Test name is:- "
                    + tr.getMethod().getConstructorOrMethod().getMethod()
                            .getAnnotation(Test.class).testName(), true);
            try {
                String group = Arrays.toString(
                        tr.getMethod().getConstructorOrMethod().getMethod()
                                .getAnnotation(Test.class).groups()).replace(
                        "[", "");
                group = group.replace("]", "");

                we.createContent(sheet, 1, i, group);

                we.createContent(sheet, 2, i,
                        tr.getMethod().getConstructorOrMethod().getMethod()
                                .getAnnotation(Test.class).testName());

                we.createContent(sheet, 3, i,
                        tr.getMethod().getConstructorOrMethod().getMethod()
                                .getAnnotation(Test.class).description());

                we.createContent(sheet, 4, i, "Skip");

                i++;
            } catch (WriteException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            boolean islocal = EnvirnomentHandler.getInstance().getEnvirnoment()
                    .isLocal();

            if (islocal) {
                WebDriver driver = (WebDriver) tr.getTestContext()
                        .getAttribute("driver");

                System.setProperty(ESCAPE_PROPERTY, "false");

                File file = new File("");
                Calendar lCDateTime = Calendar.getInstance();
                String a = lCDateTime.getTimeInMillis() + ".png";
                Reporter.setCurrentTestResult(tr);
                try {
                    System.out.println(file.getCanonicalPath());
                    File scrFile = ((TakesScreenshot) driver)
                            .getScreenshotAs(OutputType.FILE);
                    String f = file.getCanonicalPath() + File.separator
                            + "target" + File.separator + "surefire-reports"
                            + File.separator + lCDateTime.getTimeInMillis()
                            + ".png";
                    File dest = new File(f);

                    Files.copy(scrFile.toPath(), dest.toPath());
                    // FileUtils.copyFile(scrFile, new File(f));
                    StringBuilder href = new StringBuilder();
                    href.append("<a href=");
                  //  href.append("'.." + File.separator + "surefire-reports");
                    href.append(file.getCanonicalPath() + File.separator
                            + "target" + File.separator + "surefire-reports");
                    href.append(File.separator + a
                            + " target=\"_blank\">ScreenShot_");
                    href.append(tr.getName() + "</a>");
                    System.out
                            .println("-------------------------------------------");

                    Reporter.log(href.toString());

                    Reporter.setCurrentTestResult(null);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.testng.TestListenerAdapter#onTestSuccess(org.testng.ITestResult)
     */
    @Override
    public void onTestSuccess(ITestResult tr) {
        synchronized (this) {

            if (testName == tr.getMethod().getMethodName()) {
                i--;
            }
            Reporter.log("-Passed-", true);
            Reporter.log("Test Method name is:- "
                    + tr.getMethod().getMethodName(), true);
            Reporter.log("Test name is:- "
                    + tr.getMethod().getConstructorOrMethod().getMethod()
                            .getAnnotation(Test.class).testName(), true);
            Reporter.log("Test desc is:- "
                    + tr.getMethod().getConstructorOrMethod().getMethod()
                            .getAnnotation(Test.class).description(), true);
            try {
                String group = Arrays.toString(
                        tr.getMethod().getConstructorOrMethod().getMethod()
                                .getAnnotation(Test.class).groups()).replace(
                        "[", "");
                group = group.replace("]", "");
                we.createContent(sheet, 1, i, group);

                we.createContent(sheet, 2, i,
                        tr.getMethod().getConstructorOrMethod().getMethod()
                                .getAnnotation(Test.class).testName());

                we.createContent(sheet, 3, i,
                        tr.getMethod().getConstructorOrMethod().getMethod()
                                .getAnnotation(Test.class).description());

                we.createContent(sheet, 4, i, "Pass");
                i++;
            } catch (WriteException e1) {
                e1.printStackTrace();
            }

        }

    }

    @Override
    public void onStart(ITestContext context) {
        /*
         * System.out.println("----------------------"+context.getSuite().
         * getParameter("platform"));
         * 
         * if("android".equalsIgnoreCase(context.getSuite().getParameter("platform"
         * ))){ driver = appium.getAndroidDriver();
         * 
         * } else
         * if("IOS".equalsIgnoreCase(context.getSuite().getParameter("platform"
         * ))){ driver = appium.getIOSDriver(); } else{ driver =
         * selenium.getDriver(); }
         */
    }

}