package com.atnt.framework.tool;

public class Tools {

	public enum SupportedTools {
		SELENIUM {
			@Override
			public String toString() {
				return "Selenium";
			}
		},
		APPIUM {
			@Override
			public String toString() {
				return "APPIUM";
			}
		}
	}

	SupportedTools cName;

	
	public SupportedTools getcName() {
		return cName;
	}

	public void setcName(SupportedTools cName) {
		this.cName = cName;
	}

	public Tools(SupportedTools cName) {
		this.cName = cName;
	}

	public void toolsDetails() {
		switch (cName) {
		case SELENIUM:
			System.out.println("Web-Selenium Tool.");
			break;

		case APPIUM:
			System.out.println("appium.");
			break;

		default:
			System.out.println("no supported tool");
			break;
		}
	}

	public static void main(String[] args) {
		Tools selenium = new Tools(SupportedTools.SELENIUM);
		selenium.toolsDetails();
		Tools appium = new Tools(SupportedTools.APPIUM);
		appium.toolsDetails();
		System.out.println(appium.getcName().toString());
	}
}