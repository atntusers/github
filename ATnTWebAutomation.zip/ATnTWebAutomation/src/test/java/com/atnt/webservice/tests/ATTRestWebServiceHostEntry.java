package com.atnt.webservice.tests;

import org.apache.log4j.Logger;

import org.testng.Assert;

import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.apache.http.HttpHost;
import org.apache.http.HttpStatus;
import com.atnt.common.ExcelManager;
import com.atnt.webservice.common.WebServiceUtil;

/**
 * 
 * @ Sandeep G
 * 
 * 
 */
public class ATTRestWebServiceHostEntry {
	private static Logger log = Logger
			.getLogger(ATTRestWebServiceHostEntry.class.getName());
	private WebServiceUtil webServiceUtil = new WebServiceUtil();
	private HttpHost proxy;
	private ExcelManager xls = null;

	// new ExcelManager(System.getProperty("user.dir") +
	// "//src//test//resources//WebServiceTestResult.xlsx");
	/**
	 * This method is used to initialize something to proceed with tests
	 * 
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		log.info("Set up Method Set Proxy"
				+ ATTRestWebServiceHostEntry.class.getName());
		proxy = new HttpHost("135.28.13.11", 8080);
		log.info("Initializing log4j");
	}

	@BeforeClass
	public void initiate() throws Exception {
		xls = new ExcelManager(System.getProperty("user.dir")
				+ "//src//test//resources//WebServiceTestResult.xlsx");
		log.info("Initiliating test result fiile");

	}

	/**
	 * Sample Restful webservice
	 * 
	 * @throws Exception
	 */
	@Test
	@Parameters({ "restURL", "fanid", "companyName" })
	public void testSampleRestfulWS(String restURL, String fanid,
			String companyname) throws Exception {

		log.info("insdie weservice 2");
		int responsecode = webServiceUtil.testStatusCode(restURL, proxy);
		System.out.println("HTTP STATUS CODE--->" + responsecode);
		Reporter.log("HTTP STATUS CODE--->" + responsecode);
		Assert.assertEquals(responsecode, HttpStatus.SC_OK);
		xls.createTestResultReport("123", "testSampleRestfulWS", "pass", "250",
				"200");

	}

	@Test
	@Parameters({ "restURL", "fanid", "companyName" })
	public void testSampleRestfulWS1(String restURL, String fanid,
			String companyname) throws Exception {

		// restURL="http://api.openweathermap.org/data/2.5/forecast/city?id=524901&APPID=edffa01a08f5cfad77a2bc912b0486c5";
		log.info("web second");

		int responsecode = webServiceUtil.testStatusCode(restURL, proxy);
		System.out.println("HTTP STATUS CODE--->" + responsecode);
		Reporter.log("HTTP STATUS CODE--->" + responsecode);
		Assert.assertEquals(responsecode, HttpStatus.SC_OK);
		xls.createTestResultReport("testwebasd", "testSampleRestfulWS8",
				"pass", "2500", "200");

	}

	@AfterClass
	public void finalTearDown() throws Exception {

		xls.updateExcelFile(System.getProperty("user.dir")
				+ "//src//test//resources//WebServiceTestResult.xlsx");

	}

	@AfterMethod
	public void tearDown() throws Exception {

		log.info(getClass().getName() + "   tearDown");
	}

}
