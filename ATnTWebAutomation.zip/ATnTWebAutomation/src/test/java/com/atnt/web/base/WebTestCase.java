package com.atnt.web.base;

import jxl.write.WritableWorkbook;

import org.apache.commons.lang3.time.StopWatch;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

import com.atnt.framework.common.SeleniumDriverUtil;
import com.atnt.framework.common.TestSession;
import com.atnt.framework.common.WriteExcel;
import com.atnt.pages.WebPageFactory;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

//
public class WebTestCase {
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	protected WebDriver driver = selenium.getDriver();
	private WritableWorkbook workbook;
	private TestSession session;
	private WebPageFactory pageFactory;
	private StopWatch stopWatch = new StopWatch();

	public WebTestCase() {
		DOMConfigurator.configure("log4j.xml");

		session = new TestSession();
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
	}

	public WebDriver getDriver() {
		// System.out.println("inside getDriver");
		return driver;
	}

	public void setDriver(WebDriver driver) {
		// super.setDriver(driver);
		this.driver = driver;
	}

	public WritableWorkbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(WritableWorkbook workbook) {
		this.workbook = workbook;
	}

	public TestSession getSession() {
		return session;
	}

	public void setSession(TestSession session) {
		this.session = session;
	}

	public WebPageFactory getPageFactory() {

		return pageFactory;
	}

	public void setPageFactory(WebPageFactory pageFactory) {
		this.pageFactory = pageFactory;
	}

	@AfterSuite(alwaysRun = true)
	public void closeBrowser() {
		driver.close();
	}

	@AfterMethod(alwaysRun = true)
	public void closeMenu() {
		// getPageFactory().getHome().closeMenu();
	}

	public StopWatch getStopWatch() {
		return stopWatch;
	}

	public void setStopWatch(StopWatch stopWatch) {
		this.stopWatch = stopWatch;
	}
}