package com.atnt.web.buildbundle.tests;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.atnt.common.Common;
import com.atnt.web.base.WebTestCase;
import com.atnt.framework.common.Retry;
import com.atnt.framework.common.Screenshot;

@Listeners({ Screenshot.class })
public class RegisterTodayTest extends WebTestCase {
	private Common common = new Common(driver);
	private Logger logger = Logger.getLogger(RegisterTodayTest.class.getName());

	private WebDriver driver2 = driver;

	@BeforeClass
	public void initialize(ITestContext testContext) {
		testContext.setAttribute("driver", driver2);

		getDriver().manage().deleteAllCookies();
		common.impicitWait(20);
		getDriver().manage().window().maximize();
		getDriver().get(getSession().getEnv().getUrl());
		getDriver().manage().timeouts().pageLoadTimeout(200, TimeUnit.SECONDS);

	}

	@AfterClass
	public void closeBrowser() {
		
		driver2.close();

	}

	@Test(testName = "checkRegisterToday", description = "verify", timeOut = 4190000, enabled = true, groups = { "sanity", }, retryAnalyzer = Retry.class)
	public void checkRegisterToday() {
		try {

			getPageFactory().getATnTRegisterTodayPage().clickonRegisterToday();
			getPageFactory().getATnTRegisterTodayPage()
					.verifyregistertodayPage();

			getPageFactory().getATnTRegisterTodayPage()
					.selectonAccTypeRegisterToday();
			getPageFactory().getATnTRegisterTodayPage()
					.verifyAccTypeRegisterToday();

			getPageFactory().getATnTRegisterTodayPage().enterAccNumberZip();

			getPageFactory().getATnTRegisterTodayPage().clickNxtonRegister();
			getPageFactory().getATnTRegisterTodayPage().verifyNxtonRegister();
			// Thread.sleep(40000);

		} catch (Exception e) {
			getDriver().get(getSession().getEnv().getUrl());
			Assert.assertTrue(false,
					"test case one failed verifying home page links");
		}
	}
}