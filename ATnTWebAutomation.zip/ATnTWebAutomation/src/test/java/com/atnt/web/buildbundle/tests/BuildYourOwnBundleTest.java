package com.atnt.web.buildbundle.tests;

import java.util.concurrent.TimeUnit;
//import java.util.logging.Logger;
//import org.apache.log4j.Logger;

import org.apache.log4j.Logger;
//import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.atnt.common.Common;
import com.atnt.common.ExcelManager;

import com.atnt.framework.common.Retry;
import com.atnt.framework.common.Screenshot;
import com.atnt.web.base.WebTestCase;

@Listeners({ Screenshot.class })
public class BuildYourOwnBundleTest extends WebTestCase {

	private Common common = new Common(driver);

	private Logger logger = Logger.getLogger(BuildYourOwnBundleTest.class
			.getName());

	private WebDriver driver2 = driver;
	// Test data file path
	private ExcelManager xls = new ExcelManager(System.getProperty("user.dir")
			+ "//src//test//resources//testdata.xlsx");

	@BeforeClass
	public void initialize(ITestContext testContext) {

		testContext.setAttribute("driver", driver2);

		getDriver().manage().deleteAllCookies();
		common.impicitWait(20);
		getDriver().manage().window().maximize();
		getDriver().get(getSession().getEnv().getUrl());
		getDriver().manage().timeouts().pageLoadTimeout(200, TimeUnit.SECONDS);

	}

	@AfterClass
	public void closeBrowser() {
		driver2.close();
	}

	@DataProvider(name = "inputdata")
	public Object[][] readExcelData() {
		Object[][] sheetData = null;
		sheetData = xls.getSheetData("address","valid");
		return sheetData;
	}

	@Test(dataProvider = "inputdata", testName = "CheckBuildyYourOwnBundle", description = " Bug Id=100 verify title", timeOut = 4190000, enabled = true, groups = { "sanity", }, retryAnalyzer = Retry.class)
	public void CheckBuildyYourOwnBundle(String scenarion, String street,
			String unittype, String zipcode) {
		try {

			Reporter.log("Started Test Case Execution CheckBuildyYourOwnBundle");
			getPageFactory().getATnTHomePage().clickonPrimaryNav();

			Reporter.log(BuildYourOwnBundleTest.class.getName()
					+ " Clicked on build your own bundle");
			getPageFactory().getATnTAvailabilityPage()
					.clickOnCheckAvailabiltyButton(street, unittype, zipcode);

			Reporter.log(BuildYourOwnBundleTest.class.getName()
					+ " Entered address details");

			getPageFactory().getATntTBuildYourOwnBundlePage().verifyPageTile();
			Reporter.log(BuildYourOwnBundleTest.class.getName()
					+ " clicked  on select plan");

			Reporter.log("completed CheckBuildyYourOwnBundle test case");
		} catch (Exception e) {

			getDriver().get(getSession().getEnv().getUrl());
			Assert.assertTrue(false, "test case failed while doing select plan");
		}
	}
}