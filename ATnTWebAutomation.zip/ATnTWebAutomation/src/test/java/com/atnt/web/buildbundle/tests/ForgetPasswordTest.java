package com.atnt.web.buildbundle.tests;


import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.atnt.common.Common;
import com.atnt.web.base.WebTestCase;
import com.atnt.framework.common.Retry;
import com.atnt.framework.common.Screenshot;



@Listeners({ Screenshot.class })
public class ForgetPasswordTest extends WebTestCase {
	private Common common = new Common(driver);
	private WebDriver driver2 = driver;
	

	@BeforeClass
	public void initialize(ITestContext testContext) {
		testContext.setAttribute("driver", driver2);
		
		getDriver().manage().deleteAllCookies();
		common.impicitWait(20);
		getDriver().manage().window().maximize();
		getDriver().get(getSession().getEnv().getUrl());
		getDriver().manage().timeouts().pageLoadTimeout(200, TimeUnit.SECONDS);

	}

	@AfterClass
	public void closeBrowser() {
		driver2.manage().deleteAllCookies();
		driver2.close();
	}

	
	@Test(testName = "Dont Know your Contact Email", description = "Click On Dont Know Your Contact Email", priority = 2, timeOut = 4190000, enabled = true, groups = { "sanity", }, retryAnalyzer = Retry.class)
	public void checkErrorMessageOnDontKnowContactEmail() {
		try {
			getPageFactory().getATnTHomePage().clickHomeLink();
			getPageFactory().getATnTHomePage().clickOnForgotUserIDLink();
			getPageFactory().getATnTForgotPasswordPage()
					.checkErrorOnClickingDontKnowEmailAddress();
		} catch (Exception e) {
			getDriver().get(getSession().getEnv().getUrl());
			Assert.assertTrue(false,
					"test case failed verifying the error message");
			
		}
	}
}