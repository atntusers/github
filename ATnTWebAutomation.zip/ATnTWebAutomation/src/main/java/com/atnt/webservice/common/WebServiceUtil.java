package com.atnt.webservice.common;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
//import net.sf.json.JSONObject;
//import net.sf.json.JSONSerializer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
//import org.testng.Reporter;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;

import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HostParams;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

/**
 * This utility class will hit the restful web service by using client id and
 * client secret and will genearte the access token . By using this generated
 * access token will hit the URL and get the results as response.
 * 
 */
@SuppressWarnings("deprecation")
public class WebServiceUtil {
	private static Logger log = Logger
			.getLogger(WebServiceUtil.class.getName());
	private String clientID = null;
	private String clientSecret = null;
	private String prevMerchantID = null;

	/**
	 * @return the apiStatusCode
	 */
	public int getApiStatusCode() {
		return apiStatusCode;
	}

	/**
	 * @return the apiStatusMessage
	 */
	public String getApiStatusMessage() {
		return apiStatusMessage;
	}

	private int apiStatusCode;
	private String apiStatusMessage = null;

	public String getClientID() {
		return clientID;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public String setClientID(String id) {
		return clientID = id;
	}

	public String setClientSecret(String secret) {
		return clientSecret = secret;
	}
	/**
	 * @return the prevMerchantID
	 */
	public String getPrevMerchantID() {
		return prevMerchantID;
	}
	/**
	 * @param prevMerchantID the prevMerchantID to set
	 */
	public void setPrevMerchantID(String prevMerchantID) {
		this.prevMerchantID = prevMerchantID;
	}

	/**
	 * This method will returns json object and which contains the AccessToken.
	 * 
	 * @param clientID
	 * @param clientSecret
	 * @param tokenURL
	 * @return JSONObject
	 * @throws Exception
	 */
	public String getAPIAccessToken(String clientID, String clientSecret,
			String tokenURL) throws Exception {
		log.info(getClass().getName() + "getAPIAccessToken" + "clientID=="
				+ clientID + "clientSecret==" + clientSecret);
		log.info("tokenURL==" + tokenURL);
		JSONObject js = null;
		HttpClient client = getHttpClient();
		GetMethod req = new GetMethod(tokenURL);
		req.addRequestHeader("client_id", clientID);
		req.addRequestHeader("client_secret", clientSecret);
		req.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,
				new DefaultHttpMethodRetryHandler(3, false));
		client.executeMethod(req);
		js = new JSONObject(req.getResponseBodyAsString());
		return js.getJSONObject("Result").getString("AccessToken");

	}

	public JSONObject getAPIAccessTokenObj(String clientID,
			String clientSecret, String tokenURL) throws Exception {
		log.info(getClass().getName() + "getAPIAccessTokenObj" + "clientID=="
				+ clientID + "clientSecret==" + clientSecret);
		log.info("tokenURL==" + tokenURL);
		JSONObject js = null;
		HttpClient client = getHttpClient();
		GetMethod req = new GetMethod(tokenURL);
		req.addRequestHeader("client_id", clientID);
		req.addRequestHeader("client_secret", clientSecret);
		req.addRequestHeader("Content-Type", "application/json");
		req.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,
				new DefaultHttpMethodRetryHandler(3, false));
		client.executeMethod(req);
		js = new JSONObject(req.getResponseBodyAsString());
		apiStatusCode = js.getInt("Code");
		apiStatusMessage = js.getString("Message");
		log.info("STATUS CODE==" + apiStatusCode);
		log.info("STATUS MESSAGE==" + apiStatusMessage);
		return js;
	}

	public JSONObject getAPIStatus(String accessToken, String API_URL,
			String startDate, String endDate, String limit) throws Exception {
		log.info(getClass().getName() + "    getSalesByCustomerWithoutStoreNo");
		JSONObject js = null;
		String URL = API_URL + "?" + "start_date=" + startDate + "&"
				+ "end_date=" + endDate + "&" + "limit=" + limit;
		log.info("URL==" + URL);
		HttpClient client = getHttpClient();
		client.getHostConfiguration().setProxy(
				"noida-sez-v10k.hclt.corp.hcl.in", 8080);
		GetMethod req = new GetMethod(URL);
		HostParams hc = client.getHostConfiguration().getParams();
		req.addRequestHeader("Content-Type", "application/json");
		req.addRequestHeader("Authorization", "Bearer " + accessToken);
		client.getHostConfiguration().setParams(hc);
		client.executeMethod(req);
		js = new JSONObject(req.getResponseBodyAsString());
		apiStatusCode = js.getInt("Code");
		apiStatusMessage = js.getString("Message");
		log.info("STATUS CODE==" + apiStatusCode);
		log.info("STATUS MESSAGE==" + apiStatusMessage);
		return js;
	}

	/**
	 * This method gets Sales by Ticket for given params and return results as
	 * JSONArray using restricted dates
	 * 
	 * @param accessToken
	 * @param API_URL
	 * @param START_DATE
	 * @param STORE_NUMBER
	 * @return SHOW_VARIATIONS
	 * @throws Exception
	 */
	public JSONObject getAPIResponse(String accessToken, String URL)
			throws Exception {
		log.info(getClass().getName() + "    getJsonAsResponse");
		JSONObject js = null;
		HttpClient client = getHttpClient();// jar mavn
		GetMethod req = new GetMethod(URL);
		HostParams hc = client.getHostConfiguration().getParams();
		req.addRequestHeader("Content-Type", "application/json");
		req.addRequestHeader("Authorization", "Bearer " + accessToken);
		client.getHostConfiguration().setParams(hc);
		client.executeMethod(req);
		js = new JSONObject(req.getResponseBodyAsString());
		return js;
	}
	/**
	 *  POST - REQUEST  - GRAPH REPORT VALIDATION
	 * 
	 *  This method gets Grapph report for given params and return results as JSONArray using restricted dates
	 * @param accessToken
	 * @param API_URL
	 * @param requestArgs
	 * @throws Exception 
	 */
	public JSONArray getGraphResponseForPostRequest(String URL,String requestArgs,String accessToken ) throws Exception {
        log.info(getClass().getName()+"    getAPIResponseForPostRequest");
        JSONArray resp = null;
        log.info("URL---->"+URL);
        DefaultHttpClient httpClient = new DefaultHttpClient();
      StringBuilder result = new StringBuilder();
      try {
    	  
             HttpPost putRequest = new HttpPost(URL);
             putRequest.addHeader("Content-Type", "application/json");
             putRequest.addHeader("Accept", "application/json");
             putRequest.addHeader("Date","Tue, 15 Feb 2015 08:12:31 GMT");
             // TODO - Need to provide the cookies(as of now) - need to change
             putRequest.addHeader("Cookie","SilverWebSessionId=cgxvw1123ybam24xvfg1fgco; SilverWebAuth=FE0A5D3A514B612CE350E11DBAF98FCC48AFB08465A52C98B1EC6E07E8EB91F9A88566B32E0F922C7EBC2DF3DD1D559A573EF5D65B56524E4BF0CD77A7BF2BDEE54A98F87A64E2C79BAA0ED5388DA53D0068CE007479BFB8F45359598CB52EABE5B2EFF0539B7A077DB437B8692355EF28CB1EFA9E5681C85AFB6F7C8E06C14D1862DD818EED9FB791FE87BE8D5851C0A10F6B8ACD5A760466F246F6F857DB038E17F77B8659915E3378C3FB8D794B4CA985EA50622FF6C58EE5C8204AC31F150C2342296AF33245EAFD182E7F4896E687CF035832959CFB310AAF37E4A65A603B97AB9EC014F1F20A02AA72367BBA8746C2CCB808028410CEAFA5F52478E79839ECC8CA");
            putRequest.addHeader("Authorization", "Bearer " + accessToken);
             StringEntity input = null;
             try {
                 input = new StringEntity(requestArgs.toString());
             } catch (UnsupportedEncodingException e) {
                 e.printStackTrace();
             }
             putRequest.setEntity(input);
             HttpResponse response = httpClient.execute(putRequest);
            log.info("STATUS CODE IS : "+ response.getStatusLine().getStatusCode());
             BufferedReader br = new BufferedReader(new InputStreamReader(
                     (response.getEntity().getContent())));
             String output;
             while ((output = br.readLine()) != null) {
                 result.append(output);
             }
             log.info("[RESULT] "+result.toString() );
             String jsResult=result.toString();
             resp = new JSONArray(jsResult);
             System.out.println("---->resp<----"+resp);
         } catch (ClientProtocolException e) {
             e.printStackTrace();
         } catch (IOException e) {
             e.printStackTrace();
         }
            log.info("[END RUN] { "+ getClass().getName()+"}    getAPIResponseForPostRequest");
            return resp;
	}

	/**
	 * POST - REQUEST
	 * 
	 * This method gets Sales by Ticket for given params and return results as
	 * JSONArray using restricted dates
	 * 
	 * @param accessToken
	 * @param API_URL
	 * @param requestArgs
	 * @throws Exception
	 */
	public JSONObject getAPIResponseForPostRequest(String accessToken,
			String URL, JSONObject requestArgs) throws Exception {
		log.info(getClass().getName() + "    getAPIResponseForPostRequest");
		DefaultHttpClient httpClient = new DefaultHttpClient();
		StringBuilder result = new StringBuilder();
		HttpPost req = new HttpPost(URL);
		req.addHeader("Content-Type", "application/json");
		req.addHeader("Accept", "application/json");
		req.addHeader("Authorization", "Bearer " + accessToken);
		StringEntity input = null;
		input = new StringEntity(requestArgs.toString());
		req.setEntity(input);
		HttpResponse response = httpClient.execute(req);
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(response.getEntity().getContent())));
		String output;
		while ((output = br.readLine()) != null) {
			result.append(output);
		}
		return new JSONObject(result.toString());
	}

	/**
	 * PUT REQUEST This method gets Sales by Ticket for given params and return
	 * results as JSONArray using restricted dates
	 * 
	 * @param accessToken
	 * @param API_URL
	 * @param requestArgs
	 * @throws Exception
	 */
	public JSONObject getAPIResponseForPutRequest(String accessToken,
			String URL, JSONObject requestArgs) throws Exception {
		log.info(getClass().getName() + "    getAPIResponseForPutRequest");
		DefaultHttpClient httpClient = new DefaultHttpClient();
		StringBuilder result = new StringBuilder();
		HttpPut req = new HttpPut(URL);
		req.addHeader("Content-Type", "application/json");
		req.addHeader("Accept", "application/json");
		req.addHeader("Authorization", "Bearer " + accessToken);
		StringEntity input = null;
		input = new StringEntity(requestArgs.toString());
		req.setEntity(input);
		HttpResponse response = httpClient.execute(req);
		log.info("STATUS CODE--->"+response.getStatusLine().getStatusCode());
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(response.getEntity().getContent())));
		String output;
		while ((output = br.readLine()) != null) {
			result.append(output);
		}
		return new JSONObject(result.toString());
	}

	/**
	 * DELETE REQUEST
	 * 
	 * This method removes an Item Validate DELETE REQUEST of an existing ITEM
	 * 
	 * @param accessToken
	 * @param API_URL
	 * @throws Exception
	 */
	public String getAPIResponseForRemoveItem(String accessToken, String URL)
			throws Exception {
		log.info(getClass().getName() + "    getAPIResponseForUpdateAnItem");
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpDelete req = new HttpDelete(URL);
		req.addHeader("Content-Type", "application/json");
		req.addHeader("Accept", "application/json");
		req.addHeader("Authorization", "Bearer " + accessToken);
		HttpResponse response = httpClient.execute(req);
		log.info("--------RESPONSE STATUS LINE"+response.getStatusLine());
		return String.valueOf(response.getStatusLine().getStatusCode());
	}

	/**
	 * DELETE REQUEST
	 * 
	 * This method removes an Item Validate DELETE REQUEST of an existing ITEM
	 * 
	 * @param accessToken
	 * @param API_URL
	 * @throws Exception
	 */
	public JSONObject getAPIResponseForRemoveItemWithMessage(
			String accessToken, String URL) throws Exception {
		log.info(getClass().getName() + "    getAPIResponseForRemoveAnItem");
		StringBuilder result = null;
		DefaultHttpClient httpClient = new DefaultHttpClient();
		result = new StringBuilder();
		HttpDelete req = new HttpDelete(URL);
		req.addHeader("Content-Type", "application/json");
		req.addHeader("Accept", "application/json");
		req.addHeader("Authorization", "Bearer " + accessToken);
		HttpResponse response = httpClient.execute(req);
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(response.getEntity().getContent())));
		String output;
		while ((output = br.readLine()) != null) {
			result.append(output);
		}
		return new JSONObject(result.toString());
	}

	public ArrayList<JSONObject> convertJSONArrayToArrayList(JSONArray jsonArray)
			throws Exception {
		ArrayList<JSONObject> list = new ArrayList<JSONObject>();
		if (jsonArray != null) {
			for (int i = 0; i < jsonArray.length(); i++) {
				try {
					list.add(jsonArray.getJSONObject(i));
				} catch (JSONException e1) {
					e1.printStackTrace();
				}
			}
		}
		return list;
	}

	private HttpClient getHttpClient() throws Exception {
		HttpClient client = new HttpClient();
		// TODO comment the below line when executing at NCR
		// client.getHostConfiguration().setProxy("hyd-hclt-adc01.hclt.corp.hcl.in",
		// 8080);
		return client;
	}
	
	
	private HttpResponse getHttpResponse(String resturl,HttpHost proxy) throws Exception {
		HttpUriRequest request = new HttpGet(resturl);
		
		//request.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY,proxy);
		request.addHeader("Cookie","SHOPSESSIONID=RmSVl14ZxKAEKChCcgqrG3UBctKQhUpG!-1491228561");
		HttpResponse httpResponse = HttpClientBuilder.create().build().execute(request);
		return httpResponse;
	}
	
	///////--------NEWLY ADDED
	
	public String getAPIResponseATT( String resturl,HttpHost proxy)
			throws Exception {
		//testStatusCode(URL);
		log.info(getClass().getName() + "    getJsonAsResponse");
		JSONObject js = null;
		HttpResponse hr= getHttpResponse(resturl,proxy);
		
		String rss = EntityUtils.toString(hr.getEntity());
		System.out.println("value-----------------------------" +rss);
		return rss;
	}
	public  int testStatusCode(String restURL,HttpHost proxy) throws Exception {
		
		return getHttpResponse(restURL,proxy).getStatusLine().getStatusCode();
		
			}
}
