package com.atnt.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.atnt.framework.common.TestSession;
import com.atnt.common.Common;

public class ForgotPasswordPage {
	private WebDriver driver;// = selenium.getDriver();
	private Common common;// = new Common();
	private TestSession session;

	@FindBy(xpath = Elements.forgotUserIDAndPassword)
	private WebElement forgotUserIDAndPassword1;

	@FindBy(xpath = Elements.contactMailIDTextBox)
	private WebElement contactMailIDTextBox;

	@FindBy(xpath = Elements.continueButton)
	private WebElement continueButton;

	@FindBy(xpath = Elements.errorMessage)
	private WebElement errorMessage;

	@FindBy(xpath = Elements.errorMessageWithoutDomain)
	private WebElement errorMessageWithoutDomain;

	@FindBy(xpath = Elements.dontKnowEmailAddressLink)
	private WebElement dontKnowEmailAddressLink;

	@FindBy(xpath = Elements.accountSelectBox)
	private WebElement accountSelectBox;

	@FindBy(xpath = Elements.accountEnteredTextBox)
	private WebElement accountEnteredTextBox;

	@FindBy(xpath = Elements.zipCodeTextBox)
	private WebElement zipCodeTextBox;

	@FindBy(xpath = Elements.continueButtonForgotPage)
	private WebElement continueButtonForgotPage;

	@FindBy(xpath = Elements.checkYourInfoErrorMsg)
	private WebElement checkYourInfoErrorMsg;

	@FindBy(xpath = Elements.errorMsgBox)
	private WebElement errorMsgBox;

	public ForgotPasswordPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);

	}

	/*
	 * The below method validates the error message on passing invalid email ID
	 * in the forgot password page.
	 */
	public void checkForgotUserIDAndPassword() throws InterruptedException {
		try {

			String actualTitle = driver.getTitle();
			String expectedTitle = "Forgot Your myAT&T User ID? Recover Your AT&T User ID";
			common.verifyText(actualTitle, expectedTitle);
			forgotUserIDAndPassword1.click();
			contactMailIDTextBox.sendKeys("xyudffifhrf@gmail.com");
			continueButton.click();
			common.verifyText(actualTitle, expectedTitle);
			String expectedErrorMsg = "We can't find a match for that email address.";
			String actualErrorMsg = errorMessage.getText();
			common.verifyText(actualErrorMsg, expectedErrorMsg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * The below method validates the error message on passing invalid email ID
	 * without domain in the text box.
	 */
	public void checkErrorMessageOnEmailWithoutDomain()
			throws InterruptedException {
		try {

			String actualTitle = driver.getTitle();
			String expectedTitle = "Forgot Your myAT&T User ID? Recover Your AT&T User ID";
			common.verifyText(actualTitle, expectedTitle);
			forgotUserIDAndPassword1.click();
			contactMailIDTextBox.sendKeys("xyud");
			continueButton.click();
			common.verifyText(actualTitle, expectedTitle);
			String actualError = errorMessageWithoutDomain.getText();
			String expectedError = "Please enter a valid email format (ex. xyz@domain.net)";
			common.verifyText(actualError, expectedError);
			Assert.assertEquals(actualError, expectedError);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * The below method validates the error message on clicking on "Dont know
	 * your email address,passing the details and check if error is displayed"
	 */

	public void checkErrorOnClickingDontKnowEmailAddress() {
		try {
			String actualTitle = driver.getTitle();
			String expectedTitle = "Forgot Your myAT&T User ID? Recover Your AT&T User ID";
			common.verifyText(actualTitle, expectedTitle);
			forgotUserIDAndPassword1.click();
			dontKnowEmailAddressLink.click();
			Select sel = new Select(accountSelectBox);
			sel.selectByVisibleText("Wireless");
			accountEnteredTextBox.sendKeys("9856321420");
			zipCodeTextBox.sendKeys("98507");
			continueButtonForgotPage.click();
			common.impicitWait(10);
			String newActualTitle = driver.getTitle();
			String newExpectedTitle = "Forgot User ID";
			common.verifyText(newActualTitle, newExpectedTitle);
			String actualError = checkYourInfoErrorMsg.getText();
			String expectedError = "Check your information, and try again.";
			common.verifyText(actualError, expectedError);
			Assert.assertEquals(actualError, expectedError);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
