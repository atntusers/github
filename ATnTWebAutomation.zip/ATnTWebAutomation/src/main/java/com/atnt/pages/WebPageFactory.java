package com.atnt.pages;

import org.openqa.selenium.WebDriver;

public class WebPageFactory {
	private HomePage ATnTHomePage;
	private EDSAvailabilityPage EDSAvailabilityPage;
	private BuildYourOwnBundlePage ATnTBuildYourOwnBundlePage;
	private RegisterTodayPage ATnTRegisterTodayPage;
	private ForgotPasswordPage ATnTForgotPasswordPage;
	private BringYourPhoneOrTabletPage ATnTBringYourPhoneOrTabletPage;

	public WebPageFactory(WebDriver driver) {
		System.out.println("ATnTPageFactory constrctor");
		ATnTHomePage = new HomePage(driver);
		EDSAvailabilityPage = new EDSAvailabilityPage(driver);
		ATnTBuildYourOwnBundlePage = new BuildYourOwnBundlePage(driver);
		ATnTRegisterTodayPage = new RegisterTodayPage(driver);
		ATnTForgotPasswordPage = new ForgotPasswordPage(driver);
		ATnTBringYourPhoneOrTabletPage = new BringYourPhoneOrTabletPage(driver);
	}

	public RegisterTodayPage getATnTRegisterTodayPage() {
		return ATnTRegisterTodayPage;
	}

	public HomePage getATnTHomePage() {
		return ATnTHomePage;
	}

	public EDSAvailabilityPage getATnTAvailabilityPage() {
		return EDSAvailabilityPage;
	}

	public BuildYourOwnBundlePage getATntTBuildYourOwnBundlePage() {
		return ATnTBuildYourOwnBundlePage;
	}

	public ForgotPasswordPage getATnTForgotPasswordPage() {
		return ATnTForgotPasswordPage;
	}

	public BringYourPhoneOrTabletPage getATnTBringYourPhoneOrTabletPage() {
		return ATnTBringYourPhoneOrTabletPage;
	}
}
