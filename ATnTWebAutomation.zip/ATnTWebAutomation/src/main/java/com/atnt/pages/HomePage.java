package com.atnt.pages;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.testng.Reporter;
import com.atnt.pages.Elements;
import com.atnt.common.Common;
import com.atnt.framework.common.TestSession;

/**
 * This class contains total functionality related to At&t home page -
 * www.att.com
 * 
 * @author Sandeep Gautam
 * 
 * 
 */

public class HomePage {

	private WebDriver driver;// = selenium.getDriver();
	private Common common;// = new Common();
	private TestSession session;
	private Logger logger = Logger.getLogger(HomePage.class.getName());

	@FindBy(xpath = Elements.primaryNavShopLink)
	private WebElement PrimaryNavShopLink;

	@FindBy(xpath = Elements.primaryNavShopBundlesLink)
	private WebElement primaryNavShopBundlesLink;

	@FindBy(xpath = Elements.buildYourOwnBundle)
	private WebElement buildYourOwnBundle;

	@FindBy(xpath = Elements.homeLink)
	private WebElement homeLink;

	@FindBy(xpath = Elements.forgotUserID)
	private WebElement forgotUserID;

	public HomePage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);

	}

	/**
	 * Method to click all Primary Nav Links
	 * 
	 * @throws InterruptedException
	 */
	public void clickonPrimaryNav() throws InterruptedException {

		common.MouseHoverFunction(PrimaryNavShopLink);
		logger.info(HomePage.class.getName()
				+ "   mouse hovered at primary link");

		common.MouseHoverFunction(primaryNavShopBundlesLink);
		logger.info(HomePage.class.getName()
				+ "   mouse hovered at secondary link");
		buildYourOwnBundle.click();
		logger.info(HomePage.class.getName() + "   clicked on third level link");
		Reporter.log("redirecting to check availability page", true);

	}

	public void clickOnForgotUserIDLink() {
		try {
			forgotUserID.click();
			common.impicitWait(10);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickHomeLink() {
		try {
			homeLink.click();
			common.impicitWait(20);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
