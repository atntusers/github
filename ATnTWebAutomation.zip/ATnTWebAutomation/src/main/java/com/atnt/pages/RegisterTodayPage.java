package com.atnt.pages;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;

import com.atnt.common.Common;
import com.atnt.pages.Elements;
import com.atnt.framework.common.TestSession;

/**
 * This class contains total functionality related to At&t home page -
 * www.att.com
 * 
 * @author prashant kumar
 * 
 * 
 */

public class RegisterTodayPage {

	private WebDriver driver;// = selenium.getDriver();
	private Common common;// = new Common();
	private TestSession session;

	@FindBy(xpath = Elements.registertodayLink)
	private WebElement RegisterTodayLink;

	@FindBy(xpath = Elements.accouttypeList)
	private WebElement AccoutTypeList;

	@FindBy(xpath = Elements.accounttypelabel)
	private WebElement AccountTypeLabel;

	@FindBy(xpath = Elements.accountidText)
	private WebElement AccountIdText;

	@FindBy(xpath = Elements.errorText)
	private WebElement ErrorText;

	@FindBy(xpath = Elements.zipcodeText)
	private WebElement ZipcodeText;

	@FindBy(xpath = Elements.nxtBtn)
	private WebElement NxtBtn;

	public RegisterTodayPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);

	}

	/**
	 * Method to click all Primary Nav Links
	 */
	public void clickonRegisterToday() {
		try {

			common.impicitWait(10);
			if (common.isElementPresent(RegisterTodayLink) == true) {
				RegisterTodayLink.click();
				common.impicitWait(10);
			} else {
				Reporter.log("--Register today Element Not Present--");
			}
		} catch (ElementNotVisibleException ex) {
			ex.getCause().printStackTrace();
		}

	}

	public void selectonAccTypeRegisterToday() {
		try {
			Select selectAcctype = new Select(AccoutTypeList);
			common.impicitWait(10);
			selectAcctype.selectByVisibleText("Wireless / Wireless Home Phone");
			common.impicitWait(10);
			Assert.assertEquals(4, selectAcctype.getOptions().size());
		} catch (NoSuchElementException ex) {
			ex.getCause().printStackTrace();
		} catch (Exception ex) {
			ex.getCause().printStackTrace();
			Reporter.log("--Exception in selectonAccTypeRegisterToday --");
		}
	}

	public void enterAccNumberZip() {
		try {
			common.impicitWait(10);

			if (common.isElementPresent(AccountIdText) == true
					&& common.isElementPresent(ZipcodeText) == true) {
				AccountIdText.sendKeys("2125553456");
				common.impicitWait(10);
				ZipcodeText.sendKeys("98362");
			} else {
				Reporter.log("--enterAccNumberZipCode Element Not Present--");
			}
		}

		catch (Exception ex) {
			ex.getCause().printStackTrace();
			Reporter.log("--Exception in enterAccNumberZip --");
		}

	}

	public void clickNxtonRegister() {
		try {
			common.impicitWait(10);
			if (common.isElementPresent(NxtBtn) == true) {
				NxtBtn.click();
			} else {
				Reporter.log("--clickNxtonRegister Element Not Present--");
			}
			common.impicitWait(10);
		} catch (Exception ex) {
			ex.getCause().printStackTrace();
			Reporter.log("--Exception in clickNxtonRegister --");
		}
	}

	public void verifyAccTypeRegisterToday() {
		try {
			Select selectAcctype = new Select(AccoutTypeList);
			common.impicitWait(10);
			Assert.assertEquals(4, selectAcctype.getOptions().size());
		} catch (Exception ex) {
			ex.getCause().printStackTrace();
			Reporter.log("--Exception in verifying the AccType--");
		}
	}

	public void verifyNxtonRegister() {
		try {
			common.impicitWait(10);
			ErrorText.getText().toString();
			if (ErrorText.getText().toString().contains("valid phone number")) {
				common.verifyText(ErrorText.getText().toString(),
						"Be sure to enter a valid phone number. It's required.");
				common.impicitWait(10);
			}
		} catch (Exception ex) {
			ex.getCause().printStackTrace();
			Reporter.log("--Exception in verifying the acc type --");
		}
	}

	public void verifyregistertodayPage() {
		try {
			common.waitForDriver(AccountTypeLabel, 10, 3);
		} catch (TimeoutException te) {
			te.getCause().printStackTrace();

			Reporter.log("--Cannot find the Account type label--");
		}
	}

}