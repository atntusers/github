package com.atnt.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.atnt.framework.common.TestSession;
import com.atnt.common.Common;

/**
 * This class contains total functionality related click on Bring Your Phone Or
 * Tablet link under SHOP
 * 
 * @author somalarajuc
 * 
 */
public class BringYourPhoneOrTabletPage {
	private WebDriver driver;// = selenium.getDriver();
	private Common common;// = new Common();
	private TestSession session;

	@FindBy(xpath = Elements.selectDeviceType)
	private WebElement selectDeviceType;

	@FindBy(xpath = Elements.selectBrand)
	private WebElement selectBrand;

	@FindBy(xpath = Elements.selectFirstImage)
	private WebElement selectFirstImage;

	@FindBy(xpath = Elements.clickOnContinueBtn)
	private WebElement clickOnContinueBtn;

	@FindBy(xpath = Elements.enterIMEINumber)
	private WebElement enterIMEINumber;

	@FindBy(xpath = Elements.clickOnContinue)
	private WebElement clickOnContinue;

	@FindBy(xpath = Elements.verifyErrorMsg)
	private WebElement verifyErrorMsg;

	public BringYourPhoneOrTabletPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	public void clickOnContinueBtn() throws InterruptedException {

		Select deviceType = new Select(selectDeviceType); // = Select Device
															// Type as "Phone"
		deviceType.selectByVisibleText("Phone");

		Select brandType = new Select(selectBrand); // = Select Brand as AT&T
		brandType.selectByVisibleText("AT&T");

		selectFirstImage.click(); // = Select the first image displayed in
									// search results

		clickOnContinueBtn.click(); // = Click on Continue button

		enterIMEINumber.sendKeys("356899050451751");

		clickOnContinue.click();

		System.out.println("IMEI Verification Displayed");

		boolean errorMsgPresence = verifyErrorMsg.isDisplayed();

	}

}
