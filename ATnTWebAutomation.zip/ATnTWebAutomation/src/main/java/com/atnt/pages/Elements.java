package com.atnt.pages;

import org.openqa.selenium.By;

/**
 * @author prashant_kumar
 * 
 *         This class contains all xpaths
 */
public class Elements {

	
	// -----Register User from ATT login page---------

	
	public static final String registertodayLink = "//*[@id='registerToday']/a";
	public static final String accouttypeList = "//*[@id='selectedAccountType']";
	public static final String accountidText = "//*[@id='selectedAccountId']";
	public static final String zipcodeText = "//*[@id='zipCode']";
	public static final String nxtBtn = "//*[@id='enbNextBtn']";
	public static final String errorText = "//*[@id='jsErrMsg']";
	public static final String accounttypelabel = "//*[@id='AccountType']";

	// --------Forgot Password Page---------------
	public static final String forgotUserID = "//a[contains(text(),'User ID')]";
	public static final String forgotUserIDAndPassword = "//input[@id='forgotUserid2']";
	public static final String contactMailIDTextBox = "//input[@id='combinedCustomerEmailAddress']";
	public static final String continueButton = "//button[@id='btnPrimarySmall']";
	public static final String errorMessage = "//div[@class='errorMsg box']/p/b[1]";
	public static final String errorMessageWithoutDomain = "html/body/div[14]/div[1]/div[2]/div[1]/div[4]/div/form/div[1]/div/div[3]/div[2]/div/div[2]/div[2]/div[2]/p";
	public static final String dontKnowEmailAddressLink = "html/body/div[14]/div[1]/div[2]/div[1]/div[4]/div/form/div[1]/div/div[3]/div[2]/div/p/a";
	public static final String accountSelectBox = "//select[@id='loginMethodSelectType']";
	public static final String accountEnteredTextBox = "//input[@id='accountEntered']";
	public static final String zipCodeTextBox = "//input[@id='userZip']";
	public static final String continueButtonForgotPage = "//a[@id='enbContBtn']";
	public static final String checkYourInfoErrorMsg = "//div[@class='errorMsg box']/p/b";
	public static final String errorMsgBox = "//div[@class='errorMsg box'][1]";
	public static final String homeLink = "//a[@title='AT&T Home Page Link']";

	// ----Primary Navigation Links-------

	public static final String primaryNavHomeLogoLink = "//*[@id='primaryLogo']/a";
	public static final String primaryNavShopLink = "//*[@id='ge5p_z2_p1001']";
	public static final String primaryNavShopWirelessLink = "//*[@id='ge5p_z2_s1001']";
	public static final String primaryNavShopWirelessBringYourPhoneOrtabletLink = "//*[@id='ge5p_z2_t1006']";
	public static final String bringYourPhoneOrtablet = "//*[@id='ge5p_z2_t1006']";
	public static final String primaryNavShopWirelessSmartPhone = "//*[@id='ge5p_z2_t1002']";

	// -----Bring Your Phone Or Tablet Page-----

	public static final String selectDeviceType = "//*[@id='selectedDeviceType']";
	public static final String selectBrand = "//*[@id='selectBrand']";
	public static final String selectFirstImage = "html/body/div[5]/div[3]/div[2]/div/div/div[4]/div/div[1]/div[2]/div[2]/div[2]/div[1]/a/div/div[2]/img";
	public static final String clickOnContinueBtn = "//*[@id='byop-continue']";

	// ----Bring Your Phone Or Tablet Page_IMEI Verification-----

	public static final String enterIMEINumber = "//*[@id='imei-input-2']";
	public static final String verifyErrorMsg = "//*[@id='imei_error']";
	public static final String clickOnContinue = "//*[@id='imei-continue-btn']";

	
	//-----Header
	public static final String globalNavAllLinks = "//div[@id='ge5p_z1-global-nav-container']/ul[1]/li[1]/a";
	public static final String secondaryNavAllLinks = "//div[@id='ge5p_z2-user-info']/div/div/span";
	public static final String secondaryNavLogonButton = "//div[@id='ge5p_z2-user-info']/div/a/span";
	public static final String primaryNavAllLinksAndSearchBox = "//div[@id='ge5p_z2-primary-nav-wrapper']/nav/ul/li";

	public static final String globalNavPeronalLink = "//*[@id='ge5p_z1_s1001']";

	public static final String globalNavBusinessLink = "//*[@id='ge5p_z1_s1002']";

	public static final String globalNavAboutAtntLink = "//*[@id='ge5p_z1_s1003']";

	public static final String secondaryNavZipLink = "//*[@id='ge5p_z2-zipcode-enter']";
	public static final String secondaryNavRegisterLink = "//*[@id='ge5p_z2-zipcode-register']";
	public static final String secondaryNavLoginButton = "//*[@id='ge5p_z2-user-auth']/span";

	public static final String primaryNavShopTVLink = "//*[@id='ge5p_z2_s1002']";

	public static final String primaryNavShopBundlesLink = "//*[@id='ge5p_z2_s1003']";

	public static final String primaryNavShopInternetLink = "//*[@id='ge5p_z2_s1004']";

	public static final String primaryNavShopHomePhoneLink = "//*[@id='ge5p_z2_s1005']";

	public static final String primaryNavShopDigitalLifeLink = "//*[@id='ge5p_z2_s1006']";
	public static final String primaryNavShopAccessoriesLink = "//*[@id='ge5p_z2_s1007']";
	public static final String primaryNavShopOffersLink = "//*[@id='ge5p_z2_s1008']";
	public static final String primaryNavMyATnTLink = "//*[@id='ge5p_z2_p2001']";
	public static final String primaryNavMyATnTOverview = "//*[@id='ge5p_z2_p3001']";

	public static final String primaryNavSupportLink = "//*[@id='ge5p_z2_p3001']";
	public static final String primaryNavSearchBox = "//*[@id='ge5p_search']]";

	public static final String buildYourOwnBundle = ".//*[@id='ge5p_z2_t1057']";

	// ----Availability page------

	public static final String streetAddress = ".//*[@id='streetaddress']";
	public static final String unitType = ".//*[@id='unitnumber']";

	public static final String zipCode = ".//*[@id='zipcode']";

	public static final String checkAvailabiltyButton = ".//*[@value='Check Availability']";

	// Login Page Objects //

	public static final String userName = "usernameInput";
	public static final String password = "passwordInput";
	public static final String submitBtn = "submitBtn";
	public static final String errorPopup = "//div[@class='login-error']/span[1]";
	public static final String okBtn = "confirm-okay";
	public static final String logincustomeragreement = ".//*[@id='wrapper']//span[contains(text(),'Customer Agreement')]";
	public static final String loginprivacypolicy = ".//*[@id='wrapper']//span[contains(text(),'Privacy')]";
	public static final String loginlocatingyou = ".//*[@id='wrapper']//span[contains(text(),'Locating You')]";
	public static final String loginlocatingyouverify = "//span[contains(text(),'Location Usage Policy')]";
	public static final String loginlocatingyouok = "//*[@class='cofirm-buttons']//div[@class='confirm-okay']";
	public static final String forgotpassword = ".//*[@id='wrapper']//*[@class='forgot-pwd']";
	public static final String forgotpasswordpage = "//div[contains(text(),'Recover Your Credentials')]";
	public static final String getstarted = "startedBtn";
	public static final String getstartedpage = "//div[contains(text(),'Get Started')]";

	// -------------Build your own bundle------------

	public static final String pageTitle = ".//*[text()='Select any of these services to build your own bundle.']";
	public static final String selectAplanButton = ".//*[@id='iptvSelectBtn']";

}
