package com.atnt.pages;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.atnt.common.Common;
import com.atnt.framework.common.TestSession;

public class BuildYourOwnBundlePage {
	private WebDriver driver;;
	private Common common;
	private Logger logger = Logger.getLogger(BuildYourOwnBundlePage.class
			.getName());
	private TestSession session;

	@FindBy(xpath = Elements.pageTitle)
	private WebElement PageTitle;

	@FindBy(xpath = Elements.selectAplanButton)
	private WebElement SelectAPlan;

	public BuildYourOwnBundlePage(WebDriver driver2) {

		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);

	}

	/**
	 * Method to click all Primary Nav Links
	 * 
	 * @throws Exception
	 */
	public void verifyPageTile() throws Exception {

		logger.info(BuildYourOwnBundlePage.class.getName()
				+ "   waiting for page load");
		common.waitForElement(SelectAPlan, 10000, driver);

		SelectAPlan.click();
		logger.info(BuildYourOwnBundlePage.class.getName()
				+ "   clicked for select plan button");

	}

}
