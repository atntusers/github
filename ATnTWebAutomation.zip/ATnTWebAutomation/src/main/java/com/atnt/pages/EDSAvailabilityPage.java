package com.atnt.pages;


import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.atnt.pages.Elements;
import com.atnt.common.Common;
import com.atnt.framework.common.TestSession;

/**
 * This class contains total functionality related to At&t home page - www.att.com
 * 
 * @author prashant kumar
 *
 *  
 */
public class EDSAvailabilityPage {

    private WebDriver driver;
    private Common common;
   	private TestSession session;
	private Logger logger = Logger.getLogger(EDSAvailabilityPage.class.getName());
	

	@FindBy(xpath = Elements.streetAddress)
	private WebElement streetAddress;
	
	@FindBy(xpath = Elements.unitType)
	private WebElement unitType;
	
	@FindBy(xpath = Elements.zipCode)
	private WebElement zipCode;
	
	
	
	@FindBy(xpath = Elements.checkAvailabiltyButton)
	private WebElement checkAvailabiltyButton;

	public EDSAvailabilityPage(WebDriver driver2) {
	  
		driver = driver2;
	    common = new Common(driver2);
		PageFactory.initElements(driver2, this);
		//session = new TestSession();
	}

	
	


	/**
	 *   Method to click all Primary Nav Links
	 */
	public void clickOnCheckAvailabiltyButton(String streetaddress,String unitnumber,String zipcode) {
		
		
		
		logger.info(EDSAvailabilityPage.class.getName()  +"   clear out any pre populated value in address fileds");
		
		streetAddress.clear();
		unitType.clear();
		zipCode.clear();
		
		logger.info(EDSAvailabilityPage.class.getName()  +"   cleared out pre populated value in address fileds");
		System.out.println("displayed---------"+streetAddress.isDisplayed());
		streetAddress.sendKeys(streetaddress);
		logger.info(EDSAvailabilityPage.class.getName()  +"   entered street address");
		System.out.println("streetaddress"+ streetaddress);
		
		unitType.sendKeys(unitnumber);
		logger.info(EDSAvailabilityPage.class.getName()  +"   entered unitnumber");
		
		zipCode.sendKeys(zipcode);
		logger.info(EDSAvailabilityPage.class.getName()  +"   entered zip code");
		checkAvailabiltyButton.click();
		logger.info(EDSAvailabilityPage.class.getName()  +"   clicked on check availability button");
		
		
		
	}

 }
