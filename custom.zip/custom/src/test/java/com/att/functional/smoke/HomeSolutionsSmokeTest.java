package com.att.functional.smoke;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.att.framework.CommonFunctions;
import com.att.framework.Driver;
import com.att.framework.Driver.HashMapNew;
import com.att.framework.Reporting;
import com.att.hrock.ATTStoreLocations;
import com.att.hrock.CheckAvailabilityPage;
import com.att.hrock.LoginPage;
import com.att.hrock.PrintMapLocators;
import com.att.hrock.StoreDirections;
import com.att.mhr.ATTFindAStore;
import com.att.mhr.ATTFindAStoreDetails;
import com.att.mhr.ATTFindAStoreDirections;
import com.att.mhr.ATTFindAStoreResults;
import com.att.mhr.GigapowerProvideResponsePage;
import com.att.star.AuthenticationPage;
import com.att.star.AutoPayStarPage;
import com.att.star.ExistingServicesPage;
import com.att.star.ModalExistingDTVServiceFound;
import com.att.star.OffersPage;
import com.att.star.TvConfigPage;
import com.att.wbfc.AddVoicePageModify;
import com.att.wbfc.BYOBPage;
import com.att.wbfc.BeforeYouUpgradeModal;
import com.att.wbfc.CartSummaryPage;
import com.att.wbfc.CartSummaryPageModify;
import com.att.wbfc.DashboardPageModify;
import com.att.wbfc.ExistingGigapowerServiceModal;
import com.att.wbfc.GigaPowerResponse;
import com.att.wbfc.InstallationAndEquipmentPage;
import com.att.wbfc.InstallationAndEquipmentPageModify;
import com.att.wbfc.ModalAdditionalCreditInformation;
import com.att.wbfc.PersonalInfoPage;
import com.att.wbfc.PersonalInfoPageModify;
import com.att.wbfc.ReviewOrderPage;
import com.att.wbfc.ReviewOrderPageModify;
import com.att.wbfc.ScheduleInstallationPage;
import com.att.wbfc.ScheduleInstallationPageModify;
import com.att.wbfc.ShopPage;
import com.att.wbfc.ThankYouPage;
import com.att.wbfc.VoipConfig;
import com.att.wbfc.VoipConfigPageModify;
import com.att.wbfc.webservicesWireleine;

public class HomeSolutionsSmokeTest {

    HashMap<String, String> Environment = new HashMap<String, String>();
    HashMapNew Dictionary = new HashMapNew();
    Reporting Reporter;

    // Instances
    Driver d;
    WebDriver driver;
    String driverType;
    CommonFunctions objCommon;
    boolean bSkip;
    int TestCounter = 0;
    ITestResult result;
    String env;
    String runOnEnv;
    String browser;
    
    @Parameters({ "browser", "envcode" })
    @BeforeClass
    public void beforeClass(@Optional("") String browser, @Optional("") String runOnEnv) {
        try {
            driverType = browser;
            Environment.put("CLASS_NAME", this.getClass().getSimpleName());
            d = new Driver(driverType, Dictionary, Environment);
            env = System.getProperty("envName");
            if (env == null) {
                env = runOnEnv;
            }
            Assert.assertNotNull(env);
            // Add env global environments
            Environment.put("ENV_CODE", env);

            // Get the skiped cells
            d.getSkipedCells();
            d.fetchEnvironmentDetails(); // from Environment.xlsx
            if(System.getProperty("dataCenter")!=null){
                Environment.put("SET_COOKIES_REGION",System.getProperty("dataCenter"));
            }
            d.createExecutionFolders(Environment.get("CLASS_NAME"));
            Reporter = new Reporting(driver, driverType, Dictionary, Environment);
            Reporter.fnCreateSummaryReport();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Parameters({ "browser" })
    @BeforeMethod
    public void beforeMethod(@Optional("") String browser, Method method) {
        try {
            String action = method.getName();
            d.fGetDataForTest(action, Environment.get("CLASS_NAME"));
            if(Dictionary.get("HIDE_TEST_DATA")!=null && Dictionary.get("HIDE_TEST_DATA")!=""){
                Environment.put("HIDE_TEST_DATA",Dictionary.get("HIDE_TEST_DATA"));
            }
            if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
                driver = d.fGetWebDriver(driverType, action);
                d.fGuiHandleAuth(browser);
                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                Reporter.driver = driver;
                Reporter.fnCreateHtmlReport(Dictionary.get("TEST_NAME"));
                objCommon = new CommonFunctions(driver, driverType, Environment, Reporter);
                Dictionary.put("TEST_NAME_" + driverType, Dictionary.get("TEST_NAME"));
                
                // position the window so it doesn't cover the screen margins
                driver.manage().window().setPosition(new Point(32, 32));
                // if it is running from Ant and in Chrome browser set the window to a huge size 
                // so the screenshot contains the whole page, not only the visible part
                if(System.getProperty("envName") != null && driverType.toLowerCase().contains("chrome")) {
                    driver.manage().window().setSize(new Dimension(1100, 10000)); // adjust to a huge window height
                } else {
                    driver.manage().window().setSize(new Dimension(1100, 800)); // just adjust the width so there is no horizontal scroll
                }
            }else{
                throw new SkipException("Skipping test: "+ method.getName());
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    // ***************************************************************************************************
    // * NAME : WBFC_Desktop_ProvideHappyFlow
    // * AUTHOR : Abhijeet Gorecha
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void WBFC_Desktop_ProvideHappyFlow(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_PROVIDE_URL") + "availability.html"));
            //driver.manage().window().maximize();
            CheckAvailabilityPage checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.IsPageDisplayed());
            Assert.assertTrue(checkAvailabilityPage.EnterStreetAddress());
            Assert.assertTrue(checkAvailabilityPage.SelectUnitType());
            Assert.assertTrue(checkAvailabilityPage.EnterUnit());
            Assert.assertTrue(checkAvailabilityPage.EnterZipCode());
            Assert.assertTrue(checkAvailabilityPage.ClickCheckAvailbility());
            
            objCommon.fCommonGetCookieValue("SALESSESSIONID");

            ShopPage shopPage = new ShopPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(shopPage.IsShopPageDisplayed());
            driver.manage().window().maximize();
            Assert.assertTrue(shopPage.ClickBYOB());

            
            
            BYOBPage bYOBPage = new BYOBPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(bYOBPage.BYOBPageIsDisplayed());
            Assert.assertTrue(bYOBPage.ClickSelectHSIAButton());
            Assert.assertTrue(bYOBPage.BYOBPageIsDisplayed());
            Assert.assertTrue(bYOBPage.SelectHSIA(Dictionary.get("HSIA_PLAN")));

            Assert.assertTrue(bYOBPage.BYOBPageIsDisplayed());
            Assert.assertTrue(bYOBPage.ClickSelectVOIPButton());
            Assert.assertTrue(bYOBPage.CheckChangeButtonHSIADisplayed());
            Assert.assertTrue(bYOBPage.SelectVOIP(Dictionary.get("VOIP_PLAN")));
            Assert.assertTrue(bYOBPage.ClickContinueCTA());

            VoipConfig voipConfig = new VoipConfig(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(voipConfig.IsConfigVoicePageExist());
            Assert.assertTrue(voipConfig.SelectPhoneNumberOption(1, "NEW"));
            Assert.assertTrue(voipConfig.HomeAlarmSection("NO"));
            Assert.assertTrue(voipConfig.ClickOnContinueToEquimentIstallationPage());

            InstallationAndEquipmentPage installationAndEquipmentPage = new InstallationAndEquipmentPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(installationAndEquipmentPage.IsInstallationEquipmentPageExist());
            Assert.assertTrue(installationAndEquipmentPage.ClickYesForPosQues());
            
            objCommon.fCommonValidateDynamicPageDisplayed("","");
            
            Assert.assertTrue(installationAndEquipmentPage.ClickToAgreeContractTerms());
            Assert.assertTrue(installationAndEquipmentPage.ClickContinueToCartSummary());

            CartSummaryPage cartSummaryPage = new CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
            
            // this fails randomly, adding a page down to get the object in the SS
            ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,1000)", "");
            Assert.assertTrue(cartSummaryPage.SelectIBRadioOption("NO"));

            PersonalInfoPage personalInfoPage = cartSummaryPage.ClickCheckout();
            Assert.assertNotNull(personalInfoPage);
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());

            // contact information
            Assert.assertTrue(personalInfoPage.IsContactDetailsEmpty());
            Assert.assertTrue(personalInfoPage.EnterFirstName(Dictionary.get("FIRSTNAME")));
            Assert.assertTrue(personalInfoPage.EnterLastName(Dictionary.get("LASTNAME")));
            Assert.assertTrue(personalInfoPage.EnterPrimaryNumber(Dictionary.get("PRIMARYNUMBER")));
            Assert.assertTrue(personalInfoPage.EnterEmail(Dictionary.get("EMAIL")));
            Assert.assertTrue(personalInfoPage.ReEnterEmail(Dictionary.get("EMAIL")));

            // credit information
            Assert.assertTrue(personalInfoPage.SelectDateBirthMonth(Dictionary.get("MONTH")));
            Assert.assertTrue(personalInfoPage.SelectDateBirthDay(Dictionary.get("DAY")));
            Assert.assertTrue(personalInfoPage.SelectDateBirthYear(Dictionary.get("YEAR")));
            Assert.assertTrue(personalInfoPage.EnterSSN(Dictionary.get("SSN")));

            // Account setup
            Assert.assertTrue(personalInfoPage.PassCodeAccountSetUp(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.ReEnterPassCodeForAccountSetup(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.SecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            Assert.assertTrue(personalInfoPage.SecurityAnswer(Dictionary.get("SECURITYANSWER")));
         //   Assert.assertTrue(personalInfoPage.Click911ServiceAddress());
            Assert.assertTrue(personalInfoPage.ClickContinueBtn());

            // Optional AutoPay page
            com.att.star.OptionalAutopayPage optionalAutopayPage=new com.att.star.OptionalAutopayPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(optionalAutopayPage.OptionalAutopayPageIsDisplayed());
            Assert.assertTrue(optionalAutopayPage.ClickContinueWithoutAutopay());

            // Schedule Installation page
            ScheduleInstallationPage scheduleInstallationPage = new ScheduleInstallationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
            Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

            // Review Order page
            ReviewOrderPage reviewOrderPage = new ReviewOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

            ThankYouPage thankYouPage = reviewOrderPage.ClickOnSubmitOrder();
            Assert.assertNotNull(thankYouPage);
            Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
        }
    }
    
    //***************************************************************************************************
    //* NAME                : WBFC_Desktop_ModifyHappyFlow
    //* AUTHOR              : Stefan Andrei
    //* STATUS              : TEST COMPLETED SUCCESSFUL IN CHROME
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void WBFC_Desktop_ModifyHappyFlow(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")) {
            
            driver.manage().deleteAllCookies();
            driver.manage().window().maximize();
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

            LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(loginPage.LoginPageIsDisplayed());
            Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

           /* SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(specialOffersPage.isPageDisplayed());
            Assert.assertTrue(specialOffersPage.isBreadcrumbDisplayed());
            Assert.assertTrue(specialOffersPage.checkAtLeastOnePremiumPlanTile());
            Assert.assertTrue(specialOffersPage.addToCartPlanPremiumOffer("ANY", "ANY"));
            Assert.assertTrue(specialOffersPage.isPageDisplayed());
            Assert.assertTrue(specialOffersPage.clickContinue());
           */ 
            
            //objCommon.fCommonValidateDynamicPageDisplayed("","");
            
            DashboardPageModify dashboardPageModify=new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(dashboardPageModify.isPageDisplayed());
            objCommon.fCommonGetCookieValue("SALESSESSIONID");                        
            AddVoicePageModify addVoicePage = dashboardPageModify.clickSelectPlanVOIP();
            Assert.assertNotNull(addVoicePage);
            Assert.assertTrue(addVoicePage.isPageDisplayed());
           // Assert.assertTrue(addVoicePage.clickNewPhoneNoRadio());
           // Assert.assertTrue(addVoicePage.clickHomeIsNotMonitored());
            Assert.assertTrue(addVoicePage.clickAnyPlanTile());
                        
            Assert.assertTrue(addVoicePage.isPageDisplayed());
            
            VoipConfigPageModify voipConfigPageModify=addVoicePage.clickContinue();
            Assert.assertNotNull(voipConfigPageModify);
            Assert.assertTrue(voipConfigPageModify.isPageDisplayed());
            Assert.assertTrue(voipConfigPageModify.clickGiveMeNewPhoneNumber());
            Assert.assertTrue(voipConfigPageModify.clickAdditionalInstallationNeedsYes());
                        
            InstallationAndEquipmentPageModify installOptionsPage = voipConfigPageModify.clickContinue();
            Assert.assertNotNull(installOptionsPage);
            Assert.assertTrue(installOptionsPage.isPageDisplayed());
            //Assert.assertTrue(installOptionsPage.clickNoForPosQues());
            //Assert.assertTrue(installOptionsPage.isPageDisplayed());
            
            CartSummaryPageModify cartSummaryPage = installOptionsPage.clickContinue();
            Assert.assertNotNull(cartSummaryPage);
            Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
            Assert.assertTrue(cartSummaryPage.ClickYesIBOption()); 
            Assert.assertTrue(cartSummaryPage.ClickCheckout());
            
            PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
           // Assert.assertTrue(personalInfoPage.click911AddressRadio());
            Assert.assertTrue(personalInfoPage.ClickContinueBtn());
            
            com.att.wbfc.OptionalAutopayPageModify optionalAutopayPage = new com.att.wbfc.OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(optionalAutopayPage.isPageDisplayed());
            Assert.assertNotNull(optionalAutopayPage.clickContinueWithoutAutoPay());
                        
            //Assert.assertTrue(optionalAutopayPage.isPageDisplayed());
                       
            ScheduleInstallationPageModify scheduleInstallationPageModify=new ScheduleInstallationPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(scheduleInstallationPageModify.VerifyScheduleInformationPage());
            Assert.assertTrue(scheduleInstallationPageModify.ClickOnContinue());
            
            ReviewOrderPageModify reviewOrderPage = new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

            // Submitting the order is burning the data so leaving it for manual tests 
            //ThankYouPageModify thankYouPage = reviewOrderPage.ClickOnSubmitOrder();
            //Assert.assertNotNull(thankYouPage);
            //Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
        }
    }
    
 // ***************************************************************************************************
    // * NAME : WBFC_Mobile_ProvideExpressHappyPath
    // * AUTHOR : Stefan Andrei
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void WBFC_Mobile_ProvideExpressHappyPath (@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
            
           // Assert.assertTrue(new webservicesWireleine(Dictionary, Environment, Reporter).checkCreditDecisionTypeIsNotValue("TB"));
            driver.manage().window().maximize();
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC") + "availability.html"));
            
            CheckAvailabilityPage checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.IsPageDisplayed());
            Assert.assertTrue(checkAvailabilityPage.EnterStreetAddress());
            Assert.assertTrue(checkAvailabilityPage.EnterUnit());
            Assert.assertTrue(checkAvailabilityPage.EnterZipCode());
            Assert.assertTrue(checkAvailabilityPage.ClickCheckAvailbility());
                        
            
            com.att.mwbfc.GetServicePage getServicePage = new com.att.mwbfc.GetServicePage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(getServicePage.isGetServicePageDisplayed());
            objCommon.fCommonGetCookieValue("SALESSESSIONID");
            Assert.assertTrue(getServicePage.isGetServicePageDisplayed());
            Assert.assertTrue(getServicePage.clickUfamilyTVEliteVoiceOffer());
                        
            
            com.att.mwbfc.OfferDetailsPage offerDetailsPage = new com.att.mwbfc.OfferDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(offerDetailsPage.isOfferDetailsPageDisplayed());
            Assert.assertTrue(offerDetailsPage.clickAddToOrder());
            
            com.att.mwbfc.ConfigurationPage configurationPage = new com.att.mwbfc.ConfigurationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(configurationPage.isConfigurationPageDisplayed());
            Assert.assertTrue(configurationPage.addRecieverForDTV());
            Assert.assertTrue(configurationPage.clickSatelliteDishInstallationOptionYes());
            Assert.assertTrue(configurationPage.clickSelect());
            
            com.att.mwbfc.OrderSummaryPage orderSummaryPage = new com.att.mwbfc.OrderSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(orderSummaryPage.isOrderSummaryPageDisplayed());
            Assert.assertTrue(orderSummaryPage.clickCheckout());
            
            com.att.mwbfc.PersonalInfoPage personalInfoPage = new com.att.mwbfc.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.isPersonalInfoPageDisplayed());

            // Personal information
            Assert.assertTrue(personalInfoPage.enterFirstName(Dictionary.get("FIRSTNAME")));
            Assert.assertTrue(personalInfoPage.enterLastName(Dictionary.get("LASTNAME")));
            Assert.assertTrue(personalInfoPage.enterPrimaryNumber(Dictionary.get("PRIMARYNUMBER")));
            Assert.assertTrue(personalInfoPage.enterEmail(Dictionary.get("EMAIL")));
            Assert.assertTrue(personalInfoPage.reEnterEmail(Dictionary.get("EMAIL")));

            // Account security
            Assert.assertTrue(personalInfoPage.selectDOBmonth(Dictionary.get("MONTH")));
            Assert.assertTrue(personalInfoPage.selectDOBday(Dictionary.get("DAY")));
            Assert.assertTrue(personalInfoPage.selectDOByear(Dictionary.get("YEAR")));
            Assert.assertTrue(personalInfoPage.enterSSN(Dictionary.get("SSN")));
            Assert.assertTrue(personalInfoPage.enterPassCode(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.reEnterPassCode(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.selectSecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            Assert.assertTrue(personalInfoPage.enterSecurityAnswer(Dictionary.get("SECURITYANSWER")));
            
            // Consents
          // Assert.assertTrue(personalInfoPage.clickCheckBoxForOneTimeCharge());
           Assert.assertTrue(personalInfoPage.clickCheckBoxForAttTOS());
            //Assert.assertTrue(personalInfoPage.clickCheckBoxForTermCommitment());
            
            Assert.assertTrue(personalInfoPage.clickContinue());
            
            com.att.mwbfc.AutopayPage autopayPage = new com.att.mwbfc.AutopayPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(autopayPage.isPageDisplayed());
            Assert.assertTrue(autopayPage.enterCardNumber(Dictionary.get("CC_NUMBER")));
            Assert.assertTrue(autopayPage.selectExpirationMonth(Dictionary.get("CC_EXP_MONTH")));
            Assert.assertTrue(autopayPage.selectExpirationYear(Dictionary.get("CC_EXP_YEAR")));
            Assert.assertTrue(autopayPage.enterSecurityCode(Dictionary.get("CC_CVV")));
            Assert.assertTrue(autopayPage.enterNameOnCard(Dictionary.get("FIRSTNAME")+ " " +Dictionary.get("LASTNAME")));
           // Assert.assertTrue(autopayPage.chkSamePaymentMethod());
            Assert.assertTrue(autopayPage.selectTermsCondition());
            Assert.assertTrue(autopayPage.clickContinue());    
            
            com.att.mwbfc.ScheduleInstallationPage scheduleInstallationPage = new com.att.mwbfc.ScheduleInstallationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(scheduleInstallationPage.isScheduleInstallationPageDisplayed());
            Assert.assertTrue(scheduleInstallationPage.selectInstallationTime("9 a.m. to 11 a.m."));
            Assert.assertTrue(scheduleInstallationPage.clickYesInstallDish());            
            Assert.assertTrue(scheduleInstallationPage.clickContinue());

            
            
            com.att.mwbfc.ReviewOrderPage reviewOrderPage = new com.att.mwbfc.ReviewOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewOrderPage.isReviewOrderPageDisplayed());
            Assert.assertTrue(reviewOrderPage.clickSubmitOrder());
            
            com.att.mwbfc.ThankYouPage thankYouPage = new com.att.mwbfc.ThankYouPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(thankYouPage.isThankYouPageDisplayed());
        }
    }
    
    
  //***************************************************************************************************
    //* NAME                : WBFC_Mobile_ModifyExpressHappyPath
    //* AUTHOR              : Stefan Andrei
    //* STATUS              : BLOCKED - The code is not ready yet
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void WBFC_Mobile_ModifyExpressHappyPath(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")) {
            
            driver.manage().deleteAllCookies();

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC")+"login/login.html?wlsfi=MODIFY"));
            
            com.att.mxr.LoginPage loginPage = new com.att.mxr.LoginPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(loginPage.LoginPageIsDisplayed());
        }
    }
    
    
    // ***************************************************************************************************
    // * NAME : GP_Desktop_ProvideHappyPath
    // * AUTHOR : Stefan Andrei
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void GP_Desktop_ProvideHappyPath(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
            
        //    Assert.assertTrue(new webservicesWireleine(Dictionary, Environment, Reporter).checkCreditDecisionTypeIsNotValue("TB"));
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_PROVIDE_URL") + "availability.html"));

            CheckAvailabilityPage checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.IsPageDisplayed());
            Assert.assertTrue(checkAvailabilityPage.EnterStreetAddress());
            Assert.assertTrue(checkAvailabilityPage.SelectUnitType());
            Assert.assertTrue(checkAvailabilityPage.EnterUnit());
            Assert.assertTrue(checkAvailabilityPage.EnterZipCode());
            Assert.assertTrue(checkAvailabilityPage.ClickCheckAvailbility());
            
            
            GigaPowerResponse gigaPowerResponse=new GigaPowerResponse(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(gigaPowerResponse.GigaPowerResponsePageVerification());
            Assert.assertTrue(gigaPowerResponse.ClickShopNowCTA());
            
            ExistingGigapowerServiceModal existingGigapowerServiceModal=new ExistingGigapowerServiceModal(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(existingGigapowerServiceModal.ExistingGigapowerServiceModalIsDisplayed());
            Assert.assertTrue(existingGigapowerServiceModal.SelectImMovingRadioBtn());
            Assert.assertTrue(existingGigapowerServiceModal.ClickContinueCTA());
            
            OffersPage offersPage=new OffersPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(offersPage.OffersPageGigaPowerIsDisplayed());
            objCommon.fCommonGetCookieValue("SALESSESSIONID");
            objCommon.fCommonValidateDynamicPageDisplayed("","");
            
            Assert.assertTrue(offersPage.ClickGigaPowerStandard());
            Assert.assertTrue(offersPage.SelectAnyGPOffer());
            
           
            com.att.wbfc.TvConfigPage tvConfigPage=new com.att.wbfc.TvConfigPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(tvConfigPage.IsConfigTVPageExist());
            
            InstallationAndEquipmentPage installationAndEquipmentPage = tvConfigPage.ClickOnContinueToEquimentIstallationPage();
            Assert.assertNotNull(installationAndEquipmentPage);
            Assert.assertTrue(installationAndEquipmentPage.IsInstallationEquipmentPageExist());
            Assert.assertTrue(installationAndEquipmentPage.selectConnectTVNumber("Connect 1 TV"));
            Assert.assertTrue(installationAndEquipmentPage.ClickAllCheckBoxesGP());
            Assert.assertTrue(installationAndEquipmentPage.ClickContinueToCartSummary());
            
            CartSummaryPage cartSummaryPage=new CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
            
            PersonalInfoPage personalInfoPage=cartSummaryPage.ClickCheckout();
            Assert.assertNotNull(personalInfoPage);
            
            ModalExistingDTVServiceFound existingDTVServiceFound=new ModalExistingDTVServiceFound(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(existingDTVServiceFound.ExistingDSLServiceModalIsDisplayed());
            Assert.assertTrue(existingDTVServiceFound.ClickContinueCTA());
            
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
            Assert.assertTrue(personalInfoPage.IsContactDetailsEmpty());
            Assert.assertTrue(personalInfoPage.EnterFirstName(Dictionary.get("FIRSTNAME")));
            Assert.assertTrue(personalInfoPage.EnterLastName(Dictionary.get("LASTNAME")));
            Assert.assertTrue(personalInfoPage.EnterPrimaryNumber(Dictionary.get("PRIMARYNUMBER")));
            Assert.assertTrue(personalInfoPage.EnterEmail(Dictionary.get("EMAIL")));
            Assert.assertTrue(personalInfoPage.ReEnterEmail(Dictionary.get("EMAIL")));

            // credit information
            Assert.assertTrue(personalInfoPage.SelectDateBirthMonth(Dictionary.get("MONTH")));
            Assert.assertTrue(personalInfoPage.SelectDateBirthDay(Dictionary.get("DAY")));
            Assert.assertTrue(personalInfoPage.SelectDateBirthYear(Dictionary.get("YEAR")));
            Assert.assertTrue(personalInfoPage.EnterSSN(Dictionary.get("SSN")));

            // Account setup
            Assert.assertTrue(personalInfoPage.PassCodeAccountSetUp(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.ReEnterPassCodeForAccountSetup(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.SecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            Assert.assertTrue(personalInfoPage.SecurityAnswer(Dictionary.get("SECURITYANSWER")));
            Assert.assertTrue(personalInfoPage.ClickContinueBtn());
            
            com.att.star.OptionalAutopayPage optionalAutopayPage=new com.att.star.OptionalAutopayPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(optionalAutopayPage.OptionalAutopayPageIsDisplayed());
            Assert.assertTrue(optionalAutopayPage.ClickContinueWithoutAutopay());
            
            
            ScheduleInstallationPage scheduleInstallationPage = new ScheduleInstallationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
            Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());
            
            objCommon.fCommonValidateDynamicPageDisplayed("","");
            
            ReviewOrderPage reviewOrderPage = new ReviewOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());
           
            ThankYouPage thankYouPage = reviewOrderPage.ClickOnSubmitOrder();
            
            objCommon.fCommonValidateDynamicPageDisplayed("","");
                        
            Assert.assertNotNull(thankYouPage);
            Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
        }
    }
    
    //***************************************************************************************************
    //* NAME                : GP_Desktop_ModifyHappyPath
    //* AUTHOR              : Stefan Andrei
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void GP_Desktop_ModifyHappyPath(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")) {
            
            driver.manage().deleteAllCookies();
            driver.manage().window().maximize();
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

            LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(loginPage.LoginPageIsDisplayed());
            Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());
            
            DashboardPageModify dashboardPageModify=new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(dashboardPageModify.isPageDisplayed());
            
            objCommon.fCommonGetCookieValue("SALESSESSIONID");            
           
            Assert.assertTrue(dashboardPageModify.clickChangeHSIA());
            Assert.assertTrue(dashboardPageModify.isPageDisplayed());
            Assert.assertTrue(dashboardPageModify.SelectAnyPlanHSIAGP("1Gbps"));
            
            BeforeYouUpgradeModal beforeYouUpgradeModal=new BeforeYouUpgradeModal(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(beforeYouUpgradeModal.BeforeYouUpgradeModalIsDisplayed());
            Assert.assertTrue(beforeYouUpgradeModal.ClickOkIUnderstandCTA());
           
            Assert.assertTrue(dashboardPageModify.isPageDisplayed());
            
            Assert.assertTrue(dashboardPageModify.clickContinue());
            
            InstallationAndEquipmentPageModify installationAndEquipmentPageModify=new InstallationAndEquipmentPageModify(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(installationAndEquipmentPageModify.isPageDisplayed());
            Assert.assertTrue(installationAndEquipmentPageModify.checkInternetServiceAgreementTC());
            Assert.assertTrue(installationAndEquipmentPageModify.CheckInternetPreferences());
            
            CartSummaryPageModify cartSummaryPageModify=installationAndEquipmentPageModify.clickContinue();
            Assert.assertNotNull(cartSummaryPageModify);
            /*
            UnificationPage unificationPage=new UnificationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(unificationPage.UnificationPageDisplayed());
            Assert.as
            sertTrue(unificationPage.ClickNoThanksCTA());
           */ 
            //Assert.assertTrue(cartSummaryPageModify.ClickYesIBOption());
            //Assert.assertTrue(cartSummaryPageModify.IsCartSummaryDisplayed());
            Assert.assertTrue(cartSummaryPageModify.ClickCheckout());
            
           com.att.wbfc.OptionalAutopayPage optionalAutopayPage=new com.att.wbfc.OptionalAutopayPage(driver, driverType, Dictionary, Environment, Reporter);
           Assert.assertTrue(optionalAutopayPage.OptionalAutopayPageIsDisplayed());
           Assert.assertTrue(optionalAutopayPage.SelectCheckBoxToAgreeAutoPayTerms());
           Assert.assertTrue(optionalAutopayPage.ClickContinueWithoutAutopay());
           
           ScheduleInstallationPageModify scheduleInstallationPageModify=new ScheduleInstallationPageModify(driver, driverType, Dictionary, Environment, Reporter);
           Assert.assertTrue(scheduleInstallationPageModify.VerifyScheduleInformationPage());
           
           Assert.assertTrue(scheduleInstallationPageModify.waitTillAutoFillOfTextBoxes());   
           
           Assert.assertTrue(scheduleInstallationPageModify.EnterPrimaryPhone());
           Assert.assertTrue(scheduleInstallationPageModify.ClickOnContinue());
           
           ReviewOrderPageModify reviewOrderPageModify=new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
           Assert.assertTrue(reviewOrderPageModify.IsReviewOrderPageDisplayed());
            
            // Submitting the order is burning the data so leaving it for manual tests
            //Assert.assertTrue(reviewOrderPage.clickSubmitOrder());
            //com.att.xr.ThankYouPage thankYouPage = new com.att.xr.ThankYouPage(driver, driverType, Dictionary, Environment, Reporter);
            //Assert.assertTrue(thankYouPage.isThankYouPageDisplayed());
        }
    }

 // ***************************************************************************************************
    // * NAME : GP_Mobile_ProvideHappyPath
    // * AUTHOR : Stefan Andrei
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void GP_Mobile_ProvideHappyPath(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
            
            //Assert.assertTrue(new webservicesWireleine(Dictionary, Environment, Reporter).checkCreditDecisionTypeIsNotValue("TB"));
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC") + "availability.html"));

            CheckAvailabilityPage checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.IsPageDisplayed());
            Assert.assertTrue(checkAvailabilityPage.EnterStreetAddress());
            Assert.assertTrue(checkAvailabilityPage.EnterUnit());
            Assert.assertTrue(checkAvailabilityPage.EnterZipCode());
            Assert.assertTrue(checkAvailabilityPage.ClickCheckAvailbility());

            objCommon.fCommonGetCookieValue("SALESSESSIONID");
            
            com.att.mwbfc.GetServicePage getServicePage = new com.att.mwbfc.GetServicePage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(getServicePage.isGetServicePageDisplayed());
            Assert.assertTrue(getServicePage.clickShowMoreBundles());
            Assert.assertTrue(getServicePage.clickUfamilyTVGPVoiceOffer());
                    
            com.att.mwbfc.OfferDetailsPage offerDetailsPage = new com.att.mwbfc.OfferDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(offerDetailsPage.isOfferDetailsPageDisplayed());
            Assert.assertTrue(offerDetailsPage.clickAddToOrder());
            
            com.att.mwbfc.ConfigurationPage configurationPage = new com.att.mwbfc.ConfigurationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(configurationPage.isConfigurationPageDisplayed());
            Assert.assertTrue(configurationPage.addRecieverForDTV());
           // Assert.assertTrue(configurationPage.clickSatelliteDishInstallationOptionYes());
            Assert.assertTrue(configurationPage.clickSelect());
            
            com.att.mwbfc.OrderSummaryPage orderSummaryPage = new com.att.mwbfc.OrderSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(orderSummaryPage.isOrderSummaryPageDisplayed());
            Assert.assertTrue(orderSummaryPage.clickCheckout());
            
            com.att.mwbfc.PersonalInfoPage personalInfoPage = new com.att.mwbfc.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.isPersonalInfoPageDisplayed());

            // Personal information
            Assert.assertTrue(personalInfoPage.enterFirstName(Dictionary.get("FIRSTNAME")));
            Assert.assertTrue(personalInfoPage.enterLastName(Dictionary.get("LASTNAME")));
            Assert.assertTrue(personalInfoPage.enterPrimaryNumber(Dictionary.get("PRIMARYNUMBER")));
            Assert.assertTrue(personalInfoPage.enterEmail(Dictionary.get("EMAIL")));
            Assert.assertTrue(personalInfoPage.reEnterEmail(Dictionary.get("EMAIL")));

            // Account security
            Assert.assertTrue(personalInfoPage.selectDOBmonth(Dictionary.get("MONTH")));
            Assert.assertTrue(personalInfoPage.selectDOBday(Dictionary.get("DAY")));
            Assert.assertTrue(personalInfoPage.selectDOByear(Dictionary.get("YEAR")));
            Assert.assertTrue(personalInfoPage.enterSSN(Dictionary.get("SSN")));
            Assert.assertTrue(personalInfoPage.enterPassCode(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.reEnterPassCode(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.selectSecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            Assert.assertTrue(personalInfoPage.enterSecurityAnswer(Dictionary.get("SECURITYANSWER")));
            
            // Consents
            Assert.assertTrue(personalInfoPage.clickCheckBoxForInternetPreferences());
            Assert.assertTrue(personalInfoPage.clickCheckBoxForAttTOS());
            Assert.assertTrue(personalInfoPage.clickContinue());
            
            com.att.mwbfc.AutopayPage autopayPage = new com.att.mwbfc.AutopayPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(autopayPage.isPageDisplayed());
         /*   Assert.assertTrue(autopayPage.enterCardNumber(Dictionary.get("CC_NUMBER")));
            Assert.assertTrue(autopayPage.selectExpirationMonth(Dictionary.get("CC_EXP_MONTH")));
            Assert.assertTrue(autopayPage.selectExpirationYear(Dictionary.get("CC_EXP_YEAR")));
            Assert.assertTrue(autopayPage.enterSecurityCode(Dictionary.get("CC_CVV")));
            Assert.assertTrue(autopayPage.enterNameOnCard(Dictionary.get("FIRSTNAME")+ " " +Dictionary.get("LASTNAME")));
            Assert.assertTrue(autopayPage.selectTermsCondition());
         */   Assert.assertTrue(autopayPage.clickContinue());                          
            
            com.att.mwbfc.ScheduleInstallationPage scheduleInstallationPage = new com.att.mwbfc.ScheduleInstallationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(scheduleInstallationPage.isScheduleInstallationPageDisplayed());
            Assert.assertTrue(scheduleInstallationPage.selectInstallationTime("9:00 AM to 11:00 AM"));
           // Assert.assertTrue(scheduleInstallationPage.clickYesInstallDish());
            Assert.assertTrue(scheduleInstallationPage.clickYesAlarm());            
            Assert.assertTrue(scheduleInstallationPage.clickContinue());
           
            com.att.mwbfc.ReviewOrderPage reviewOrderPage = new com.att.mwbfc.ReviewOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewOrderPage.isReviewOrderPageDisplayed());
            Assert.assertTrue(reviewOrderPage.clickSubmitOrder());
            
            com.att.mwbfc.ThankYouPage thankYouPage = new com.att.mwbfc.ThankYouPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(thankYouPage.isThankYouPageDisplayed());
            
            
        }
    }
    
    //***************************************************************************************************
    //* NAME                : GP_Mobile_ModifyHappyPath
    //* AUTHOR              : Stefan Andrei
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void GP_Mobile_ModifyHappyPath(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")) {
            
            driver.manage().deleteAllCookies();

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC")+"login/login.html?wlsfi=MODIFY"));

            com.att.mxr.LoginPage loginPage = new com.att.mxr.LoginPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(loginPage.LoginPageIsDisplayed());
//            Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());
//            
//            GetServicePage getServicePage = new GetServicePage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(getServicePage.isGetServicePageDisplayed());
//            Assert.assertTrue(getServicePage.clickSelectDoubleTV());
//            
//            OfferDetailsPage offerDetailsPage = new OfferDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(offerDetailsPage.isOfferDetailsPageDisplayed());
//            Assert.assertTrue(offerDetailsPage.clickSelect());
//            
//            ConfigurationPage configurationPage=new ConfigurationPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(configurationPage.isConfigurationPageDisplayed());
//            Assert.assertTrue(configurationPage.clickAddToOrder());           
//            
//           //Insert the new page verify.
//            
//            OrderSummaryPage orderSummaryPage = new OrderSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(orderSummaryPage.isOrderSummaryPageDisplayed());
//            Assert.assertTrue(orderSummaryPage.clickBeginCheckout());
//            
//            com.att.xr.PersonalInfoPage personalInfoPage = new com.att.xr.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(personalInfoPage.isPersonalInfoPageDisplayed());
//            Assert.assertTrue(personalInfoPage.enterPrimaryNumber(Dictionary.get("PRIMARYNUMBER")));
//            Assert.assertTrue(personalInfoPage.clickCheckBoxForConsentAttInternetPrefs());
//            Assert.assertTrue(personalInfoPage.clickCheckBoxForAttTOS());
//            Assert.assertTrue(personalInfoPage.clickContinue());
//            
//            AutopayPage autopayPage = new AutopayPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(autopayPage.isAutopayPageDisplayed());
//            Assert.assertTrue(autopayPage.clickCheckBoxSignUpForAutopay());
//            Assert.assertTrue(autopayPage.clickCheckBoxSignUpForAutopay());
//            Assert.assertTrue(autopayPage.isAutopayPageDisplayed());
//            Assert.assertTrue(autopayPage.clickContinue());
//            
//            com.att.xr.ScheduleInstallationPage scheduleInstallationPage = new com.att.xr.ScheduleInstallationPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(scheduleInstallationPage.isScheduleInstallationPageDisplayed());
//            Assert.assertTrue(scheduleInstallationPage.enterFirstName(Dictionary.get("FIRSTNAME")));
//            Assert.assertTrue(scheduleInstallationPage.enterLastName(Dictionary.get("LASTNAME")));
//            Assert.assertTrue(scheduleInstallationPage.clickContinue());
//            
//            com.att.xr.ReviewOrderPage reviewOrderPage = new com.att.xr.ReviewOrderPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(reviewOrderPage.isReviewOrderPageDisplayed());
            
            // Submitting the order is burning the data so leaving it for manual tests
            //Assert.assertTrue(reviewOrderPage.clickSubmitOrder());
            //com.att.xr.ThankYouPage thankYouPage = new com.att.xr.ThankYouPage(driver, driverType, Dictionary, Environment, Reporter);
            //Assert.assertTrue(thankYouPage.isThankYouPageDisplayed());
        }
    }
    
    
    // ***************************************************************************************************
    // * NAME : HR_Desktop_ValidateMaps
    // * AUTHOR : Naveena Basetty
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void HR_Desktop_ValidateMaps (@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("") && !Dictionary.get("SKIP_" + driverType).equals("null")) {
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt("http://" + Environment.get("TRANSITION_HOST_2") + "/maps/store-locator.html"));
            
            ATTStoreLocations attstorelocations = new ATTStoreLocations(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(attstorelocations.verifyAttStoreLocationsPageExist());
            
            // chose a random zipcode from list
            String[] zips = {"98101", "10010", "75202", "30303"};
            Assert.assertTrue(attstorelocations.enterZip(zips[new Random().nextInt(4)]));
            
            Assert.assertTrue(attstorelocations.verifyAttStoreLocationsPageExist());
            Assert.assertTrue(attstorelocations.clickSearch());
            Assert.assertTrue(attstorelocations.checkIfSearchResultsDisplayed());
            PrintMapLocators printmaplocators = attstorelocations.clickOnStoreDetails();
            Assert.assertTrue(printmaplocators.validatePrintMapLocatorPage());
            Assert.assertTrue(printmaplocators.verifyMapPageComponents());
            Assert.assertTrue(printmaplocators.goBackToSearchResults());
            Assert.assertTrue(attstorelocations.verifyAttStoreLocationsPageExist());
            StoreDirections storedirections = attstorelocations.ClickOnGetDirections();
            Assert.assertTrue(storedirections.verifyEmailTextForm("Email"));
            Assert.assertTrue(storedirections.clickOnCloseModal());
            Assert.assertTrue(storedirections.verifyEmailTextForm("Text"));
        }
    }
    
    // ***************************************************************************************************
    // * NAME : HR_Mobile_ValidateMaps
    // * AUTHOR : Stefan Andrei
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void HR_Mobile_ValidateMaps(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("") && !Dictionary.get("SKIP_" + driverType).equals("null")) {
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC") + "find-a-store.html"));
            
            ATTFindAStore attFindAStore = new ATTFindAStore(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(attFindAStore.isATTFindAStorePageDisplayed());
            
            // chose a random zipcode from list
            String[] zips = {"98101", "10010", "75202", "30303"};
            Assert.assertTrue(attFindAStore.enterZip(zips[new Random().nextInt(4)]));
            
            ATTFindAStoreResults attFindAStoreResults = attFindAStore.clickFindAStore();
            Assert.assertTrue(attFindAStoreResults.isATTFindAStoreResultsPageDisplayed());
            Assert.assertTrue(attFindAStoreResults.isSearchResultsDisplayed());
            
            objCommon.fCommonValidateDynamicPageDisplayed("","");
            
            ATTFindAStoreDetails attFindAStoreDetails = attFindAStoreResults.ClickOnStoreDetails();
            Assert.assertTrue(attFindAStoreDetails.isATTFindAStoreDetailsPageDisplayed());
            Assert.assertTrue(attFindAStoreDetails.validateStoreDetails());
            Assert.assertNotNull(attFindAStoreDetails.clickOnBackToResults());
            
            Assert.assertTrue(attFindAStoreResults.isATTFindAStoreResultsPageDisplayed());
            ATTFindAStoreDirections attFindAStoreDirections = attFindAStoreResults.ClickOnGetDirections();
            Assert.assertTrue(attFindAStoreDirections.isATTFindAStoreDirectionsPageDisplayed());
            Assert.assertTrue(attFindAStoreDirections.isMapDisplayed());
        }
    }
    
    // ***************************************************************************************************
    // * NAME : Star_Desktop_ExistingWirelessNewDTV
    // * AUTHOR : Stefan Andrei
    //* Modified : Abhigyan Dwivedi
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void Star_Desktop_ExistingWirelessNewDTV(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
            
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_NC") + "unified/authentication.html"));

            AuthenticationPage authenticationPage = new AuthenticationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(authenticationPage.IsPageDisplayed());
            Assert.assertTrue(authenticationPage.SelectAccountType("wireless"));
            Assert.assertTrue(authenticationPage.IsSelectedAccountTypeDisplayed("Wireless"));
            Assert.assertTrue(authenticationPage.EnterUserId("wireless", Dictionary.get("WIRELESS_UID")));
            Assert.assertTrue(authenticationPage.EnterPassword("wireless", Dictionary.get("PASSWORD")));
            Assert.assertTrue(authenticationPage.ClickOnLogIn("Wireless"));
            //Assert.assertTrue(authenticationPage.EnterPasscode("wireless", Dictionary.get("WIRELESS_PASSCODE")));
            //Assert.assertTrue(authenticationPage.ClickOnContinueToValidatePasscode());
            Assert.assertTrue(authenticationPage.waitForContinueWhenWirelessLoginSucceeds());
            Assert.assertTrue(authenticationPage.ClickOnContinueWhenWirelessLoginSucceeds());

            com.att.star.CheckAvailabilityPage checkAvailabilityPage = new  com.att.star.CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.isPageDisplayed());
            Assert.assertTrue(checkAvailabilityPage.getSalesSessionID());
            Assert.assertTrue(checkAvailabilityPage.EnterZipCode(Dictionary.get("ZIP_CODE")));
            Assert.assertTrue(checkAvailabilityPage.EnterStreetAddress(Dictionary.get("STREET_ADDRESS")));
            Assert.assertTrue(checkAvailabilityPage.EnterUnitNumber(Dictionary.get("UNIT_NUMBER")));
            Assert.assertTrue(checkAvailabilityPage.ClickCheckAvailbility());
            
            objCommon.fCommonGetCookieValue("SALESSESSIONID");

            OffersPage offersPage = new OffersPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(offersPage.OffersPageStarIsDisplayed());
            //Assert.assertTrue(offersPage.ClickDirectTvStandard());
            Assert.assertTrue(offersPage.OffersPageStarIsDisplayed());
            Assert.assertTrue(offersPage.SelectAnyOffer());

            TvConfigPage tvConfigPage = new TvConfigPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(tvConfigPage.IsConfigTVPageExist());

            com.att.star.InstallationAndEquipmentPage installationAndEquipmentPage = tvConfigPage.ClickOnContinueToEquimentIstallationPage();
            Assert.assertNotNull(installationAndEquipmentPage);
            Assert.assertTrue(installationAndEquipmentPage.IsInstallationEquipmentPageExist());
            Assert.assertTrue(installationAndEquipmentPage.selectConnectTVNumber("Connect 1 TV"));
            Assert.assertTrue(installationAndEquipmentPage.IsInstallationEquipmentPageExist());
            Assert.assertTrue(installationAndEquipmentPage.checkAllTerms());
            //Assert.assertTrue(installationAndEquipmentPage.checkRadioForDish());
            Assert.assertTrue(installationAndEquipmentPage.ClickContinueToCartSummary());
            
            com.att.star.CartSummaryPage cartSummaryPage = new com.att.star.CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
            //Assert.assertTrue(cartSummaryPage.SelectIBRadioOption("YES"));
            Assert.assertTrue(cartSummaryPage.ClickCheckout());

            com.att.star.PersonalInfoPage personalInfoPage = new com.att.star.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());

            // contact information
            Assert.assertTrue(personalInfoPage.EnterPrimaryNumber(Dictionary.get("PRIMARYNUMBER")));
            Assert.assertTrue(personalInfoPage.EnterFirstName(Dictionary.get("FIRSTNAME")));
            Assert.assertTrue(personalInfoPage.EnterLastName(Dictionary.get("LASTNAME")));
            Assert.assertTrue(personalInfoPage.EnterEmail(Dictionary.get("EMAIL")));
            Assert.assertTrue(personalInfoPage.ReEnterEmail(Dictionary.get("EMAIL")));

            // Account setup
            Assert.assertTrue(personalInfoPage.PassCodeAccountSetUp(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.ReEnterPassCodeForAccountSetup(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.SecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            Assert.assertTrue(personalInfoPage.SecurityAnswer(Dictionary.get("SECURITYANSWER")));


            Assert.assertTrue(personalInfoPage.ClickContinueBtn());
            
            //Environment.put("HIDE_TEST_DATA",null);
            
            AutoPayStarPage autoPayPages=new AutoPayStarPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(autoPayPages.AutopayPageForDTVIsDisplayed());
            Assert.assertTrue(autoPayPages.EnterCreditCardDetails());
            //Assert.assertTrue(autoPayPages.EnterNameOnCard());
            //Assert.assertTrue(autoPayPages.ClickOnTOSAutoPayPage());
            Assert.assertTrue(autoPayPages.ClickBtnContinue());

            com.att.star.ScheduleInstallationPage scheduleInstallationPage = new com.att.star.ScheduleInstallationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
            Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

            com.att.star.ReviewOrderPage reviewOrderPage = new com.att.star.ReviewOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

            //ThankYouPage thankYouPage = reviewOrderPage.ClickOnSubmitOrder(); // commented to prevent burning data
            //Assert.assertNotNull(thankYouPage);
            //Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
        
        }
    }
    
    
    // ***************************************************************************************************
    // * NAME : Star_Desktop_ExistingWirelessNewUverse
    // * AUTHOR : Stefan Andrei
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void Star_Desktop_ExistingWirelessNewUverse(@Optional("") String browser) {
        
        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
            //2142638954
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_NC") + "unified/authentication.html"));
            
            AuthenticationPage authenticationPage = new AuthenticationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(authenticationPage.IsPageDisplayed());
            Assert.assertTrue(authenticationPage.SelectAccountType("wireless"));
            Assert.assertTrue(authenticationPage.IsSelectedAccountTypeDisplayed("Wireless"));
            Assert.assertTrue(authenticationPage.EnterUserId("wireless", Dictionary.get("WIRELESS_UID")));
            Assert.assertTrue(authenticationPage.EnterPassword("wireless", Dictionary.get("PASSWORD")));
            Assert.assertTrue(authenticationPage.ClickOnLogIn("Wireless"));
            //Assert.assertTrue(authenticationPage.EnterPasscode("Wireless", Dictionary.get("WIRELESS_PASSCODE")));
            //Assert.assertTrue(authenticationPage.ClickOnContinueToValidatePasscode());  
            Assert.assertTrue(authenticationPage.waitForContinueWhenWirelessLoginSucceeds());
            Assert.assertTrue(authenticationPage.ClickOnContinueWhenWirelessLoginSucceeds());

            com.att.star.CheckAvailabilityPage checkAvailabilityPage = new  com.att.star.CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.isPageDisplayed());
            Assert.assertTrue(checkAvailabilityPage.getSalesSessionID());
            Assert.assertTrue(checkAvailabilityPage.EnterZipCode(Dictionary.get("ZIP_CODE")));
            Assert.assertTrue(checkAvailabilityPage.EnterStreetAddress(Dictionary.get("STREET_ADDRESS")));
            Assert.assertTrue(checkAvailabilityPage.EnterUnitNumber(Dictionary.get("UNIT_NUMBER")));
            Assert.assertTrue(checkAvailabilityPage.ClickCheckAvailbility());
                        
            objCommon.fCommonGetCookieValue("SALESSESSIONID"); 
            
            OffersPage offersPage = new OffersPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(offersPage.OffersPageStarIsDisplayed());
            Assert.assertTrue(offersPage.ClicBYOBCTA());
            
            
            BYOBPage byobPage=new BYOBPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(byobPage.BYOBPageIsDisplayed());
           
            Assert.assertTrue(byobPage.ClickSelectIPTVButton());
            Assert.assertTrue(byobPage.BYOBPageIsDisplayed());
            Assert.assertTrue(byobPage.ClickShowMoreOptions());
            Assert.assertTrue(byobPage.BYOBPageIsDisplayed());
            Assert.assertTrue(byobPage.ClickUVerseRadioOption());
            Assert.assertTrue(byobPage.BYOBPageIsDisplayed());
            Assert.assertTrue(byobPage.SelectAnyTVPlan());
            
            Assert.assertTrue(byobPage.ClickSelectHSIAButton());
            Assert.assertTrue(byobPage.SelectHSIA("any"));
            Assert.assertTrue(byobPage.ClickContinueCTA());
           
            
            TvConfigPage tvConfigPage = new TvConfigPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(tvConfigPage.IsConfigTVPageExist());

            com.att.star.InstallationAndEquipmentPage installationAndEquipmentPage = tvConfigPage.ClickOnContinueToEquimentIstallationPage();
            Assert.assertNotNull(installationAndEquipmentPage);
            Assert.assertTrue(installationAndEquipmentPage.IsInstallationEquipmentPageExist());
            Assert.assertTrue(installationAndEquipmentPage.checkAllTerms());
            Assert.assertTrue(installationAndEquipmentPage.selectConnectTVNumberUverse("Connect 1 TV"));
            Assert.assertTrue(installationAndEquipmentPage.ClickAddTotalHomeDVRPlusReciever());
            Assert.assertTrue(installationAndEquipmentPage.IsInstallationEquipmentPageExist());
            Assert.assertTrue(installationAndEquipmentPage.ClickContinueToCartSummary());
            
            /*ModalAdditionalReceiversPage modalAdditionalReceiversPage=new ModalAdditionalReceiversPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(modalAdditionalReceiversPage.isModalAdditionalReceiversPageDisplayed());
            Assert.assertTrue(modalAdditionalReceiversPage.clickContinueWithMyOrder());
            */

            com.att.star.CartSummaryPage cartSummaryPage = new com.att.star.CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            
            Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
            Assert.assertTrue(cartSummaryPage.SelectIBRadioOption("YES"));
            Assert.assertTrue(cartSummaryPage.ClickCheckout());
                      
            com.att.star.PersonalInfoPage personalInfoPage = new com.att.star.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());

            // contact information
            Assert.assertTrue(personalInfoPage.EnterPrimaryNumber(Dictionary.get("PRIMARYNUMBER")));

            // Account setup
            Assert.assertTrue(personalInfoPage.PassCodeAccountSetUp(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.ReEnterPassCodeForAccountSetup(Dictionary.get("PASSCODE")));
            Assert.assertTrue(personalInfoPage.SecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            Assert.assertTrue(personalInfoPage.SecurityAnswer(Dictionary.get("SECURITYANSWER")));
            Assert.assertTrue(personalInfoPage.EnterEmail(Dictionary.get("EMAIL")));
            Assert.assertTrue(personalInfoPage.ReEnterEmail(Dictionary.get("EMAIL")));
            Assert.assertTrue(personalInfoPage.ClickContinueBtn());
            
            ModalAdditionalCreditInformation ModalAdditionalCreditInformation = new ModalAdditionalCreditInformation(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(ModalAdditionalCreditInformation.IsModalDisplayed());
            Assert.assertTrue(ModalAdditionalCreditInformation.SelectDateBirth("November", "28", "1950"));
            Assert.assertTrue(ModalAdditionalCreditInformation.EnterSSN("326000094"));
            Assert.assertTrue(ModalAdditionalCreditInformation.ClickContinueBtn());
            
           //Code to handle Optional Autopay page          
            com.att.star.OptionalAutopayPage optionalAutopayPage=new com.att.star.OptionalAutopayPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(optionalAutopayPage.OptionalAutopayPageIsDisplayed());
            Assert.assertTrue(optionalAutopayPage.ClickContinueWithoutAutopay());
            
            // Code to complete when system is <up>
            com.att.star.ScheduleInstallationPage scheduleInstallationPage = new com.att.star.ScheduleInstallationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
            Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

            com.att.star.ReviewOrderPage reviewOrderPage = new com.att.star.ReviewOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

            //ThankYouPage thankYouPage = reviewOrderPage.ClickOnSubmitOrder(); // commented to prevent burning data
            //Assert.assertNotNull(thankYouPage);
            //Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
        }
    }
    
    
    @Parameters({ "browser" })
    @AfterMethod
    public void afterMethod(Method method, ITestResult result, @Optional("") String browser) throws Exception {

        driverType = browser;
        try {
            if (Dictionary.get("SKIP_" + driverType).equals("") && !Dictionary.get("SKIP_" + driverType).equals("null")) {
                System.out.println("AfterMethod begin - " + method.getName());
                // String status;

                if (result.getStatus() == ITestResult.SUCCESS) {
                    Dictionary.put("RESULT_" + driverType, "P");
                } else if (result.getStatus() == ITestResult.FAILURE) {
                    Dictionary.put("RESULT_" + driverType, "F");
                    // In case of failure adding a line because sometimes tests die in between and are marked as passed but they are actually failed
                    if(CommonFunctions.exceptionToString(result.getThrowable())!=null){
                        Reporter.fnWriteToHtmlOutput("Testng afterMethod hook", "FAILED", "Exception: " + CommonFunctions.exceptionToString(result.getThrowable()), "Fail");
                    }
                } else {
                    Dictionary.put("RESULT_" + driverType, "N");
                    System.out.println("Invalid Status");
                }
                System.out.println("Result - " + driverType + " - " + result.toString());

                // Close Summary Report
                Reporter.fnCloseHtmlReport();

                System.out.println("AfterMethod end - " + driverType);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception " + Dictionary.get("TEST_NAME_" + driverType) + driverType + ": " + e.toString());
        }

        // Quit Driver
        if (driver != null) {
            try {
                driver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    @AfterClass
    public void afterClass() {
        try {
            Reporter.fnCloseTestSummary();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception " + Dictionary.get("TEST_NAME_" + driverType) + driverType + ": " + e.toString());
        }
    }
}
