package com.att.functional.smoke;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.att.framework.CommonFunctions;
import com.att.framework.Driver;
import com.att.framework.Driver.HashMapNew;
import com.att.framework.Reporting;
import com.att.hrock.AccessoriesDetailsPage;
import com.att.hrock.AccessoriesListPage;
import com.att.hrock.AccessoryCategoryPage;
import com.att.hrock.AccountOverviewPage;
import com.att.hrock.BuyFlowDeviceConfigurator;
import com.att.hrock.BuyFlowPlanConfigurator;
import com.att.hrock.CartSummaryPage;
import com.att.hrock.DeviceDetailsPage;
import com.att.hrock.DeviceListPageSmartphone;
import com.att.hrock.EmptyCart;
import com.att.hrock.ExpressUpgrade;
import com.att.hrock.GlobalNavMenu;
import com.att.hrock.IntentModal;
import com.att.hrock.JoinGroupPage;
import com.att.hrock.LoginFromOlamHardrock;
import com.att.hrock.LoginPage;
import com.att.hrock.MyWirelessCart;
import com.att.hrock.PersonalInfoPage;
import com.att.hrock.PhoneNumberDetailsPage;
import com.att.hrock.ReviewAndSubmitOrderPage;
import com.att.hrock.ServicesListPage;
import com.att.hrock.ShopLandingPage;
import com.att.hrock.SliResultsPage;
import com.att.hrock.ThankYouOrderPage;
import com.att.hrock.UpgradeYourDevicePage;
import com.att.hrock.ZipCodeModal;
import com.att.hrock.ZipModalForSli;
import com.att.mhr.AccessoryDetailsPage;
import com.att.mhr.AccessoryListPage;
import com.att.mhr.AccessoryOnlyPage;
import com.att.mhr.AddALinePage;
import com.att.mhr.CommitmentTermPage;
import com.att.mhr.DSSLoginPage;
import com.att.mhr.DeviceCatagoryPage;
import com.att.mhr.DeviceFiltersPage;
import com.att.mhr.DeviceListPage;
import com.att.mhr.GetStartedPage;
import com.att.mhr.GlobalNavShopAttPage;
import com.att.mhr.LocalizationPage;
import com.att.mhr.MobileShareHubPage;
import com.att.mhr.MobileShareValuePlansListPage;
import com.att.mhr.MyAttOverviewPage;
import com.att.mhr.NextTermPage;
import com.att.mhr.PaymentInfoPage;
import com.att.mhr.PlansAndServicesPage;
import com.att.mhr.ProtectionServicesPage;
import com.att.mhr.RecommendedAccessoriesPage;
import com.att.mhr.SelectYourNumberPage;
import com.att.mhr.ShippingInfoPage;
import com.att.mhr.ShopMobileIndexPage;
import com.att.mhr.ShopMobileLandingPage;
import com.att.mhr.ShopMobileLoginPage;
import com.att.mhr.UpdateYourDevicePage;
import com.att.star.AuthenticationPage;
import com.att.star.CheckAvailabilityPage;
import com.att.star.HubPage;

public class HardRockSmokeTest {

    HashMap<String, String> Environment = new HashMap<String, String>();
    HashMapNew Dictionary = new HashMapNew();
    Reporting Reporter;

    // Instances
    Driver d;
    WebDriver driver;
    String driverType;
    CommonFunctions objCommon;
    boolean bSkip;
    int TestCounter = 0;
    ITestResult result;
    String env;
    String runOnEnv;
    String browser;

    @Parameters({ "browser", "envcode" })
    @BeforeClass
    public void beforeClass(@Optional("") String browser, @Optional("") String runOnEnv) {
        try {
            driverType = browser;
            Environment.put("CLASS_NAME", this.getClass().getSimpleName());
            d = new Driver(driverType, Dictionary, Environment);
            env = System.getProperty("envName");
            if (env == null) {
                env = runOnEnv;
            }
            Assert.assertNotNull(env);
            // Add env global environments
            Environment.put("ENV_CODE", env);

            // Get the skiped cells
            d.getSkipedCells();
            d.fetchEnvironmentDetails(); // from Environment.xlsx
            if(System.getProperty("dataCenter")!=null){
                Environment.put("SET_COOKIES_REGION",System.getProperty("dataCenter"));
            }
            d.createExecutionFolders(Environment.get("CLASS_NAME"));
            Reporter = new Reporting(driver, driverType, Dictionary, Environment);
            Reporter.fnCreateSummaryReport();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Parameters({ "browser" })
    @BeforeMethod
    public void beforeMethod(@Optional("") String browser, Method method) {
        try {
            String action = method.getName();
            d.fGetDataForTest(action, Environment.get("CLASS_NAME"));
            if(Dictionary.get("HIDE_TEST_DATA")!=null && Dictionary.get("HIDE_TEST_DATA")!=""){
                Environment.put("HIDE_TEST_DATA",Dictionary.get("HIDE_TEST_DATA"));
            }
            if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
                driver = d.fGetWebDriver(driverType, action);
                d.fGuiHandleAuth(browser);
                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                Reporter.driver = driver;
                Reporter.fnCreateHtmlReport(Dictionary.get("TEST_NAME"));
                objCommon = new CommonFunctions(driver, driverType, Environment, Reporter);
                Dictionary.put("TEST_NAME_" + driverType, Dictionary.get("TEST_NAME"));

                // position the window so it doesn't cover the screen margins
                driver.manage().window().setPosition(new Point(32,32));
                // if it is running from Ant and in Chrome browser set the window to a huge size 
                // so the screenshot contains the whole page, not only the visible part
                if(System.getProperty("envName") != null && driverType.toLowerCase().contains("chrome")) {
                    driver.manage().window().setSize(new Dimension(1100, 10000)); // adjust to a huge window height
                } else {
                    driver.manage().window().setSize(new Dimension(1100, 800)); // just adjust the width so there is no horizontal scroll
                }
            }else{
                throw new SkipException("Skipping test: "+ method.getName());
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    // ***************************************************************************************************
    // * NAME : HR_Desktop_NC_NewWirelessLine
    // * AUTHOR : Abhigyan Dwivedi
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void HR_Desktop_NC_NewWirelessLine(@Optional("") String browser) {

        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_NC")+"index.html"));

            ShopLandingPage ShopLandingPage = new ShopLandingPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(ShopLandingPage.IsShopLandingPageDisplayed());
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");
            Assert.assertTrue(ShopLandingPage.SelectCategoryLink("Smartphones"));

            DeviceListPageSmartphone DeviceListPageSmartphone = new DeviceListPageSmartphone(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(DeviceListPageSmartphone.DeviceListPageIsDisplayed());

            DeviceDetailsPage DeviceDetailsPage = DeviceListPageSmartphone.ViewButtonClickForDevice(Dictionary.get("DEVICE"));
            Assert.assertNotNull(DeviceDetailsPage);
            Assert.assertTrue(DeviceDetailsPage.BFOIsDeviceDetailsPageDisplayed());
            Assert.assertTrue(DeviceDetailsPage.BFOClickOnContinuebutton());

            IntentModal IntentModal = new IntentModal(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(IntentModal.IntentPageIsDisplayed());
            Assert.assertTrue(IntentModal.SelectIntentAsNewCustomer());

            BuyFlowDeviceConfigurator buyFlowDeviceConfigurator = new BuyFlowDeviceConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(buyFlowDeviceConfigurator.DeviceConfiguratorPageExist());

            //Assert.assertTrue(buyFlowDeviceConfigurator.SelectCommitmentTerm(Dictionary.get("CONTRACT_LENGTH")));
            Assert.assertTrue(buyFlowDeviceConfigurator.SelectInsuranceOptions(Dictionary.get("REQUIRED_SERVICE")));
            Assert.assertTrue(buyFlowDeviceConfigurator.ClickContinue());

            ZipCodeModal ZipCodeModal = new ZipCodeModal(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(ZipCodeModal.IsZipCodeModalDisplayed());
            Assert.assertTrue(ZipCodeModal.EnterZipInZipCodeModal());

            BuyFlowPlanConfigurator byFlowPlanConfigurator = new BuyFlowPlanConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(byFlowPlanConfigurator.PlanConfiguratorPageDisplayed());            
            //Assert.assertTrue(byFlowPlanConfigurator.SelectDataPlanFromVisibleRadioButton(Dictionary.get("PLAN")));

            CartSummaryPage CartSummaryPage = byFlowPlanConfigurator.ClickContinue();
            Assert.assertNotNull(CartSummaryPage);
            Assert.assertTrue(CartSummaryPage.CartSummaryPageIsDisplayed());
            Assert.assertTrue(CartSummaryPage.ClickCheckoutButton());           

            PersonalInfoPage PersonalInfoPage  = new PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            //Assert.assertTrue(PersonalInfoPage.PersonalInfo());
            Assert.assertTrue(PersonalInfoPage.EnterFirstName());
            Assert.assertTrue(PersonalInfoPage.EnterLastName());
            Assert.assertTrue(PersonalInfoPage.EnterPrimaryNumber());
            Assert.assertTrue(PersonalInfoPage.EnterEmail());
            Assert.assertTrue(PersonalInfoPage.EnterBillingAddress1());
            Assert.assertTrue(PersonalInfoPage.EnterBillingCity());
            Assert.assertTrue(PersonalInfoPage.SelectBillingState());
            Assert.assertTrue(PersonalInfoPage.EnterBillingZIP());            
            Assert.assertTrue(PersonalInfoPage.ContinueToNextStepToVerifyAddress());
            Assert.assertTrue(PersonalInfoPage.ValidateBillAddrVerifiedSuccessfully());
            Assert.assertTrue(PersonalInfoPage.CreditInfo());
            Assert.assertTrue(PersonalInfoPage.EnterCreditCardDetails());
            Assert.assertTrue(PersonalInfoPage.ClickContinueOnPersonalInfoPage());

            PhoneNumberDetailsPage PhoneNumberDetailsPage = new PhoneNumberDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PhoneNumberDetailsPage.PhoneNumberDetailsPageIsDisplayed());
            Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaCode(1,Dictionary.get("AREA_CODE")));
            //Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaName(1,Dictionary.get("SERVICE_CITY")));

            ReviewAndSubmitOrderPage ReviewAndSubmitOrderPage = PhoneNumberDetailsPage.SelectContinuePhoneNumberDetailsPage();
            Assert.assertNotNull(ReviewAndSubmitOrderPage);
            Assert.assertTrue(ReviewAndSubmitOrderPage.IsPageDisplayed());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForElectronicConsent());
            Assert.assertTrue(ReviewAndSubmitOrderPage.selectCheckBoxForRetailInstallmentAgreement());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForWirelessCustomerAgreement());

            ThankYouOrderPage thankYouOrderPage = ReviewAndSubmitOrderPage.ClickSubmitOrder();
            Assert.assertNotNull(thankYouOrderPage);
            Assert.assertTrue(thankYouOrderPage.ThankyouPageIsDisplayed());


        }
    }

    // ***************************************************************************************************
    // * NAME : HR_Desktop_EC_AddWirelessLine
    // * AUTHOR : Abhigyan Dwivedi
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void HR_Desktop_EC_AddWirelessLine(@Optional("") String browser) {

        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
            
            DeviceListPageSmartphone deviceListPage=null;

            if(Environment.get("ENV_CODE").equals("FS")){
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_OLAM")));
                
                LoginFromOlamHardrock loginFromOlamHardrock = new LoginFromOlamHardrock(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(loginFromOlamHardrock.EnterUserID());
                Assert.assertTrue(loginFromOlamHardrock.EnterPassword());
                Assert.assertTrue(loginFromOlamHardrock.ClickLoginButton());

                AccountOverviewPage accountOverviewPage = loginFromOlamHardrock.HandlePagesTillAccountOverview();
                Assert.assertNotNull(accountOverviewPage);
                //Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
                Assert.assertTrue(objCommon.fCommonSetCookieDomain("tutG"));
                Assert.assertTrue(objCommon.fCommonSetCookieDomain("TG-PD-ID"));

                GlobalNavMenu globalNavMenu = new GlobalNavMenu(driver, driverType, Dictionary, Environment, Reporter);

                deviceListPage = globalNavMenu.ClickAddADeviceGlobalNav();
            }else{
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_EC")));
                
                LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(loginPage.LoginPageIsDisplayed());

                IntentModal intentModal = loginPage.ClickOnUserField();
                Assert.assertNotNull(intentModal);
                Assert.assertTrue(intentModal.IntentPageIsDisplayed());
                Assert.assertTrue(intentModal.SelectIntentAsAddANewDevice());
                Assert.assertTrue(loginPage.LoginPageIsDisplayed());
                Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

                deviceListPage = new DeviceListPageSmartphone(driver, driverType, Dictionary, Environment, Reporter);
            }           

            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            Assert.assertNotNull(deviceListPage);
            Assert.assertTrue(deviceListPage.DeviceListPageIsDisplayed());
            
            MyWirelessCart myWirelessCart = new MyWirelessCart (driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(myWirelessCart.isDisplayed());
            if(!myWirelessCart.isEmpty()){
                Assert.assertTrue(myWirelessCart.clickMyWirelessCart());
                
                CartSummaryPage cartSummaryPage = new CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(cartSummaryPage.CartSummaryPageIsDisplayed());

                EmptyCart emptyCart = cartSummaryPage.ClickEmptyCart();
                Assert.assertTrue(emptyCart.ValidateEmptyCartModalExist());
                cartSummaryPage = emptyCart.ClickContinueButton();
                
                Assert.assertTrue(cartSummaryPage.waitForThereAreNoItemsInYourCart());
                
                DeviceListPageSmartphone deviceListPageSmartphone=cartSummaryPage.ClickContinueShoppingButton();
                Assert.assertNotNull(deviceListPageSmartphone);
                Assert.assertTrue(deviceListPageSmartphone.DeviceListPageIsDisplayed());
                
            }

            DeviceDetailsPage DeviceDetailsPage = deviceListPage.ViewButtonClickForDevice(Dictionary.get("DEVICE"));
            Assert.assertNotNull(DeviceDetailsPage);
            Assert.assertTrue(DeviceDetailsPage.BFOIsDeviceDetailsPageDisplayed());
            Assert.assertTrue(DeviceDetailsPage.BFOClickOnContinuebutton());

            //control element for Intent Modal or BuyFlow Configurator Device
            String controlElementXPath = "xpath:=//input[@id='addaline'] | //div[@ng-controller='breadCrumbsController']//*[contains(text(),'Device Configurator')]";

            // wait for page to load first, since we don't know the page yet using an object unique to each page (IntentModal and BuyFlow Configurator Device) 
            objCommon.fCommonValidateDynamicPageDisplayed(controlElementXPath, "");

            // if Intent Modal is displayed press Add a Line again
            if (objCommon.fCommonGetObject(controlElementXPath, 
                    "Add a Line button on IntentModalPage or BuyFlow Configurator Device").getAttribute("id").equalsIgnoreCase("addaline")) {
                IntentModal intentModal= new IntentModal(driver, driverType, Dictionary, Environment, Reporter);
                //Assert.assertTrue(intentModal.IntentPageIsDisplayed());
                Assert.assertTrue(intentModal.SelectIntentAsAddANewDevice());
            }           

            BuyFlowDeviceConfigurator buyFlowDeviceConfigurator = new BuyFlowDeviceConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(buyFlowDeviceConfigurator.DeviceConfiguratorPageExist());
            //Assert.assertTrue(buyFlowDeviceConfigurator.SelectCommitmentTerm(Dictionary.get("CONTRACT_LENGTH")));
            Assert.assertTrue(buyFlowDeviceConfigurator.SelectInsuranceOptions(Dictionary.get("REQUIRED_SERVICE")));
            Assert.assertTrue(buyFlowDeviceConfigurator.ClickContinue());

            JoinGroupPage joinGroupPage=new JoinGroupPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(joinGroupPage.IsPageDisplayed());
            Assert.assertTrue(joinGroupPage.ClickCreateNewPlan());

            BuyFlowPlanConfigurator byFlowPlanConfigurator = new BuyFlowPlanConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(byFlowPlanConfigurator.PlanConfiguratorPageDisplayed());
            //Assert.assertTrue(byFlowPlanConfigurator.SelectDataPlanFromVisibleRadioButton(Dictionary.get("PLAN")));
            CartSummaryPage CartSummaryPage = byFlowPlanConfigurator.ClickContinue();

            //CartSummaryPage CartSummaryPage = new CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertNotNull(CartSummaryPage);
            Assert.assertTrue(CartSummaryPage.CartSummaryPageIsDisplayed());
            Assert.assertTrue(CartSummaryPage.ClickCheckoutButton());           

            PersonalInfoPage PersonalInfoPage  = new PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            //Assert.assertTrue(PersonalInfoPage.PersonalInfo());
            //Assert.assertTrue(PersonalInfoPage.BillingInfo());
            //Assert.assertTrue(PersonalInfoPage.ValidateBillAddrVerifiedSuccessfully());
            //Assert.assertTrue(PersonalInfoPage.CreditInfo());
            Assert.assertTrue(PersonalInfoPage.EnterCreditCardDetails());
            Assert.assertTrue(PersonalInfoPage.ClickContinueOnPersonalInfoPage());

            PhoneNumberDetailsPage PhoneNumberDetailsPage = new PhoneNumberDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PhoneNumberDetailsPage.PhoneNumberDetailsPageIsDisplayed());
            Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaCode(1,Dictionary.get("AREA_CODE")));
            //Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaName(1,Dictionary.get("SERVICE_CITY")));

            ReviewAndSubmitOrderPage ReviewAndSubmitOrderPage = PhoneNumberDetailsPage.SelectContinuePhoneNumberDetailsPage();
            Assert.assertNotNull(ReviewAndSubmitOrderPage);
            Assert.assertTrue(ReviewAndSubmitOrderPage.IsPageDisplayed());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForElectronicConsent());
            Assert.assertTrue(ReviewAndSubmitOrderPage.selectCheckBoxForRetailInstallmentAgreement());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForWirelessCustomerAgreement());

            ThankYouOrderPage thankYouOrderPage = ReviewAndSubmitOrderPage.ClickSubmitOrder();
            Assert.assertNotNull(thankYouOrderPage);
            Assert.assertTrue(thankYouOrderPage.ThankyouPageIsDisplayed());
        }
    }

    // ***************************************************************************************************
    // * NAME : HR_Desktop_EC_UpgradeWirelessLine
    // * AUTHOR : Abhigyan Dwivedi
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void HR_Desktop_EC_UpgradeWirelessLine(@Optional("") String browser) {

        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {

            UpgradeYourDevicePage upgradeYourDevicePage;           
            
            if(Environment.get("ENV_CODE").equals("FS")){
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_OLAM")));
                
                LoginFromOlamHardrock loginFromOlamHardrock = new LoginFromOlamHardrock(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(loginFromOlamHardrock.IsLoginFromOlamHardrockPageDisplayed());
                Assert.assertTrue(loginFromOlamHardrock.EnterUserID());
                Assert.assertTrue(loginFromOlamHardrock.EnterPassword());
                Assert.assertTrue(loginFromOlamHardrock.ClickLoginButton());
                AccountOverviewPage accountOverviewPage = loginFromOlamHardrock.HandlePagesTillAccountOverview();
                Assert.assertNotNull(accountOverviewPage);
                Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
                Assert.assertTrue(objCommon.fCommonSetCookieDomain("tutG"));
                Assert.assertTrue(objCommon.fCommonSetCookieDomain("TG-PD-ID"));

                upgradeYourDevicePage = accountOverviewPage.ClickUpgrade();
                
            }else{
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_EC")));
                
                LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertNotNull(loginPage);
                Assert.assertTrue(loginPage.LoginPageIsDisplayed());
                IntentModal intentModal = loginPage.ClickOnUserField();
                Assert.assertNotNull(intentModal);
                Assert.assertTrue(intentModal.IntentPageIsDisplayed());
                Assert.assertTrue(intentModal.SelectIntentAsUpgrade());
                Assert.assertTrue(loginPage.LoginPageIsDisplayed());
                Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());
                upgradeYourDevicePage = new UpgradeYourDevicePage(driver, driverType, Dictionary, Environment, Reporter);
            }
 
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");
            
            Assert.assertNotNull(upgradeYourDevicePage);
            Assert.assertTrue(upgradeYourDevicePage.UpgradeYourDevicePageIsDisplayed());
            Assert.assertTrue(upgradeYourDevicePage.ClickOnUpgradeForDevice(Dictionary.get("UPGRADE_CTN")));

            String controlElementXpath="xpath:=//div[@class='headerSection']//h2 | //h1[contains(@id,'title')]";
            objCommon.fCommonValidateDynamicPageDisplayed(controlElementXpath, "");

            DeviceListPageSmartphone deviceListPage = null;
            if (objCommon.fCommonGetObject(controlElementXpath, 
                    "Express Checkout page or Device List Page").getText().equalsIgnoreCase("Express Checkout")) {     
                ExpressUpgrade expressUpgrade = new ExpressUpgrade(driver, driverType, Dictionary, Environment, Reporter);
                deviceListPage = expressUpgrade.ClickShowAllDevicesLink();
            }else{
                deviceListPage = new DeviceListPageSmartphone(driver, driverType, Dictionary, Environment, Reporter);
            }                

            Assert.assertTrue(deviceListPage.DeviceListPageIsDisplayed());

            DeviceDetailsPage DeviceDetailsPage = deviceListPage.ViewButtonClickForDevice(Dictionary.get("DEVICE"));
            Assert.assertNotNull(DeviceDetailsPage);
            Assert.assertTrue(DeviceDetailsPage.BFOIsDeviceDetailsPageDisplayed());
            Assert.assertTrue(DeviceDetailsPage.BFOClickOnContinuebutton());

            BuyFlowDeviceConfigurator buyFlowDeviceConfigurator = new BuyFlowDeviceConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(buyFlowDeviceConfigurator.DeviceConfiguratorPageExist());
            //Assert.assertTrue(buyFlowDeviceConfigurator.SelectCommitmentTerm(Dictionary.get("CONTRACT_LENGTH")));
            Assert.assertTrue(buyFlowDeviceConfigurator.SelectInsuranceOptions(Dictionary.get("REQUIRED_SERVICE")));
            Assert.assertTrue(buyFlowDeviceConfigurator.ClickContinue());
            
            ServicesListPage servicesListPage = new ServicesListPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(servicesListPage.IsPageDisplayed());
            Assert.assertTrue(servicesListPage.SelectAllNoThanksRadioBtn());
            Assert.assertTrue(servicesListPage.SelectRequiredServiceRadioButton("DataPro 5GB"));
            Assert.assertTrue(servicesListPage.BFOClickContinueToNextStep());

            //BuyFlowPlanConfigurator byFlowPlanConfigurator = new BuyFlowPlanConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            //Assert.assertTrue(byFlowPlanConfigurator.PlanConfiguratorPageDisplayed());
            //Assert.assertTrue(byFlowPlanConfigurator.SelectDataPlanFromVisibleRadioButton(Dictionary.get("PLAN")));

            CartSummaryPage CartSummaryPage = new CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            //CartSummaryPage CartSummaryPage = byFlowPlanConfigurator.ClickContinue();
            Assert.assertNotNull(CartSummaryPage);
            Assert.assertTrue(CartSummaryPage.CartSummaryPageIsDisplayed());
            Assert.assertTrue(CartSummaryPage.ClickCheckoutButton());           

            PersonalInfoPage PersonalInfoPage  = new PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            //Assert.assertTrue(PersonalInfoPage.PersonalInfo());
            //Assert.assertTrue(PersonalInfoPage.BillingInfo());
            //Assert.assertTrue(PersonalInfoPage.ValidateBillAddrVerifiedSuccessfully());
            //Assert.assertTrue(PersonalInfoPage.CreditInfo());
            Assert.assertTrue(PersonalInfoPage.EnterCreditCardDetails());
            Assert.assertTrue(PersonalInfoPage.ClickContinueOnPersonalInfoPage());

            ReviewAndSubmitOrderPage ReviewAndSubmitOrderPage = new ReviewAndSubmitOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertNotNull(ReviewAndSubmitOrderPage);
            Assert.assertTrue(ReviewAndSubmitOrderPage.IsPageDisplayed());
            //Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForElectronicConsent());
            //Assert.assertTrue(ReviewAndSubmitOrderPage.selectCheckBoxForRetailInstallmentAgreement());
            //Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForWirelessCustomerAgreement());

            // This might be burning the data, skipping for now
            //ThankYouOrderPage thankYouOrderPage = reviewAndSubmitOrderPage.ClickSubmitOrder();
            //Assert.assertNotNull(thankYouOrderPage);
            //Assert.assertTrue(thankYouOrderPage.ThankyouPageIsDisplayed());
        }
    }


    //***************************************************************************************************
    //* NAME                : HR_Mobile_NC_NewWirelessLineBOPIS
    //* AUTHOR              : Gavril Grigorean
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void HR_Mobile_NC_NewWirelessLineBOPIS(@Optional("") String browser) {

        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")) {   

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_NC")+"index.html"));

            ShopMobileLandingPage shopMobileLandingPage = new ShopMobileLandingPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(shopMobileLandingPage.ShopMobileLandingPageIsDisplayed());
            
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            DeviceCatagoryPage deviceCatagoryPage = shopMobileLandingPage.ClickPhonesTabletsDevicesLink();
            Assert.assertNotNull(deviceCatagoryPage);
            Assert.assertTrue(deviceCatagoryPage.VerifyDeviceCategoryPageExist());

            DeviceListPage deviceListPage = deviceCatagoryPage.SelectCategory(Dictionary.get("DEVICE_CATEGORY"));
            Assert.assertNotNull(deviceListPage);
            Assert.assertTrue(deviceListPage.IsDeviceListPageDisplayed());

            com.att.mhr.DeviceDetailsPage deviceDetailsPage = deviceListPage.SelectDeviceBySku(Dictionary.get("DEVICE_NAME"));
            Assert.assertNotNull(deviceDetailsPage);
            Assert.assertTrue(deviceDetailsPage.IsDeviceDetailsPageDisplayed());            
            
//            GeoLocationPage geoLocationPage = deviceDetailsPage.ClickOnCheckInStoreAvailability();
            
//            Assert.assertTrue(deviceDetailsPage.handleKnowYourLocationPopup());
//            
//            Assert.assertNotNull(geoLocationPage);
//            Assert.assertTrue(geoLocationPage.GeoLocationPageIsDisplayed());
//            Assert.assertTrue(geoLocationPage.SetZipCode(Dictionary.get("ZIP_CODE")));
//            Assert.assertTrue(geoLocationPage.clickSubmit());
//
//            SLIResultsPage sLIResultsPage = new SLIResultsPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(sLIResultsPage.SLIResultPageIsDisplayed());
//            Assert.assertTrue(sLIResultsPage.ClickOnPickUpInStore());
//            
//            GetStartedPage getStarted=new GetStartedPage(driver,driverType,Dictionary,Environment,Reporter);
//            Assert.assertTrue(getStarted.CheckGetStartedPageIsDisplayed());
//            Assert.assertTrue(getStarted.ClickOrderNewService());
//            Assert.assertTrue(getStarted.ClickContinue());
//
//            LocalizationPage localizationPage = new LocalizationPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(localizationPage.CheckLocalizationModalIsDisplayed());
//            Assert.assertTrue(localizationPage.EnterZipCode(Dictionary.get("ZIP_CODE")));
//
//            CommitmentTermPage commitmentTermPage = localizationPage.ClickSubmit();
//            Assert.assertNotNull(commitmentTermPage);
//            Assert.assertTrue(commitmentTermPage.CheckCommitmentTermPageIsDisplayed());
//            //Assert.assertTrue(commitmentTermPage.SelectCommitmentTerm("AT&T 24"));
//            Assert.assertTrue(commitmentTermPage.clickAddToCart());
//
//            ProtectionServicesPage protectionServicesPage = new ProtectionServicesPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertNotNull(protectionServicesPage);
//            Assert.assertTrue(protectionServicesPage.CheckProtectYourDevicePageIsDisplayed());
//            Assert.assertTrue(protectionServicesPage.SelectProtectionServices(""));
//            Assert.assertTrue(protectionServicesPage.ClickSelectButton());
//
//            MobileShareValuePlansListPage mobileShareValuePlansListPage = new MobileShareValuePlansListPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(mobileShareValuePlansListPage.CheckMobileShareValuePlanListPageIsDisplayed());
//            Assert.assertTrue(mobileShareValuePlansListPage.ClickExpandLinkToSelectPlan("15GB"));
//
//            MobileShareHubPage mobileShareHubPage = mobileShareValuePlansListPage.ClickOnAddToCart("ANY");
//            Assert.assertNotNull(mobileShareHubPage);
//            Assert.assertTrue(mobileShareHubPage.CheckMobileShareHubPageIsDisplayed());
//            Assert.assertTrue(mobileShareHubPage.ClickOnContinueToCartCTA());
//
//            RecommendedAccessoriesPage recommendedAccessoriesPage = new RecommendedAccessoriesPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(recommendedAccessoriesPage.VerifyRecommendedAccessoriesPage());
//            Assert.assertTrue(recommendedAccessoriesPage.ClickOnContinueButton());
//
//            com.att.mhr.CartSummaryPage cartSummaryPage = new com.att.mhr.CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(cartSummaryPage.CartSummaryIsDisplayed());
//            Assert.assertTrue(cartSummaryPage.ClickCheckOut());
//
//            com.att.mhr.PersonalInfoPage personalInfoPage = new com.att.mhr.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
//            Assert.assertTrue(personalInfoPage.SetContactInformation());
//            Assert.assertTrue(personalInfoPage.SetBillToAddress());
//            Assert.assertTrue(personalInfoPage.SetCreditInformation());
//            Assert.assertTrue(personalInfoPage.ClickOnContinue());
//
//            PaymentInfoPage paymentInfoPage=new PaymentInfoPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(paymentInfoPage.IsPaymentInfoPageDisplayed());
//            Assert.assertTrue(paymentInfoPage.EnterPaymentInfo());
//            Assert.assertTrue(paymentInfoPage.ClickOnContinueBtn());
//
//            com.att.mhr.PhoneNumberDetailsPage phoneNumberDetailsPage = new com.att.mhr.PhoneNumberDetailsPage(driver, driverType, Dictionary,Environment,Reporter); 
//            Assert.assertNotNull(phoneNumberDetailsPage);
//            Assert.assertTrue(phoneNumberDetailsPage.VerifyPoneNumberDetailsPageExist());
//            Assert.assertTrue(phoneNumberDetailsPage.SelectNewNumberAllCheckBoxes());
//            Assert.assertTrue(phoneNumberDetailsPage.ClickContinueButton());
//
//            SelectYourNumberPage selectYourNumberPage=new SelectYourNumberPage(driver, driverType, Dictionary,Environment,Reporter);
//            Assert.assertTrue(selectYourNumberPage.SelectYourNumberPageIsDisplayed());
//            Assert.assertTrue(selectYourNumberPage.SelectAreaCode("1",Dictionary.get("AREA_CODE")));
//            Assert.assertTrue(selectYourNumberPage.SelectServiceCity("1",Dictionary.get("SERVICE_CITY")));
//            Assert.assertTrue(selectYourNumberPage.ClickContinueCTA());         
//
//            com.att.mhr.ReviewAndSubmitOrderPage reviewAndSubmitOrderPage = new com.att.mhr.ReviewAndSubmitOrderPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(reviewAndSubmitOrderPage.ReviewAndSubmitOrderPageIsDisplayed());
//            Assert.assertTrue(reviewAndSubmitOrderPage.ClickContinueButton());
//
//            NextTermPage nextTermPage = new NextTermPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(nextTermPage.NextTermPageIsDisplayed());
//            Assert.assertTrue(nextTermPage.SelectAllCheckBoxes());
//            Assert.assertTrue(nextTermPage.ClickContinue());
//
//            com.att.mhr.ThankYouOrderPage thankYouOrderPage=new com.att.mhr.ThankYouOrderPage(driver, driverType, Dictionary, Environment, Reporter);
//            Assert.assertTrue(thankYouOrderPage.isThankyouPageIsDisplayed());         
        }
    }

    // ***************************************************************************************************
    // * NAME : HR_Mobile_EC_AddWirelessLine
    // * AUTHOR : Abhigyan Dwivedi
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void HR_Mobile_EC_AddWirelessLine(@Optional("") String browser) {

        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
        
            if(Environment.get("ENV_CODE").equals("FS")){
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC_DSS")));

                DSSLoginPage dssLoginPage = new DSSLoginPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(dssLoginPage.VerifyDSSLoginPageExist());

                MyAttOverviewPage myAttOverviewPage = dssLoginPage.Login();
                Assert.assertNotNull(myAttOverviewPage);
                //Assert.assertTrue(objCommon.fCommonSetCookieDomain("tutG"));
                //Assert.assertTrue(objCommon.fCommonSetCookieDomain("TG-PD-ID"));
                Assert.assertTrue(myAttOverviewPage.CheckMyAttOverviewPageExistance());                 
                Assert.assertTrue(myAttOverviewPage.ClickOnShopAtnT());

                GlobalNavShopAttPage globalNavShopAttPage = new GlobalNavShopAttPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(globalNavShopAttPage.VerifyGlobalNavShopAttPageExist());

                ShopMobileIndexPage shopMobileIndexPage = globalNavShopAttPage.ClickWirelessLink();
                Assert.assertNotNull(shopMobileIndexPage);
                Assert.assertTrue(shopMobileIndexPage.VerifyShopMobileIndexPageExist());  
                Assert.assertTrue(shopMobileIndexPage.ClickAddNewDeviceToAccount());              
                
            }else{
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC")+"index.html"));

                ShopMobileIndexPage shopMobileIndexPage=new ShopMobileIndexPage(driver,driverType, Dictionary,Environment,Reporter);
                Assert.assertTrue(shopMobileIndexPage.VerifyShopMobileIndexPageExist());
                Assert.assertTrue(shopMobileIndexPage.ClickAddNewDeviceToAccount());
                
			    ShopMobileLoginPage shopMobileLoginPage= new ShopMobileLoginPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(shopMobileLoginPage.VerifyShopMobileLoginPageExist());
                Assert.assertTrue(shopMobileLoginPage.ShopMobileLogin(Dictionary.get("USER_CTN"),Dictionary.get("PASSWORD"),"Y"));

            }           

            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            DeviceCatagoryPage deviceCatagoryPage=new DeviceCatagoryPage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertTrue(deviceCatagoryPage.VerifyDeviceCategoryPageExist());

            DeviceListPage  deviceListPage=deviceCatagoryPage.SelectCategory("Smartphones");
            Assert.assertNotNull(deviceListPage);
            Assert.assertTrue(deviceListPage.IsDeviceListPageDisplayed());

            com.att.mhr.DeviceDetailsPage deviceDetailsPage = deviceListPage.SelectDeviceBySku(Dictionary.get("DEVICE_NAME"));
            Assert.assertNotNull(deviceDetailsPage);
            Assert.assertTrue(deviceDetailsPage.IsDeviceDetailsPageDisplayed());
            Assert.assertTrue(deviceDetailsPage.ClickOnAddToCart());

            CommitmentTermPage commitmentTermPage = new CommitmentTermPage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertNotNull(commitmentTermPage);
            Assert.assertTrue(commitmentTermPage.CheckCommitmentTermPageIsDisplayed());
            //Assert.assertTrue(commitmentTermPage.SelectCommitmentTerm("No annual contract"));
            Assert.assertTrue(commitmentTermPage.clickAddToCart());

            ProtectionServicesPage protectionServicesPage = new ProtectionServicesPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertNotNull(protectionServicesPage);
            Assert.assertTrue(protectionServicesPage.CheckProtectYourDevicePageIsDisplayed());
            Assert.assertTrue(protectionServicesPage.SelectProtectionServices("DECLINE"));
            Assert.assertTrue(protectionServicesPage.ClickSelectButton());

            //these page does not come in TST02 for the current test account but keeping them until 
            //we get close to end release because we might use another account where these pages will come
            //if(!Environment.get("ENV_CODE").contains("TST02")){
            AddALinePage addALinePage=new AddALinePage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertTrue(addALinePage.AddALinePageDisplayed());
            Assert.assertTrue(addALinePage.SelectAddNewPlan());
            Assert.assertTrue(addALinePage.ClickOnContinueAL());

            MobileShareValuePlansListPage mobileShareValuePlansListPage=new MobileShareValuePlansListPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertNotNull(mobileShareValuePlansListPage);
            Assert.assertTrue(mobileShareValuePlansListPage.CheckMobileShareValuePlanListPageIsDisplayed());
            //Assert.assertTrue(mobileShareValuePlansListPage.ClickExpandLinkToSelectPlan("15GB"));
            Assert.assertNotNull(mobileShareValuePlansListPage.ClickOnAddToCart("ANY"));
            //}

            MobileShareHubPage mobileShareHubPage = new MobileShareHubPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(mobileShareHubPage.CheckMobileShareHubPageIsDisplayed());
            Assert.assertTrue(mobileShareHubPage.ClickOnContinueToCartCTA());

            RecommendedAccessoriesPage recommendedAccessoriesPage = new RecommendedAccessoriesPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(recommendedAccessoriesPage.VerifyRecommendedAccessoriesPage());
            Assert.assertTrue(recommendedAccessoriesPage.ClickOnContinueButton());

            com.att.mhr.CartSummaryPage cartSummaryPage = new com.att.mhr.CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.CartSummaryIsDisplayed());
            //Assert.assertTrue(cartSummaryPage.CheckAgreement());
            Assert.assertTrue(cartSummaryPage.ClickOnCheckOut());

            ShippingInfoPage shippingInfoPage=new ShippingInfoPage(driver, driverType, Dictionary, Environment, Reporter);                    
            Assert.assertTrue(shippingInfoPage.CheckShippingInfoIsDisplayed());
            Assert.assertTrue(shippingInfoPage.ClickContinue());

            PaymentInfoPage paymentInfoPage=new PaymentInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(paymentInfoPage.EnterPaymentInfo());
            Assert.assertTrue(paymentInfoPage.ClickOnContinueBtn());

            com.att.mhr.PhoneNumberDetailsPage phoneNumberDetailsPage = new com.att.mhr.PhoneNumberDetailsPage(driver, driverType, Dictionary,Environment,Reporter); 
            Assert.assertNotNull(phoneNumberDetailsPage);
            Assert.assertTrue(phoneNumberDetailsPage.VerifyPoneNumberDetailsPageExist());
            Assert.assertTrue(phoneNumberDetailsPage.SelectNewNumberAllCheckBoxes());
            Assert.assertTrue(phoneNumberDetailsPage.ClickContinueButton());

            SelectYourNumberPage selectYourNumberPage=new SelectYourNumberPage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertTrue(selectYourNumberPage.SelectYourNumberPageIsDisplayed());
            Assert.assertTrue(selectYourNumberPage.SelectAreaCode("1",Dictionary.get("AREA_CODE")));
            Assert.assertTrue(selectYourNumberPage.SelectServiceCity("1",Dictionary.get("SERVICE_CITY")));
            Assert.assertTrue(selectYourNumberPage.ClickContinueCTA());         

            com.att.mhr.ReviewAndSubmitOrderPage reviewAndSubmitOrderPage=new com.att.mhr.ReviewAndSubmitOrderPage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertTrue(reviewAndSubmitOrderPage.ReviewAndSubmitOrderPageIsDisplayed());
            Assert.assertTrue(reviewAndSubmitOrderPage.ClickContinueButton());

            NextTermPage nextTermPage = new NextTermPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(nextTermPage.NextTermPageIsDisplayed());
            Assert.assertTrue(nextTermPage.SelectAllCheckBoxes());
            Assert.assertTrue(nextTermPage.ClickContinue());

            com.att.mhr.ThankYouOrderPage thankYouOrderPage=new com.att.mhr.ThankYouOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(thankYouOrderPage.isThankyouPageIsDisplayed());
        }
    }

    // ***************************************************************************************************
    // * NAME : HR_Mobile_EC_UpgradeWirelessLine
    // * AUTHOR : Abhigyan Dwivedi
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" }) 
    public void HR_Mobile_EC_UpgradeWirelessLine(@Optional("") String browser) {

        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {

            
            if(Environment.get("ENV_CODE").equals("FS")){
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC_DSS")));

                DSSLoginPage dssLoginPage = new DSSLoginPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertTrue(dssLoginPage.VerifyDSSLoginPageExist());

                MyAttOverviewPage myAttOverviewPage = dssLoginPage.Login();
                Assert.assertNotNull(myAttOverviewPage);
                //Assert.assertTrue(objCommon.fCommonSetCookieDomain("tutG"));
                //Assert.assertTrue(objCommon.fCommonSetCookieDomain("TG-PD-ID"));
                Assert.assertTrue(myAttOverviewPage.CheckMyAttOverviewPageExistance());
                Assert.assertTrue(myAttOverviewPage.ClickOnCheckUpgradeEligiblity());
            
            }else{
                
                Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_NC")+"index.html"));

                ShopMobileIndexPage shopMobileIndexPage=new ShopMobileIndexPage(driver, driverType, Dictionary, Environment, Reporter);
                Assert.assertNotNull(shopMobileIndexPage);
                Assert.assertTrue(shopMobileIndexPage.VerifyShopMobileIndexPageExist());

                ShopMobileLoginPage shopMobileLoginPage=shopMobileIndexPage.ClickCheckUpgradeEligibilityUnAuthenticate();
                Assert.assertNotNull(shopMobileLoginPage);
                Assert.assertTrue(shopMobileLoginPage.VerifyShopMobileLoginPageHeader());
                Assert.assertTrue(shopMobileLoginPage.ShopMobileLogin(Dictionary.get("USER_CTN"), Dictionary.get("PASSWORD"),"Y"));  
                
            }
                     
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            UpdateYourDevicePage upgradeYourDevicePage=new UpdateYourDevicePage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(upgradeYourDevicePage.UpdateYourDevicePageIsDisplayed());
            Assert.assertTrue(upgradeYourDevicePage.clickCTN(Dictionary.get("UPGRADE_CTN")));                 

            DeviceCatagoryPage deviceCatagoryPage=new DeviceCatagoryPage(driver, driverType, Dictionary,Environment,Reporter);

            Assert.assertTrue(deviceCatagoryPage.VerifyDeviceCategoryPageExist());

            DeviceListPage  deviceListPage=deviceCatagoryPage.SelectCategory("Smartphones");
            Assert.assertNotNull(deviceListPage);
            Assert.assertTrue(deviceListPage.IsDeviceListPageDisplayed());
            
            DeviceFiltersPage deviceFiltersPage = deviceListPage.CheckDeviceFilters();
            Assert.assertTrue(deviceFiltersPage.IsDeviceFilterPageDisplayed());

            deviceListPage = deviceFiltersPage.ApplyFilter("No annual contract");
            Assert.assertNotNull(deviceListPage);           
            Assert.assertTrue(deviceListPage.IsDeviceListPageDisplayed());
            
            com.att.mhr.DeviceDetailsPage deviceDetailsPage = deviceListPage.SelectDeviceBySku(Dictionary.get("DEVICE_NAME"));
            Assert.assertNotNull(deviceDetailsPage);
            Assert.assertTrue(deviceDetailsPage.IsDeviceDetailsPageDisplayed());
            Assert.assertTrue(deviceDetailsPage.ClickOnAddToCart());

            CommitmentTermPage commitmentTermPage = new CommitmentTermPage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertNotNull(commitmentTermPage);
            Assert.assertTrue(commitmentTermPage.CheckCommitmentTermPageIsDisplayed());
            Assert.assertTrue(commitmentTermPage.SelectCommitmentTerm(""));
            Assert.assertTrue(commitmentTermPage.clickAddToCart());

            PlansAndServicesPage plansAndServicesPage=new PlansAndServicesPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(plansAndServicesPage.PlansAndServicesPageIsDisplayed());
            Assert.assertTrue(plansAndServicesPage.ClickContinue());

            RecommendedAccessoriesPage recommendedAccessoriesPage = new RecommendedAccessoriesPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(recommendedAccessoriesPage.VerifyRecommendedAccessoriesPage());
            Assert.assertTrue(recommendedAccessoriesPage.ClickOnContinueButton());

            com.att.mhr.CartSummaryPage cartSummaryPage = new com.att.mhr.CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.CartSummaryIsDisplayed());
            Assert.assertTrue(cartSummaryPage.ClickOnCheckOut());

            ShippingInfoPage shippingInfoPage=new ShippingInfoPage(driver, driverType, Dictionary, Environment, Reporter);                    
            Assert.assertTrue(shippingInfoPage.CheckShippingInfoIsDisplayed());
            Assert.assertTrue(shippingInfoPage.ClickContinue());

            PaymentInfoPage paymentInfoPage=new PaymentInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(paymentInfoPage.EnterPaymentInfo());
            Assert.assertTrue(paymentInfoPage.ClickOnContinueBtn());

            com.att.mhr.ReviewAndSubmitOrderPage reviewAndSubmitOrderPage=new com.att.mhr.ReviewAndSubmitOrderPage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertTrue(reviewAndSubmitOrderPage.ReviewAndSubmitOrderPageIsDisplayed());

            // This might be burning the data, skipping for now
            //Assert.assertTrue(reviewAndSubmitOrderPage.ClickContinueButton());
            //com.att.mhr.ThankYouOrderPage thankYouOrderPage=new com.att.mhr.ThankYouOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            //Assert.assertTrue(thankYouOrderPage.isThankyouPageIsDisplayed());     
        }
    }


    // ***************************************************************************************************
    // * NAME : Star_Desktop_ExistingUverse_NewWireless
    // * AUTHOR : Stefan Andrei
    // ***************************************************************************************************
    @Test
    @Parameters({ "browser" })
    public void Star_Desktop_ExistingUverse_NewWireless(@Optional("") String browser) {

        if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_NC") + "unified/referrals.html?referral_type=unified&product_suite=Wireless"));

            CheckAvailabilityPage checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.isPageDisplayed());
            
            objCommon.fCommonGetCookieValue("SALESSESSIONID");
            
            Assert.assertTrue(checkAvailabilityPage.clickGetStarted());

            AuthenticationPage authenticationPage = new AuthenticationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(authenticationPage.IsPageDisplayed());
            Assert.assertTrue(authenticationPage.SelectAccountType("IPTV"));
            Assert.assertTrue(authenticationPage.EnterUserId("IPTV", Dictionary.get("IPTV_UID")));
            Assert.assertTrue(authenticationPage.EnterPassword("IPTV", Dictionary.get("IPTV_PASSWORD")));
            Assert.assertTrue(authenticationPage.ClickOnLogIn("IPTV"));
            //Assert.assertTrue(authenticationPage.SuccessMsgForEligibility());
            //Assert.assertTrue(authenticationPage.ClickOnContinueWhenGoodNewsAppears());
            Assert.assertTrue(authenticationPage.checkUverseLoginSuccessful());
            Assert.assertTrue(authenticationPage.clickContinueLink());

            HubPage hubPage = new HubPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(hubPage.IsPageDisplayed());
            Assert.assertTrue(hubPage.VerifyCKAVAddressFromCKAVPage(Dictionary.get("ZIP_CODE"), Dictionary.get("STREET_ADDRESS")));
            //Assert.assertTrue(hubPage.FetchPlanPriceAtHub("Mobile Share"));
            //Assert.assertTrue(hubPage.SelectServiceAtHub("Mobile Share"));
            //Assert.assertTrue(hubPage.FetchPlanPriceAtHub("ANY"));
            Assert.assertTrue(hubPage.SelectServiceAtHub("Add Wireless"));

            DeviceListPageSmartphone deviceListPageSmartphone =  new DeviceListPageSmartphone(driver,driverType, Dictionary,Environment,Reporter);;
            Assert.assertTrue(deviceListPageSmartphone.DeviceListPageIsDisplayed());

            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            DeviceDetailsPage DeviceDetailsPage = deviceListPageSmartphone.ViewButtonClickForDevice(Dictionary.get("DEVICE"));
            Assert.assertNotNull(DeviceDetailsPage);
            Assert.assertTrue(DeviceDetailsPage.BFOIsDeviceDetailsPageDisplayed());
            Assert.assertTrue(DeviceDetailsPage.BFOClickOnContinuebutton());

            BuyFlowDeviceConfigurator buyFlowDeviceConfigurator = new BuyFlowDeviceConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(buyFlowDeviceConfigurator.DeviceConfiguratorPageExist());
            //Assert.assertTrue(buyFlowDeviceConfigurator.SelectCommitmentTerm(Dictionary.get("CONTRACT_LENGTH")));
            Assert.assertTrue(buyFlowDeviceConfigurator.SelectInsuranceOptions(Dictionary.get("REQUIRED_SERVICE")));
            Assert.assertTrue(buyFlowDeviceConfigurator.ClickContinue());

            BuyFlowPlanConfigurator byFlowPlanConfigurator = new BuyFlowPlanConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(byFlowPlanConfigurator.PlanConfiguratorPageDisplayed());
            //Assert.assertTrue(byFlowPlanConfigurator.SelectDataPlanFromVisibleRadioButton(Dictionary.get("PLAN")));
            //Assert.assertTrue(byFlowPlanConfigurator.checkDirectTVorUverseRequired()); 

            CartSummaryPage CartSummaryPage = byFlowPlanConfigurator.ClickContinue();
            Assert.assertNotNull(CartSummaryPage);
            Assert.assertTrue(CartSummaryPage.CartSummaryPageIsDisplayed());
            Assert.assertTrue(CartSummaryPage.ClickCheckoutButton());           

            PersonalInfoPage PersonalInfoPage  = new PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            //Assert.assertTrue(PersonalInfoPage.PersonalInfo());
            //Assert.assertTrue(PersonalInfoPage.BillingInfo());
            //Assert.assertTrue(PersonalInfoPage.ContinueToNextStepToVerifyAddress());
            //Assert.assertTrue(PersonalInfoPage.ValidateBillAddrVerifiedSuccessfully());
            Assert.assertTrue(PersonalInfoPage.checkUseMyBillToAddress());
            //Assert.assertTrue(PersonalInfoPage.CreditInfo());
            //Assert.assertTrue(PersonalInfoPage.PassCodeAccountSetUp(Dictionary.get("PASSCODE")));
            //Assert.assertTrue(PersonalInfoPage.ReEnterPassCodeForAccountSetup(Dictionary.get("PASSCODE")));
            //Assert.assertTrue(PersonalInfoPage.SecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            //Assert.assertTrue(PersonalInfoPage.SecurityAnswer(Dictionary.get("SECURITYANSWER")));
            Assert.assertTrue(PersonalInfoPage.EnterCreditCardDetails());
            Assert.assertTrue(PersonalInfoPage.ClickContinueOnPersonalInfoPage());
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            Assert.assertTrue(PersonalInfoPage.checkUseMyBillToAddress());
            //Assert.assertTrue(PersonalInfoPage.EnterLastName());
            Assert.assertTrue(PersonalInfoPage.EnterSSN());
            Assert.assertTrue(PersonalInfoPage.ClickContinueOnPersonalInfoPage());

            PhoneNumberDetailsPage PhoneNumberDetailsPage = new PhoneNumberDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PhoneNumberDetailsPage.PhoneNumberDetailsPageIsDisplayed());
            Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaCode(1,Dictionary.get("AREA_CODE")));
            //Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaName(1,Dictionary.get("SERVICE_CITY")));

            ReviewAndSubmitOrderPage ReviewAndSubmitOrderPage = PhoneNumberDetailsPage.SelectContinuePhoneNumberDetailsPage();
            Assert.assertNotNull(ReviewAndSubmitOrderPage);
            Assert.assertTrue(ReviewAndSubmitOrderPage.IsPageDisplayed());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForElectronicConsent());
            Assert.assertTrue(ReviewAndSubmitOrderPage.selectCheckBoxForRetailInstallmentAgreement());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForWirelessCustomerAgreement());

            // This might be burning the data, skipping for now
            //ThankYouOrderPageWirelessFlow thankYouOrderPageWirelessFlow = reviewAndSubmitOrderPageWirelessFlow.ClickSubmitOrder(); // commented to prevent burning data
            //Assert.assertNotNull(thankYouOrderPageWirelessFlow);
            //Assert.assertTrue(thankYouOrderPageWirelessFlow.ThankyouPageIsDisplayed());
        }
    }


    // ***************************************************************************************************
    // * NAME : Star_Desktop_ExistingDTV_NewWireless
    // * AUTHOR : Stefan Andrei
    // ***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void Star_Desktop_ExistingDTV_NewWireless(@Optional("") String browser) {

        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("") && !Dictionary.get("SKIP_"+driverType).equals("null")) {

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_NC") + "unified/referrals.html?referral_type=unified&product_suite=Wireless"));

            CheckAvailabilityPage checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.isPageDisplayed());
            
            objCommon.fCommonGetCookieValue("SALESSESSIONID");
            
            Assert.assertTrue(checkAvailabilityPage.clickGetStarted());
            
            AuthenticationPage authenticationPage = new AuthenticationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(authenticationPage.IsPageDisplayed());
            Assert.assertTrue(authenticationPage.SelectAccountType("DTV"));
            Assert.assertTrue(authenticationPage.EnterUserId("DTV", Dictionary.get("DTV_UID")));
            Assert.assertTrue(authenticationPage.EnterPassword("DTV", Dictionary.get("DTV_PASSWORD")));
            Assert.assertTrue(authenticationPage.ClickOnLogIn("DTV"));
            Assert.assertTrue(authenticationPage.checkDirectTVLoginSuccessful());
            Assert.assertTrue(authenticationPage.clickContinueLink());

            /*   QualificationCheckPage qualificationCheckPage = new QualificationCheckPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(qualificationCheckPage.IsPageDisplayed());
            Assert.assertTrue(qualificationCheckPage.IsExistingCustCKAVPageDisplayed());
            Assert.assertTrue(qualificationCheckPage.EnterZipCode(Dictionary.get("ZIP_CODE")));
            Assert.assertTrue(qualificationCheckPage.EnterStreetAddress(Dictionary.get("STREET_ADDRESS")));
            Assert.assertTrue(qualificationCheckPage.EnterUnitNumber(Dictionary.get("UNIT_NUMBER")));
            Assert.assertTrue(qualificationCheckPage.SubmitCKAV());
             */

            checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(checkAvailabilityPage.isPageDisplayed());
            Assert.assertTrue(checkAvailabilityPage.EnterZipCode(Dictionary.get("ZIP_CODE")));
            Assert.assertTrue(checkAvailabilityPage.EnterStreetAddress(Dictionary.get("STREET_ADDRESS")));
            Assert.assertTrue(checkAvailabilityPage.EnterUnitNumber(Dictionary.get("UNIT_NUMBER")));

            Assert.assertTrue(checkAvailabilityPage.ClickCheckAvailbility());

            HubPage hubPage = new HubPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(hubPage.IsPageDisplayed());
            Assert.assertTrue(hubPage.VerifyCKAVAddressFromCKAVPage(Dictionary.get("ZIP_CODE"), Dictionary.get("STREET_ADDRESS")));
            //Assert.assertTrue(hubPage.FetchPlanPriceAtHub("Mobile Share"));
            //Assert.assertTrue(hubPage.SelectServiceAtHub("Mobile Share"));
            //Assert.assertTrue(hubPage.FetchPlanPriceAtHub("ANY"));
            Assert.assertTrue(hubPage.SelectServiceAtHub("Add Wireless"));

            DeviceListPageSmartphone deviceListPageSmartphone =  new DeviceListPageSmartphone(driver,driverType, Dictionary,Environment,Reporter);;
            Assert.assertTrue(deviceListPageSmartphone.DeviceListPageIsDisplayed());

            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            DeviceDetailsPage DeviceDetailsPage = deviceListPageSmartphone.ViewButtonClickForDevice(Dictionary.get("DEVICE"));
            Assert.assertNotNull(DeviceDetailsPage);
            Assert.assertTrue(DeviceDetailsPage.BFOIsDeviceDetailsPageDisplayed());
            Assert.assertTrue(DeviceDetailsPage.BFOClickOnContinuebutton());

            BuyFlowDeviceConfigurator buyFlowDeviceConfigurator = new BuyFlowDeviceConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(buyFlowDeviceConfigurator.DeviceConfiguratorPageExist());
            //Assert.assertTrue(buyFlowDeviceConfigurator.SelectCommitmentTerm(Dictionary.get("CONTRACT_LENGTH")));
            Assert.assertTrue(buyFlowDeviceConfigurator.SelectInsuranceOptions(Dictionary.get("REQUIRED_SERVICE")));
            Assert.assertTrue(buyFlowDeviceConfigurator.ClickContinue());

            BuyFlowPlanConfigurator byFlowPlanConfigurator = new BuyFlowPlanConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(byFlowPlanConfigurator.PlanConfiguratorPageDisplayed());
            //Assert.assertTrue(byFlowPlanConfigurator.SelectDataPlanFromVisibleRadioButton(Dictionary.get("PLAN")));
            //Assert.assertTrue(byFlowPlanConfigurator.checkDirectTVorUverseRequired());        
            
            CartSummaryPage CartSummaryPage = byFlowPlanConfigurator.ClickContinue();
            Assert.assertNotNull(CartSummaryPage);
            Assert.assertTrue(CartSummaryPage.CartSummaryPageIsDisplayed());
            Assert.assertTrue(CartSummaryPage.ClickCheckoutButton());           

            PersonalInfoPage PersonalInfoPage  = new PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            //Assert.assertTrue(PersonalInfoPage.PersonalInfo());
            Assert.assertTrue(PersonalInfoPage.EnterPrimaryNumber());
            Assert.assertTrue(PersonalInfoPage.EnterEmail());
            //Assert.assertTrue(PersonalInfoPage.ReEnterEmail());
            //Assert.assertTrue(PersonalInfoPage.BillingInfo());
            Assert.assertTrue(PersonalInfoPage.EnterBillingZIP());
            Assert.assertTrue(PersonalInfoPage.ContinueToNextStepToVerifyAddress());
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            Assert.assertTrue(PersonalInfoPage.ValidateBillAddrVerifiedSuccessfully());
            Assert.assertTrue(PersonalInfoPage.CreditInfo());
            Assert.assertTrue(PersonalInfoPage.PassCodeAccountSetUp(Dictionary.get("PASSCODE")));
            Assert.assertTrue(PersonalInfoPage.ReEnterPassCodeForAccountSetup(Dictionary.get("PASSCODE")));
            Assert.assertTrue(PersonalInfoPage.SecurityQuestion(Dictionary.get("SECURITYQUESTION")));
            Assert.assertTrue(PersonalInfoPage.SecurityAnswer(Dictionary.get("SECURITYANSWER")));
            Assert.assertTrue(PersonalInfoPage.EnterCreditCardDetails());
            Assert.assertTrue(PersonalInfoPage.ClickContinueOnPersonalInfoPage());

            PhoneNumberDetailsPage PhoneNumberDetailsPage = new PhoneNumberDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PhoneNumberDetailsPage.PhoneNumberDetailsPageIsDisplayed());
            Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaCode(1,Dictionary.get("AREA_CODE")));
            //Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaName(1,Dictionary.get("SERVICE_CITY")));

            ReviewAndSubmitOrderPage ReviewAndSubmitOrderPage = PhoneNumberDetailsPage.SelectContinuePhoneNumberDetailsPage();
            Assert.assertNotNull(ReviewAndSubmitOrderPage);
            Assert.assertTrue(ReviewAndSubmitOrderPage.IsPageDisplayed());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForElectronicConsent());
            Assert.assertTrue(ReviewAndSubmitOrderPage.selectCheckBoxForRetailInstallmentAgreement());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForWirelessCustomerAgreement());

            // This might be burning the data, skipping for now
            //ThankYouOrderPageWirelessFlow thankYouOrderPageWirelessFlow = reviewAndSubmitOrderPageWirelessFlow.ClickSubmitOrder(); // commented to prevent burning data
            //Assert.assertNotNull(thankYouOrderPageWirelessFlow);
            //Assert.assertTrue(thankYouOrderPageWirelessFlow.ThankyouPageIsDisplayed());
        }
    }

    // ***************************************************************************************************
    // * NAME :   HR_Desktop_NCBuyAccessory
    // * AUTHOR : Gavril Grigorean
    // ***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void HR_Desktop_NC_NewAccessory(@Optional("") String browser) 
    {
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
        {   
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_NC")));

            ShopLandingPage shopLandingPage = new ShopLandingPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(shopLandingPage.IsShopLandingPageDisplayed());
            
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");
            
            Assert.assertTrue(shopLandingPage.SelectCategoryLink("Accessories"));
            
            AccessoryCategoryPage accessoryCategoryPage = new AccessoryCategoryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(accessoryCategoryPage.AccessoryPageExistance());

            AccessoriesListPage accessoriesListPage = accessoryCategoryPage.SelectAccessoryCategory("Cases");
            Assert.assertTrue(accessoriesListPage.AccessoriesListPageIsDisplayed());

            AccessoriesDetailsPage accessoriesDetailsPage = accessoriesListPage.ClickViewAccessory(Dictionary.get("ACCESSORY_NAME"));
            Assert.assertNotNull(accessoriesDetailsPage);
            Assert.assertTrue(accessoriesDetailsPage.AccessoriesDetailsPageIsDisplayed());

            accessoriesListPage = accessoriesDetailsPage.AddToCartOnAccessoriesDetailsPage();
            Assert.assertTrue(accessoriesListPage.AccessoriesListPageIsDisplayed());
            Assert.assertTrue(accessoriesListPage.ClickContinueToNextStep());

            CartSummaryPage cartSummaryPage = new CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.CartSummaryPageIsDisplayed());
            Assert.assertTrue(cartSummaryPage.ClickCheckoutButton());  

            LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(loginPage.LoginPageIsDisplayed());
            Assert.assertTrue(loginPage.clickContinueButton());

            PersonalInfoPage personalInfoPage  = new PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
            //Assert.assertTrue(personalInfoPage.PersonalInfo());
            Assert.assertTrue(personalInfoPage.EnterFirstName());
            Assert.assertTrue(personalInfoPage.EnterLastName());
            Assert.assertTrue(personalInfoPage.EnterPrimaryNumber());
            Assert.assertTrue(personalInfoPage.EnterEmail());
            Assert.assertTrue(personalInfoPage.EnterBillingAddress1());
            Assert.assertTrue(personalInfoPage.EnterBillingCity());
            Assert.assertTrue(personalInfoPage.SelectBillingState());
            Assert.assertTrue(personalInfoPage.EnterBillingZIP());            
            Assert.assertTrue(personalInfoPage.ContinueToNextStepToVerifyAddress());
            Assert.assertTrue(personalInfoPage.ValidateBillAddrVerifiedSuccessfully());
            //Assert.assertTrue(personalInfoPage.CreditInfo());
            Assert.assertTrue(personalInfoPage.EnterCreditCardDetails());
            Assert.assertTrue(personalInfoPage.ClickContinueOnPersonalInfoPage());

            ReviewAndSubmitOrderPage reviewAndSubmitOrderPage = new ReviewAndSubmitOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewAndSubmitOrderPage.IsPageDisplayed());

            ThankYouOrderPage thankYouOrderPage = reviewAndSubmitOrderPage.ClickSubmitOrder();
            Assert.assertNotNull(thankYouOrderPage);
            Assert.assertTrue(thankYouOrderPage.ThankyouPageIsDisplayed());         

        }
    }

    // ***************************************************************************************************
    // * NAME :   HR_Desktop_NC_NewWirelessLineBOPIS
    // * AUTHOR : Gavril Grigorean
    // ***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void HR_Desktop_NC_NewWirelessLineBOPIS(){
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
        {
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_NC")));

            ShopLandingPage ShopLandingPage = new ShopLandingPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(ShopLandingPage.IsShopLandingPageDisplayed());
            
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");
            
            Assert.assertTrue(ShopLandingPage.SelectCategoryLink("Smartphones"));
            
            DeviceListPageSmartphone DeviceListPageSmartphone = new DeviceListPageSmartphone(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(DeviceListPageSmartphone.DeviceListPageIsDisplayed());

            DeviceDetailsPage DeviceDetailsPage = DeviceListPageSmartphone.ViewButtonClickForDevice(Dictionary.get("DEVICE"));
            Assert.assertNotNull(DeviceDetailsPage);
            Assert.assertTrue(DeviceDetailsPage.BFOIsDeviceDetailsPageDisplayed());
            Assert.assertTrue(DeviceDetailsPage.BFOClickOnContinuebutton());

            IntentModal IntentModal = new IntentModal(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(IntentModal.IntentPageIsDisplayed());
            Assert.assertTrue(IntentModal.SelectIntentAsNewCustomer());

            BuyFlowDeviceConfigurator buyFlowDeviceConfigurator = new BuyFlowDeviceConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(buyFlowDeviceConfigurator.DeviceConfiguratorPageExist());

            //Assert.assertTrue(buyFlowDeviceConfigurator.SelectCommitmentTerm(Dictionary.get("CONTRACT_LENGTH")));
            Assert.assertTrue(buyFlowDeviceConfigurator.SelectInsuranceOptions(Dictionary.get("REQUIRED_SERVICE")));

            ZipModalForSli zipModalForSli  = buyFlowDeviceConfigurator.ClickCheckInStoreAvailability();
            Assert.assertNotNull(zipModalForSli);

            SliResultsPage sliResultsPage=zipModalForSli.EnterValidZipOnSliModal();
            Assert.assertNotNull(sliResultsPage);
            Assert.assertTrue(sliResultsPage.VerifyResultsExist());
            Assert.assertTrue(sliResultsPage.SelectStore(Dictionary.get("STORE")));

            ZipCodeModal ZipCodeModal = new ZipCodeModal(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(ZipCodeModal.IsZipCodeModalDisplayed());
            Assert.assertTrue(ZipCodeModal.EnterZipInZipCodeModal());

            BuyFlowPlanConfigurator byFlowPlanConfigurator = new BuyFlowPlanConfigurator(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(byFlowPlanConfigurator.PlanConfiguratorPageDisplayed());            
            //Assert.assertTrue(byFlowPlanConfigurator.SelectDataPlanFromVisibleRadioButton(Dictionary.get("PLAN")));

            CartSummaryPage CartSummaryPage = byFlowPlanConfigurator.ClickContinue();
            Assert.assertNotNull(CartSummaryPage);
            Assert.assertTrue(CartSummaryPage.CartSummaryPageIsDisplayed());
            Assert.assertTrue(CartSummaryPage.ClickCheckoutButton());           

            PersonalInfoPage PersonalInfoPage  = new PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PersonalInfoPage.IsPersonalInfoPageDisplayed());
            //Assert.assertTrue(PersonalInfoPage.PersonalInfo());
            Assert.assertTrue(PersonalInfoPage.EnterFirstName());
            Assert.assertTrue(PersonalInfoPage.EnterLastName());
            Assert.assertTrue(PersonalInfoPage.EnterPrimaryNumber());
            Assert.assertTrue(PersonalInfoPage.EnterEmail());
            Assert.assertTrue(PersonalInfoPage.EnterBillingAddress1());
            Assert.assertTrue(PersonalInfoPage.EnterBillingCity());
            Assert.assertTrue(PersonalInfoPage.SelectBillingState());
            Assert.assertTrue(PersonalInfoPage.EnterBillingZIP());            
            Assert.assertTrue(PersonalInfoPage.ContinueToNextStepToVerifyAddress());
            Assert.assertTrue(PersonalInfoPage.ValidateBillAddrVerifiedSuccessfully());
            Assert.assertTrue(PersonalInfoPage.CreditInfo());
            Assert.assertTrue(PersonalInfoPage.EnterCreditCardDetails());
            Assert.assertTrue(PersonalInfoPage.ClickContinueOnPersonalInfoPage());

            PhoneNumberDetailsPage PhoneNumberDetailsPage = new PhoneNumberDetailsPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(PhoneNumberDetailsPage.PhoneNumberDetailsPageIsDisplayed());
            Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaCode(1,Dictionary.get("AREA_CODE")));
            //Assert.assertTrue(PhoneNumberDetailsPage.SelectPreferredAreaName(1,Dictionary.get("SERVICE_CITY")));

            ReviewAndSubmitOrderPage ReviewAndSubmitOrderPage = PhoneNumberDetailsPage.SelectContinuePhoneNumberDetailsPage();
            Assert.assertNotNull(ReviewAndSubmitOrderPage);
            Assert.assertTrue(ReviewAndSubmitOrderPage.IsPageDisplayed());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForElectronicConsent());
            Assert.assertTrue(ReviewAndSubmitOrderPage.selectCheckBoxForRetailInstallmentAgreement());
            Assert.assertTrue(ReviewAndSubmitOrderPage.SelectCheckBoxForWirelessCustomerAgreement());

            ThankYouOrderPage thankYouOrderPage = ReviewAndSubmitOrderPage.ClickSubmitOrder();
            Assert.assertNotNull(thankYouOrderPage);
            Assert.assertTrue(thankYouOrderPage.ThankyouPageIsDisplayed());

        }
    }



    //***************************************************************************************************
    //* NAME                : HR_Desktop_EC_OlamHandoff
    //* AUTHOR              : Gavril Grigorean
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void HR_Desktop_EC_OlamHandoff(@Optional("") String browser) 
    {
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))

        {              
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HROCK_OLAM")));

            LoginFromOlamHardrock loginFromOlamHardrock = new LoginFromOlamHardrock(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(loginFromOlamHardrock.IsLoginFromOlamHardrockPageDisplayed());
            
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");
            
            Assert.assertTrue(loginFromOlamHardrock.EnterUserID());
            Assert.assertTrue(loginFromOlamHardrock.EnterPassword());
            Assert.assertTrue(loginFromOlamHardrock.ClickLoginButton());

            AccountOverviewPage accountOverviewPage = loginFromOlamHardrock.HandlePagesTillAccountOverview();
            Assert.assertNotNull(accountOverviewPage);
            //Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());

            DeviceListPageSmartphone deviceListPage = accountOverviewPage.clickIWantToShopAttAddADevice();        
            Assert.assertTrue(deviceListPage.DeviceListPageIsDisplayed());

            Assert.assertTrue(objCommon.validateHostName(objCommon.getHostName(Environment.get("HROCK_EC"))));

        }
    }


    //***************************************************************************************************
    //* NAME                : HR_Mobile_EC_DSSHandoff
    //* AUTHOR              : Gavril Grigorean
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void HR_Mobile_EC_DSSHandoff(){
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
        {

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_EC_DSS")));

            DSSLoginPage dssLoginPage = new DSSLoginPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(dssLoginPage.VerifyDSSLoginPageExist());
            
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");
            
            Assert.assertTrue(dssLoginPage.SetUserId(Dictionary.get("USER_ID")));
            Assert.assertTrue(dssLoginPage.SetPassword(Dictionary.get("PASSWORD")));
            Assert.assertTrue(dssLoginPage.ClickOnLogin());

            MyAttOverviewPage myAttOverviewPage = new MyAttOverviewPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(myAttOverviewPage.CheckMyAttOverviewPageExistance());
            Assert.assertTrue(myAttOverviewPage.ClickOnCheckUpgradeEligiblity());

            UpdateYourDevicePage updateYourDevicePage = new UpdateYourDevicePage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(updateYourDevicePage.UpdateYourDevicePageIsDisplayed());

            Assert.assertTrue(objCommon.validateHostName(objCommon.getHostName(Environment.get("MHR_EC"))));

        }
    }


    //***************************************************************************************************
    //* NAME                : HR_Mobile_NC_NewAccessory
    //* AUTHOR              : Gavril Grigorean
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void HR_Mobile_NC_NewAccessory(@Optional("") String browser) 
    {
        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
        {               
            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_NC")));

            ShopMobileLandingPage shopMobileLandingPage = new ShopMobileLandingPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(shopMobileLandingPage.ShopMobileLandingPageIsDisplayed());
            
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            AccessoryOnlyPage accessoryOnlyPage = shopMobileLandingPage.ClickAccessoriesLink();
            Assert.assertTrue(accessoryOnlyPage.VerifyAccessoryOnlyPageExist());           
            Assert.assertTrue(accessoryOnlyPage.selectAccessoryCategory(Dictionary.get("CATEGORY")));
            
            AccessoryListPage accessoryListPage = new AccessoryListPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(accessoryListPage.VerifyAccessoryListPageExist());
                        
            AccessoryDetailsPage accessoryDetailsPage= accessoryListPage.SelectAccessory(Dictionary.get("ACCESSORY_NAME"));
            Assert.assertTrue(accessoryDetailsPage.AccessoryDetailsPageIsDisplayed());
            Assert.assertTrue(accessoryDetailsPage.clickAddToCart());
            Assert.assertTrue(accessoryDetailsPage.AccessoryDetailsPageIsDisplayed());
            Assert.assertTrue(accessoryDetailsPage.ClickContinueToCart());
            
            com.att.mhr.CartSummaryPage cartSummaryPage = new com.att.mhr.CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.CartSummaryIsDisplayed());
            Assert.assertTrue(cartSummaryPage.ClickCheckOut());

            ShopMobileLoginPage shopMobileLoginPage=new ShopMobileLoginPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertNotNull(shopMobileLoginPage);
            Assert.assertTrue(shopMobileLoginPage.VerifyShopMobileLoginPageExist());
            Assert.assertTrue(shopMobileLoginPage.clickCheckOutAsGuest());
            
            com.att.mhr.PersonalInfoPage personalInfoPage = new com.att.mhr.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
            Assert.assertTrue(personalInfoPage.SetContactInformation());
            Assert.assertTrue(personalInfoPage.setShipToAddressFields(Dictionary.get("BILLING_ADDRESS_LINE1"),
                    Dictionary.get("BILLING_ADDRESS_LINE2"),Dictionary.get("BILLING_CITY"),
                    Dictionary.get("BILLING_STATE"),Dictionary.get("BILLING_ZIPCODE")));
            Assert.assertTrue(personalInfoPage.ClickOnContinue());

            PaymentInfoPage paymentInfoPage=new PaymentInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(paymentInfoPage.IsPaymentInfoPageDisplayed());
            Assert.assertTrue(paymentInfoPage.EnterPaymentInfo());
            Assert.assertTrue(paymentInfoPage.ClickOnContinueBtn());

            com.att.mhr.ReviewAndSubmitOrderPage reviewAndSubmitOrderPage = new com.att.mhr.ReviewAndSubmitOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewAndSubmitOrderPage.ReviewAndSubmitOrderPageIsDisplayed());
            Assert.assertTrue(reviewAndSubmitOrderPage.ClickContinueButton());

            com.att.mhr.ThankYouOrderPage thankYouOrderPage=new com.att.mhr.ThankYouOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(thankYouOrderPage.isThankyouPageIsDisplayed());   

        }
    }
    
    //***************************************************************************************************
    //* NAME                : HR_Mobile_NC_NewWirelessLine
    //* AUTHOR              : Gavril Grigorean
    //***************************************************************************************************
    @Test
    @Parameters({"browser"})
    public void HR_Mobile_NC_NewWirelessLine(@Optional("") String browser) {

        if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")) {   

            Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("MHR_NC")+"index.html"));

            ShopMobileLandingPage shopMobileLandingPage = new ShopMobileLandingPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(shopMobileLandingPage.ShopMobileLandingPageIsDisplayed());
            
            objCommon.fCommonGetCookieValue("SHOPSESSIONID");

            DeviceCatagoryPage deviceCatagoryPage = shopMobileLandingPage.ClickPhonesTabletsDevicesLink();
            Assert.assertNotNull(deviceCatagoryPage);
            Assert.assertTrue(deviceCatagoryPage.VerifyDeviceCategoryPageExist());

            DeviceListPage deviceListPage = deviceCatagoryPage.SelectCategory(Dictionary.get("DEVICE_CATEGORY"));
            Assert.assertNotNull(deviceListPage);
            Assert.assertTrue(deviceListPage.IsDeviceListPageDisplayed());

            com.att.mhr.DeviceDetailsPage deviceDetailsPage = deviceListPage.SelectDeviceBySku(Dictionary.get("DEVICE_NAME"));
            Assert.assertNotNull(deviceDetailsPage);
            Assert.assertTrue(deviceDetailsPage.IsDeviceDetailsPageDisplayed());
            Assert.assertTrue(deviceDetailsPage.ClickOnAddToCart());

            GetStartedPage getStarted=new GetStartedPage(driver,driverType,Dictionary,Environment,Reporter);
            Assert.assertNotNull(getStarted);
            Assert.assertTrue(getStarted.CheckGetStartedPageIsDisplayed());
            Assert.assertTrue(getStarted.ClickOrderNewService());
            Assert.assertTrue(getStarted.ClickContinue());

            LocalizationPage localizationPage = new LocalizationPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(localizationPage.CheckLocalizationModalIsDisplayed());
            Assert.assertTrue(localizationPage.EnterZipCode(Dictionary.get("ZIP_CODE")));

            CommitmentTermPage commitmentTermPage = localizationPage.ClickSubmit();
            Assert.assertNotNull(commitmentTermPage);
            Assert.assertTrue(commitmentTermPage.CheckCommitmentTermPageIsDisplayed());
            Assert.assertTrue(commitmentTermPage.SelectCommitmentTerm("AT&T 24"));
            Assert.assertTrue(commitmentTermPage.clickAddToCart());

            ProtectionServicesPage protectionServicesPage = new ProtectionServicesPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertNotNull(protectionServicesPage);
            Assert.assertTrue(protectionServicesPage.CheckProtectYourDevicePageIsDisplayed());
            Assert.assertTrue(protectionServicesPage.SelectProtectionServices(""));
            Assert.assertTrue(protectionServicesPage.ClickSelectButton());

            MobileShareValuePlansListPage mobileShareValuePlansListPage = new MobileShareValuePlansListPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(mobileShareValuePlansListPage.CheckMobileShareValuePlanListPageIsDisplayed());
            Assert.assertTrue(mobileShareValuePlansListPage.ClickExpandLinkToSelectPlan("15GB"));

            MobileShareHubPage mobileShareHubPage = mobileShareValuePlansListPage.ClickOnAddToCart("ANY");
            Assert.assertNotNull(mobileShareHubPage);
            Assert.assertTrue(mobileShareHubPage.CheckMobileShareHubPageIsDisplayed());
            Assert.assertTrue(mobileShareHubPage.ClickOnContinueToCartCTA());

            RecommendedAccessoriesPage recommendedAccessoriesPage = new RecommendedAccessoriesPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(recommendedAccessoriesPage.VerifyRecommendedAccessoriesPage());
            Assert.assertTrue(recommendedAccessoriesPage.ClickOnContinueButton());

            com.att.mhr.CartSummaryPage cartSummaryPage = new com.att.mhr.CartSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(cartSummaryPage.CartSummaryIsDisplayed()); 
            Assert.assertTrue(cartSummaryPage.ClickCheckOut());

            com.att.mhr.PersonalInfoPage personalInfoPage = new com.att.mhr.PersonalInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
            Assert.assertTrue(personalInfoPage.SetContactInformation());
            Assert.assertTrue(personalInfoPage.SetBillToAddress());
            Assert.assertTrue(personalInfoPage.SetCreditInformation());
            Assert.assertTrue(personalInfoPage.ClickOnContinue());

            PaymentInfoPage paymentInfoPage=new PaymentInfoPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(paymentInfoPage.IsPaymentInfoPageDisplayed());
            Assert.assertTrue(paymentInfoPage.EnterPaymentInfo());
            Assert.assertTrue(paymentInfoPage.ClickOnContinueBtn());

            com.att.mhr.PhoneNumberDetailsPage phoneNumberDetailsPage = new com.att.mhr.PhoneNumberDetailsPage(driver, driverType, Dictionary,Environment,Reporter); 
            Assert.assertNotNull(phoneNumberDetailsPage);
            Assert.assertTrue(phoneNumberDetailsPage.VerifyPoneNumberDetailsPageExist());
            Assert.assertTrue(phoneNumberDetailsPage.SelectNewNumberAllCheckBoxes());
            Assert.assertTrue(phoneNumberDetailsPage.ClickContinueButton());

            SelectYourNumberPage selectYourNumberPage=new SelectYourNumberPage(driver, driverType, Dictionary,Environment,Reporter);
            Assert.assertTrue(selectYourNumberPage.SelectYourNumberPageIsDisplayed());
            Assert.assertTrue(selectYourNumberPage.SelectAreaCode("1",Dictionary.get("AREA_CODE")));
            Assert.assertTrue(selectYourNumberPage.SelectServiceCity("1",Dictionary.get("SERVICE_CITY")));
            Assert.assertTrue(selectYourNumberPage.ClickContinueCTA());         

            com.att.mhr.ReviewAndSubmitOrderPage reviewAndSubmitOrderPage = new com.att.mhr.ReviewAndSubmitOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(reviewAndSubmitOrderPage.ReviewAndSubmitOrderPageIsDisplayed());
            Assert.assertTrue(reviewAndSubmitOrderPage.ClickContinueButton());

            NextTermPage nextTermPage = new NextTermPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(nextTermPage.NextTermPageIsDisplayed());
            Assert.assertTrue(nextTermPage.SelectAllCheckBoxes());
            Assert.assertTrue(nextTermPage.ClickContinue());

            com.att.mhr.ThankYouOrderPage thankYouOrderPage=new com.att.mhr.ThankYouOrderPage(driver, driverType, Dictionary, Environment, Reporter);
            Assert.assertTrue(thankYouOrderPage.isThankyouPageIsDisplayed());         
        }
    }


    @Parameters({ "browser" })
    @AfterMethod
    public void afterMethod(Method method, ITestResult result, @Optional("") String browser) throws Exception {

        driverType = browser;
        try {
            if (Dictionary.get("SKIP_" + driverType).equals("") && !Dictionary.get("SKIP_" + driverType).equals("null")) {
                System.out.println("AfterMethod begin - " + method.getName());
                // String status;

                if (result.getStatus() == ITestResult.SUCCESS) {
                    Dictionary.put("RESULT_" + driverType, "P");
                } else if (result.getStatus() == ITestResult.FAILURE) {
                    Dictionary.put("RESULT_" + driverType, "F");
                    // In case of failure adding a line because sometimes tests die in between and are marked as passed but they are actually failed
                    if(CommonFunctions.exceptionToString(result.getThrowable())!=null){
                        Reporter.fnWriteToHtmlOutput("Testng afterMethod hook", "FAILED", "Exception: " + CommonFunctions.exceptionToString(result.getThrowable()), "Fail");
                    }
                } else {
                    Dictionary.put("RESULT_" + driverType, "N");
                    System.out.println("Invalid Status");
                }
                System.out.println("Result - " + driverType + " - " + result.toString());

                // Close Summary Report
                Reporter.fnCloseHtmlReport();

                System.out.println("AfterMethod end - " + driverType);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception " + Dictionary.get("TEST_NAME_" + driverType) + driverType + ": " + e.toString());
        }

        // Quit Driver
        if (driver != null) {
            try {
                driver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    @AfterClass
    public void afterClass() {
        try {
            Reporter.fnCloseTestSummary();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception " + Dictionary.get("TEST_NAME_" + driverType) + driverType + ": " + e.toString());
        }
    }
}
