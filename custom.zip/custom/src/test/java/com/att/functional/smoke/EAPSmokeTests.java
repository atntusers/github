package com.att.functional.smoke;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.att.framework.CommonFunctions;
import com.att.framework.Driver;
import com.att.framework.Reporting;
import com.att.framework.Driver.HashMapNew;
import com.att.hrock.AccessoriesDetailsPage;
import com.att.hrock.AccessoriesListPage;
import com.att.hrock.BYOP;
import com.att.hrock.BuyFlowDeviceConfigurator;
import com.att.hrock.BuyFlowPlanConfigurator;
import com.att.hrock.CartSummaryPage;
import com.att.hrock.CurrentPlanDetailBarkModal;
import com.att.hrock.DataPlansListPage;
import com.att.hrock.DeviceDetailsPage;
import com.att.hrock.EasyActivateCreditInfoPage;
import com.att.hrock.EasyActivateCustomerInformationPage;
import com.att.hrock.EasyActivateDeviceInformationPage;
import com.att.hrock.EasyActivateLoginPage;
import com.att.hrock.EasyActivatePagePlanSelectionPage;
import com.att.hrock.EasyActivatePlanSummaryPage;
import com.att.hrock.EasyActivateSelectAccountType;
import com.att.hrock.GlobalNavMenu;
import com.att.hrock.IntentModal;
import com.att.hrock.PersonalInfoPage;
import com.att.hrock.ServicesListPage;
import com.att.hrock.ShopLandingPage;
import com.att.hrock.ZipCodeModal;

public class EAPSmokeTests {

	HashMap<String, String> Environment = new HashMap<String, String>();
    HashMapNew Dictionary = new HashMapNew();
    Reporting Reporter;

    // Instances
    Driver d;
    WebDriver driver;
    String driverType;
    CommonFunctions objCommon;
    boolean bSkip;
    int TestCounter = 0;
    ITestResult result;
    String env;
    String runOnEnv;
    String browser;

    @Parameters({ "browser", "envcode" })
    @BeforeClass
    public void beforeClass(@Optional("") String browser, @Optional("") String runOnEnv) {
        try {
            driverType = browser;
            Environment.put("CLASS_NAME", this.getClass().getSimpleName());
            d = new Driver(driverType, Dictionary, Environment);
            env = System.getProperty("envName");
            if (env == null) {
                env = runOnEnv;
            }
            Assert.assertNotNull(env);
            // Add env global environments
            Environment.put("ENV_CODE", env);

            // Get the skiped cells
            d.getSkipedCells();
            d.fetchEnvironmentDetails(); // from Environment.xlsx
            if(System.getProperty("dataCenter")!=null){
                Environment.put("SET_COOKIES_REGION",System.getProperty("dataCenter"));
            }
            d.createExecutionFolders(Environment.get("CLASS_NAME"));
            Reporter = new Reporting(driver, driverType, Dictionary, Environment);
            Reporter.fnCreateSummaryReport();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Parameters({ "browser" })
    @BeforeMethod
    public void beforeMethod(@Optional("") String browser, Method method) {
        try {
            String action = method.getName();
            d.fGetDataForTest(action, Environment.get("CLASS_NAME"));
            if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
                driver = d.fGetWebDriver(driverType, action);
                d.fGuiHandleAuth(browser);
                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                Reporter.driver = driver;
                Reporter.fnCreateHtmlReport(Dictionary.get("TEST_NAME"));
                objCommon = new CommonFunctions(driver, driverType, Environment, Reporter);
                Dictionary.put("TEST_NAME_" + driverType, Dictionary.get("TEST_NAME"));

                // position the window so it doesn't cover the screen margins
                driver.manage().window().setPosition(new Point(32,32));
                // if it is running from Ant and in Chrome browser set the window to a huge size 
                // so the screenshot contains the whole page, not only the visible part
                if(System.getProperty("envName") != null && driverType.toLowerCase().contains("chrome")) {
                    driver.manage().window().setSize(new Dimension(1100, 10000)); // adjust to a huge window height
                } else {
                    driver.manage().window().setSize(new Dimension(1100, 800)); // just adjust the width so there is no horizontal scroll
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
	
    
    
    //***************************************************************************************************
  	//*	NAME		    	:	HR Wireless REG_Func_NC_Desktop_Happy Flow with mobile share
  	//*Action				:	HRWirelessREGFuncNCDesktopHappyFlowWithMobileShare
  	//*	AUTHOR				: 	Amit Kumar
    //HRWirelessREGFuncNCDesktopHappyFlowWithMobileShare

  	//************************************************************************	

  	@Test
  	@Parameters({"browser"})
  	public void HR_Desktop_NC_Wireless_REG_WithMobileShare(@Optional("") String browser) 
  	{
  		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
  		{				
  			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HR_OFFER_BARK")+Dictionary.get("IMEI")+"&csn="+Dictionary.get("CSN")));	
  			
  			EasyActivateSelectAccountType easyActivateSelectAccountType = new EasyActivateSelectAccountType(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertTrue(easyActivateSelectAccountType.SelectAccountTypePageExist());
  			Assert.assertTrue(easyActivateSelectAccountType.SelectPostPaidMontlyPlan());

  			EasyActivateLoginPage easyActivateLoginPage = easyActivateSelectAccountType.ClickOnContinueOnAccountTypePage();
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(easyActivateLoginPage);
  			Assert.assertTrue(easyActivateLoginPage.EasyActivateLoginPageIsDisplayed());
  			//Assert.assertTrue(easyActivateLoginPage.LoginPageValidations("BARK"));
  			Assert.assertTrue(easyActivateLoginPage.ClickGetStartButtonForNewCustomer());

  			EasyActivatePagePlanSelectionPage easyActivatePagePlanSelectionPage = new EasyActivatePagePlanSelectionPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(easyActivatePagePlanSelectionPage);
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.EasyActivatePlanSelectionPageDisplayed());
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.SelectPlanType(Dictionary.get("PLAN_TYPE")));
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.SelectPlanValue(Dictionary.get("PLAN_VALUE")));
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.ClickContinueBtn());	
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			

  			EasyActivateCustomerInformationPage easyActivateCustomerInformationPage = new EasyActivateCustomerInformationPage(driver, driverType, Dictionary, Environment, Reporter);
  			Assert.assertNotNull(easyActivateCustomerInformationPage);
  			Assert.assertTrue(easyActivateCustomerInformationPage.EasyActivateCustomerinfoPageDisplayed());
  			Assert.assertTrue(easyActivateCustomerInformationPage.EnterFirstNameLastName());
  			Assert.assertTrue(easyActivateCustomerInformationPage.SelectBillingState());
  			Assert.assertTrue(easyActivateCustomerInformationPage.EnterContactAndBillingInfo());
  			Assert.assertTrue(easyActivateCustomerInformationPage.FetchTxtPlanAtCustomerInfoPage());

  			EasyActivateCreditInfoPage easyActivateCreditInfoPage = easyActivateCustomerInformationPage.EasyActivateCustomerInfoPageClickContinue();
  			Assert.assertNotNull(easyActivateCreditInfoPage);
  			Assert.assertTrue(easyActivateCreditInfoPage.EasyActivateCreditInfoPageDisplayed());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectMonth());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectDay());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectYear());
  			Assert.assertTrue(easyActivateCreditInfoPage.EnterSSN());
  			Assert.assertTrue(easyActivateCreditInfoPage.EasyActivateClickRegisterLater());
  			Assert.assertTrue(easyActivateCreditInfoPage.TxtPlanValidatonAtCreditInfoPage());

  			EasyActivatePlanSummaryPage EasyActivatePlanSummaryPage = easyActivateCreditInfoPage.EasyActivateCustomerInfoPageClickContinue();
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(EasyActivatePlanSummaryPage);
  			Assert.assertNotNull(EasyActivatePlanSummaryPage.PlanSummaryPageExist());
  			Assert.assertTrue(EasyActivatePlanSummaryPage.ClickAggrement());
  			Assert.assertNotNull(EasyActivatePlanSummaryPage.PlanSummaryPageExist());  			
  		}
  	} 
    
    //***************************************************************************************************
  	//*	NAME		    	:	HR Wireless REG_Func_NC_Desktop_Happy Flow with mobile share
  	//*Action				:	HRWirelessREGFuncECDesktopHappyFlowWithMobileShare
  	//*	AUTHOR				: 	Amit Kumar
  	//************************************************************************	

  	@Test
  	@Parameters({"browser"})
  	public void HR_Desktop_EC_Wireless_REG_WithMobileShare(@Optional("") String browser) 
  	{
  		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
  		{				
  			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HR_OFFER_BARK")+Dictionary.get("IMEI")+"&csn="+Dictionary.get("CSN")));	
  			
  			EasyActivateSelectAccountType easyActivateSelectAccountType = new EasyActivateSelectAccountType(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertTrue(easyActivateSelectAccountType.SelectAccountTypePageExist());
  			Assert.assertTrue(easyActivateSelectAccountType.SelectPostPaidMontlyPlan());
  			  			
  			EasyActivateLoginPage easyActivateLoginPage = easyActivateSelectAccountType.ClickOnContinueOnAccountTypePage();
  			Assert.assertNotNull(easyActivateLoginPage);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(easyActivateLoginPage);
  			Assert.assertTrue(easyActivateLoginPage.EasyActivateLoginPageIsDisplayed());
  			//Assert.assertTrue(easyActivateLoginPage.LoginPageValidations("BARK"));
  			Assert.assertTrue(easyActivateLoginPage.EnterUserID());
  			Assert.assertTrue(easyActivateLoginPage.EnterUserPass());
  			Assert.assertTrue(easyActivateLoginPage.ClickLoginForExistanceCustomer());
  			
  			EasyActivatePagePlanSelectionPage easyActivatePagePlanSelectionPage = new EasyActivatePagePlanSelectionPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.EasyActivatePlanSelectionPageDisplayed());
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.ClickContinueBtn());	
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			 			  			
  			EasyActivatePlanSummaryPage easyActivatePlanSummaryPage=new EasyActivatePlanSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
  			Assert.assertNotNull(easyActivatePlanSummaryPage);
  			Assert.assertTrue(easyActivatePlanSummaryPage.PlanSummaryPageExist());  	
  			} 

  	
  	}
  	
  	//***************************************************************************************************
  	//*	NAME		    	:	HR Wireless REG_Func_NC_Desktop_Happy Flow with mobile share
  	//*Action				:	HRWirelessREGFuncNCDesktopHappyFlowWithMobileShare
  	//HR_Desktop_EC_Wireless_REG_WithMobileShare
  	//HRWirelessREGFuncNCDesktopHappyFlowWithMobileShareAndroid
  	//*	AUTHOR				: 	Amit Kumar
  	//************************************************************************	

  		@Test
  	  	@Parameters({"browser"})
  	public void HR_Desktop_NC_Wireless_REG_WithMobileShareAndroid(@Optional("") String browser) 
  	{
  		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
  		{		  			
  			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HR_OFFER_ANDROID")+Dictionary.get("IMEI")+"&iccid="+Dictionary.get("CSN")));
  			
  			EasyActivateLoginPage easyActivateLoginPage = new EasyActivateLoginPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(easyActivateLoginPage);
  			Assert.assertTrue(easyActivateLoginPage.EasyActivateLoginPageIsDisplayed());
  			//Assert.assertTrue(easyActivateLoginPage.LoginPageValidations("BARK"));
  			Assert.assertTrue(easyActivateLoginPage.ClickGetStartButtonForNewCustomer());
  			
  			EasyActivatePagePlanSelectionPage easyActivatePagePlanSelectionPage = new EasyActivatePagePlanSelectionPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(easyActivatePagePlanSelectionPage);
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.EasyActivatePlanSelectionPageDisplayed());
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.ClickContinueBtn());	
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			EasyActivateCustomerInformationPage easyActivateCustomerInformationPage = new EasyActivateCustomerInformationPage(driver, driverType, Dictionary, Environment, Reporter);
  			Assert.assertTrue(easyActivateCustomerInformationPage.EasyActivateCustomerinfoDisplayed());
  			Assert.assertTrue(easyActivateCustomerInformationPage.EasyActivateBillingInfoDisplayed());  			
  			Assert.assertTrue(easyActivateCustomerInformationPage.EnterFirstNameLastName());
  			Assert.assertTrue(easyActivateCustomerInformationPage.SelectBillingState());
  			Assert.assertTrue(easyActivateCustomerInformationPage.EnterContactAndBillingInfo());
  			
  			EasyActivateCreditInfoPage easyActivateCreditInfoPage = easyActivateCustomerInformationPage.EasyActivateCustomerInfoPageClickContinue();
  			Assert.assertNotNull(easyActivateCreditInfoPage);
  			Assert.assertTrue(easyActivateCreditInfoPage.EasyActivateCreditInfoPageDisplayed());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectMonth());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectDay());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectYear());
  			Assert.assertTrue(easyActivateCreditInfoPage.EnterSSN());
  			Assert.assertTrue(easyActivateCreditInfoPage.EasyActivateClickRegisterLater());
  			  			
  			EasyActivatePlanSummaryPage easyActivatePlanSummaryPage=easyActivateCreditInfoPage.EasyActivateCustomerInfoPageClickContinue();
  			Assert.assertNotNull(easyActivatePlanSummaryPage);
  			Assert.assertTrue(easyActivatePlanSummaryPage.PlanSummaryPageExist());
  		}
  	} 
 
  	 //***************************************************************************************************
  	//*	NAME		    	:	HR Wireless REG_Func_NC_Desktop_Happy Flow with mobile share
  	//*Action				:	HRWirelessREGFuncNCDesktopHappyFlowWithMobileShare
  	//HR_Desktop_NC_Wireless_REG_WithMobileShareAndroid	
  	//*	AUTHOR				: 	Amit Kumar
  	//************************************************************************	

  	@Test
  	@Parameters({"browser"})
  	public void HR_Desktop_EC_Wireless_REG_WithMobileShareAndroid(@Optional("") String browser) 
  	{
  		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
  		{		  			
  			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HR_OFFER_ANDROID")+Dictionary.get("IMEI")+"&iccid="+Dictionary.get("CSN")));
  			
  			EasyActivateLoginPage easyActivateLoginPage = new EasyActivateLoginPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(easyActivateLoginPage);
  			Assert.assertTrue(easyActivateLoginPage.EasyActivateLoginPageIsDisplayed());
  			//Assert.assertTrue(easyActivateLoginPage.LoginPageValidations("BARK"));
  			Assert.assertTrue(easyActivateLoginPage.EnterUserID());
  			Assert.assertTrue(easyActivateLoginPage.EnterUserPass());
  			Assert.assertTrue(easyActivateLoginPage.ClickLoginForExistanceCustomer());
  			
  			EasyActivatePagePlanSelectionPage easyActivatePagePlanSelectionPage = new EasyActivatePagePlanSelectionPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.EasyActivatePlanSelectionPageDisplayed());
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.ClickContinueBtn());	
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			 			  			
  			EasyActivatePlanSummaryPage easyActivatePlanSummaryPage=new EasyActivatePlanSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
  			Assert.assertNotNull(easyActivatePlanSummaryPage);
  			Assert.assertTrue(easyActivatePlanSummaryPage.PlanSummaryPageExist());
  		}
  	} 	
  	
  	
  	
  	//3>
	//***************************************************************************************************
	//*    NAME                 	: COAMDesktopCartSummaryPageAppleiPad
	//* DESCRIPTION               : 05. US40681 - COAM - Desktop - Cart Summary Page -  Apple iPad
	//*    AUTHOR                  : Kaiqi Tang / fixed y Dina
  	//HR_Desktop_NC_Wireless_REG_WithMobileShareAndroid
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HR_Desktop_NC_COAM_OFF_Activation(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{      
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HR_COAM_OFF_DEVICE")));

			EasyActivateDeviceInformationPage easyActivateDeviceInformationPage=new EasyActivateDeviceInformationPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(easyActivateDeviceInformationPage.EasyActivateDeviceinfoPageDisplayed());
			Assert.assertTrue(easyActivateDeviceInformationPage.EnterIMEIinDiviceInformationPage());
			Assert.assertTrue(easyActivateDeviceInformationPage.EnterCSNinDiviceInformationPage());
			Assert.assertNotNull(easyActivateDeviceInformationPage.ClickContinueInDiviceInformationPage());
			
			EasyActivateLoginPage easyActivateLoginPage=new EasyActivateLoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(easyActivateLoginPage.EasyActivateLoginPageIsDisplayed());
			Assert.assertTrue(easyActivateLoginPage.ClickGetStartButtonForNewCustomer());
			
			EasyActivatePagePlanSelectionPage easyActivatePagePlanSelectionPage = new EasyActivatePagePlanSelectionPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertNotNull(easyActivatePagePlanSelectionPage);
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.EasyActivatePlanSelectionPageDisplayed());
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.ClickContinueBtn());	
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			EasyActivateCustomerInformationPage easyActivateCustomerInformationPage = new EasyActivateCustomerInformationPage(driver, driverType, Dictionary, Environment, Reporter);
  			Assert.assertNotNull(easyActivateCustomerInformationPage);
  			Assert.assertTrue(easyActivateCustomerInformationPage.EasyActivateCustomerinfoPageDisplayed());
  			Assert.assertTrue(easyActivateCustomerInformationPage.EnterFirstNameLastName());
  			Assert.assertTrue(easyActivateCustomerInformationPage.SelectBillingState());
  			Assert.assertTrue(easyActivateCustomerInformationPage.EnterContactAndBillingInfo());
  			Assert.assertTrue(easyActivateCustomerInformationPage.ClickContinue());
  			
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			EasyActivateCreditInfoPage easyActivateCreditInfoPage = new EasyActivateCreditInfoPage(driver, driverType, Dictionary, Environment, Reporter);
  			Assert.assertNotNull(easyActivateCreditInfoPage);
  			
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			Assert.assertTrue(easyActivateCreditInfoPage.EasyActivateCreditInfoPageDisplayed());
  			
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectMonth());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectDay());
  			Assert.assertTrue(easyActivateCreditInfoPage.SelectYear());
  			Assert.assertTrue(easyActivateCreditInfoPage.EnterSSN());
  			Assert.assertTrue(easyActivateCreditInfoPage.EasyActivateClickRegisterLater());
  			
  			
  			EasyActivatePlanSummaryPage easyActivatePlanSummaryPage=easyActivateCreditInfoPage.EasyActivateCustomerInfoPageClickContinue();
  			Assert.assertNotNull(easyActivatePlanSummaryPage);
  			Assert.assertTrue(easyActivatePlanSummaryPage.PlanSummaryPageExist());
  				
		}
	}     	
	

	//***************************************************************************************************
  	//*	NAME		    	:	HR Wireless REG_Func_NC_Desktop_Happy Flow with mobile share
  	//*Action				:	HRWirelessREGFuncNCDesktopHappyFlowWithMobileShare
//	HR_Desktop_NC_COAM_OFF_Activation

  	//*	AUTHOR				: 	Amit Kumar
  	//************************************************************************	

  	@Test
  	@Parameters({"browser"})
  	public void HR_Desktop_EC_COAM_OFF_Activation(@Optional("") String browser) 
  	{
  		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
  		{				
  			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("HR_COAM_OFF_DEVICE")));

			EasyActivateDeviceInformationPage easyActivateDeviceInformationPage=new EasyActivateDeviceInformationPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(easyActivateDeviceInformationPage.EasyActivateDeviceinfoPageDisplayed());
			Assert.assertTrue(easyActivateDeviceInformationPage.EnterIMEIinDiviceInformationPage());
			Assert.assertTrue(easyActivateDeviceInformationPage.EnterCSNinDiviceInformationPage());
			Assert.assertNotNull(easyActivateDeviceInformationPage.ClickContinueInDiviceInformationPage());
			
			EasyActivateLoginPage easyActivateLoginPage=new EasyActivateLoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(easyActivateLoginPage.EasyActivateLoginPageIsDisplayed());
			Assert.assertTrue(easyActivateLoginPage.EnterUserID());
  			Assert.assertTrue(easyActivateLoginPage.EnterUserPass());
  			Assert.assertTrue(easyActivateLoginPage.ClickLoginForExistanceCustomer());
  			
			
  			EasyActivatePagePlanSelectionPage easyActivatePagePlanSelectionPage = new EasyActivatePagePlanSelectionPage(driver, driverType, Dictionary, Environment, Reporter);
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.EasyActivatePlanSelectionPageDisplayed());
  			Assert.assertTrue(easyActivatePagePlanSelectionPage.ClickContinueBtn());	
  			objCommon.fCommonValidateDynamicPageDisplayed("", "");
  			
  			 			  			
  			EasyActivatePlanSummaryPage easyActivatePlanSummaryPage=new EasyActivatePlanSummaryPage(driver, driverType, Dictionary, Environment, Reporter);
  			Assert.assertNotNull(easyActivatePlanSummaryPage);
  			Assert.assertTrue(easyActivatePlanSummaryPage.PlanSummaryPageExist());  	
  			} 

  	
  	}
	
	
    @Parameters({ "browser" })
    @AfterMethod
    public void afterMethod(Method method, ITestResult result, @Optional("") String browser) throws Exception {

        driverType = browser;
        try {
            if (Dictionary.get("SKIP_" + driverType).equals("") && !Dictionary.get("SKIP_" + driverType).equals("null")) {
                System.out.println("AfterMethod begin - " + method.getName());
                // String status;

                if (result.getStatus() == ITestResult.SUCCESS) {
                    Dictionary.put("RESULT_" + driverType, "P");
                } else if (result.getStatus() == ITestResult.FAILURE) {
                    Dictionary.put("RESULT_" + driverType, "F");
                    // In case of failure adding a line because sometimes tests die in between and are marked as passed but they are actually failed
                    if(CommonFunctions.exceptionToString(result.getThrowable())!=null){
                        Reporter.fnWriteToHtmlOutput("Testng afterMethod hook", "FAILED", "Exception: " + CommonFunctions.exceptionToString(result.getThrowable()), "Fail");
                    }
                } else {
                    Dictionary.put("RESULT_" + driverType, "N");
                    System.out.println("Invalid Status");
                }
                System.out.println("Result - " + driverType + " - " + result.toString());

                // Close Summary Report
                Reporter.fnCloseHtmlReport();

                System.out.println("AfterMethod end - " + driverType);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception " + Dictionary.get("TEST_NAME_" + driverType) + driverType + ": " + e.toString());
        }

        // Quit Driver
        if (driver != null) {
            try {
                driver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    @AfterClass
    public void afterClass() {
        try {
            Reporter.fnCloseTestSummary();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception " + Dictionary.get("TEST_NAME_" + driverType) + driverType + ": " + e.toString());
        }
    }	
	
	
	
}
