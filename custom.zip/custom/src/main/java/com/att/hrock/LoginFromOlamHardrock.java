package com.att.hrock;

import java.util.HashMap;

import com.att.framework.CommonFunctions;
import com.att.framework.Reporting;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginFromOlamHardrock {

    private Reporting Reporter;
    private WebDriver driver;
    private String driverType;
    private HashMap<String, String> Dictionary;
    private HashMap<String, String> Environment;
    private CommonFunctions CommonFunctions;

    public LoginFromOlamHardrock(WebDriver GDriver,String DT,HashMap<String, String> GDictionary, HashMap<String, String> GEnvironment,Reporting GReporter)
    {
        Reporter = GReporter;
        driver = GDriver;
        driverType = DT;
        Dictionary = GDictionary;
        Environment = GEnvironment;
        CommonFunctions = new CommonFunctions(driver,driverType,Environment,Reporter);
    }


    //objects
    private String webEdtUserID = "id:=userID";
    private String webEdtPassword = "id:=password";
    private String btnLogin = "id:=LoginButton";
    private String lnkContinueLink = "xpath:=//*[@id='continueLink']";
    private String webElmtPageTitle = "cssselector:=.page-title h1";
    private String lnkContinueToMyAccountLink = "xpath:=//*[@id='remindMe']";
    private String lnkRejectPaperlessBilling = "xpath:=//*[@id='rejectPBO']";
    private String webElmntIsYourProfile = "xpath:=//h1[contains(text(),'Is your myAT&T')]";
    private String webEdtPrimaryEmailAddress = "id:=primaryEmailAddress";
    private String webEdtConfirmPrimaryEmailAddress = "id:=confirmPrimaryEmailAddress";
    private String drpdwnSecurityQuestion1 = "id:=question1";
    private String webEdtSecurityAnswer1 = "id:=answer1";
    private String drpdwnSecurityQuestion2 = "id:=question2";
    private String webEdtSecurityAnswer2 = "id:=answer2";
    private String btnContinueToAccount = "id:=bt_continue";
    private String btnRemindMeLater = "xpath:=//*[@class='btnLt']/a[2]"; 	
    private String lnkNoThanks = "xpath:=//a[contains(.,'No, Thanks')] | //a[contains(.,'No Thanks')] | //a[contains(.,'No, thanks')]";
    private String lnkUverse = "id:=Uverse";
    private String wbElmtWelcomeBack= "xpath:=//h2[contains(.,'Welcome')]";
    
    //New myAT&T login Page
    private String webEdtUserID_new = "id:=userName";
    private String btnLogin_new = "id:=loginButton";

    //methods
    //*******************************************************************************************************************
    //*	NAME		    	: EnterUserID
    //*	DESCRIPTION	    	: enter user id in the edit box
    //*	CREATED RELEASE 	: 1406
    //*	LAST MODIFIED IN	: 
    //*	AUTHOR				: Dina Dodin
    //*	INPUT PARAMS		: 
    //*	RETURN VALUE		: boolean
    //* UPDATED ON 			: 01-Oct-2014
    //*********************************************************************************************************************
    public boolean EnterUserID()
    {
        JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
        jsExecutor.executeScript("document.getElementById('userID').value=''");
        if (CommonFunctions.fCommonSetValueEditBox(webEdtUserID, "webEdtUserID", Dictionary.get("USER_ID"), "Y","") == false){return false;}

        return true;
    }


    //*******************************************************************************************************************
    //*	NAME		    	: EnterPassword
    //*	DESCRIPTION	    	: enter password in the edit box
    //*	CREATED RELEASE 	: 1406
    //*	LAST MODIFIED IN	: 
    //*	AUTHOR				: Dina Dodin
    //*	INPUT PARAMS		: 
    //*	RETURN VALUE		: boolean
    //* UPDATED ON 			: 01-Oct-2014
    //*********************************************************************************************************************
    public boolean EnterPassword()
    {
        if (CommonFunctions.fCommonSetValueEditBox(webEdtPassword, "webEdtPassword", Dictionary.get("PASSWORD"), "","") == false){return false;}

        return true;
    }



    //*******************************************************************************************************************
    //*	NAME		    	: ClickLoginButton
    //*	DESCRIPTION	    	: click on login button
    //*	CREATED RELEASE 	: 1406
    //*	LAST MODIFIED IN	: 
    //*	AUTHOR				: Dina Dodin
    //*	INPUT PARAMS		: 
    //*	RETURN VALUE		: boolean
    //* UPDATED ON 			: 01-Oct-2014
    //*********************************************************************************************************************
    public boolean ClickLoginButton()
    {
        if (CommonFunctions.fCommonClick(btnLogin, "btnLogin") == false){
            return false;
        }
        return true;
    }



    //*******************************************************************************************************************
    //*	NAME		    	: HandlePagesTillAccountOverview
    //*	DESCRIPTION	    	: handle the pages in order to continue with flow till account overview page
    //*	CREATED RELEASE 	: 1406
    //*	LAST MODIFIED IN	: 04 Dec 2015 Gavril Grigorean
    //*	AUTHOR				: Dina Dodin
    //*	INPUT PARAMS		: 
    //*	RETURN VALUE		: AccountOverviewPage object
    //* UPDATED ON 			: 01-Oct-2014
    //*********************************************************************************************************************
    public AccountOverviewPage HandlePagesTillAccountOverview()
    {

        String wbElmtWelcomeBackAltered= wbElmtWelcomeBack.split(":=")[1];//"//h2[contains(.,'Welcome')]";
        String lnkContinueLinkAltered = lnkContinueLink.split(":=")[1]; // //*[@id='continueLink']";
        String lnkNoThanksAltered = lnkNoThanks.split(":=")[1]; //"//a[contains(.,'No, Thanks')] | //a[contains(.,'No Thanks')]";
        String webElmntIsYourProfileAltered = webElmntIsYourProfile.split(":=")[1]; //"//h1[contains(text(),'Is your myAT&T')]";
        String lnkContinueToMyAccountLinkAltered =lnkContinueToMyAccountLink.split(":=")[1]; // "//*[@id='remindMe']";
        String lnkRejectPaperlessBillingAltered =lnkRejectPaperlessBilling.split(":=")[1]; // "//*[@id='rejectPBO']";
        
        
        
        String controlElement="xpath:="+ wbElmtWelcomeBackAltered + " | " + lnkContinueLinkAltered + " | " + lnkNoThanksAltered + " | " + webElmntIsYourProfileAltered + 
                " | " + lnkContinueToMyAccountLinkAltered + " | " + lnkRejectPaperlessBillingAltered;

        CommonFunctions.fCommonValidateDynamicPageDisplayed(controlElement, "");

        while (true){
            
            WebElement webControl = CommonFunctions.fCommonGetObject(controlElement,"Control element");
            if(webControl==null){
                Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Check if control element is displayed","Control element is null", "Fail");
                return null;
            }

            if (webControl.getText().contains("Welcome")){
                Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Check if AccountOverviewPage is displayed ","AccountOverviewPage is displayed", "Pass");
                return new AccountOverviewPage(driver, driverType, Dictionary, Environment, Reporter);
            }

            if(webControl.getAttribute("id").equals("continueLink")){
                if (CommonFunctions.fCommonClick(lnkContinueLink, "lnkContinueLink") == false){
                    Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Click on Continue link","Click on Continue link failed", "Fail");
                    return null;
                } else{
                    CommonFunctions.fCommonValidateDynamicPageDisplayed(controlElement, "");
                    continue;
                }
            }

            if(webControl.getText().contains("Is your myAT&T")){
                if (CommonFunctions.fCommonSetValueEditBox(webEdtPrimaryEmailAddress, webEdtPrimaryEmailAddress, "test@att.com", "Y", "Y") == false){
                    Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Set primary email address","Primary email address not set successful", "Fail");
                    return null;
                }
                if (CommonFunctions.fCommonSetValueEditBox(webEdtConfirmPrimaryEmailAddress, webEdtConfirmPrimaryEmailAddress, "test@att.com", "Y", "Y") == false){
                    Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Confirm primary email address","Confrm for primary email address not set successful", "Fail");
                    return null;
                }
                if (CommonFunctions.fCommonCheckObjectExistance(drpdwnSecurityQuestion1)){
                    if (CommonFunctions.fCommonSelectionOptionFromList(drpdwnSecurityQuestion1, drpdwnSecurityQuestion1, "What is your favorite film?", "sendKeys") == false) {
                        Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Select security question 1","Selection for security question 1 failed", "Fail");
                        return null;
                    }
                    if (CommonFunctions.fCommonSetValueEditBox(webEdtSecurityAnswer1, webEdtSecurityAnswer1, "ABCD", "Y", "Y") == false){
                        Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Set security question 1","Set question 1 failed", "Fail");
                        return null;
                    }
                    if (CommonFunctions.fCommonSelectionOptionFromList(drpdwnSecurityQuestion2, drpdwnSecurityQuestion2, "What country would you like to visit?", "sendKeys") == false){
                        Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Select security question 2","Selection for security question 2 failed", "Fail");
                        return null;
                    }
                    if (CommonFunctions.fCommonSetValueEditBox(webEdtSecurityAnswer2, webEdtSecurityAnswer2, "ABCD", "Y", "Y") == false){
                        Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Set security question 2","Set question 2 failed", "Fail");
                        return null;
                    }
                }

                if (CommonFunctions.fCommonClick(btnContinueToAccount, btnContinueToAccount) == false){
                    Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Click on Continue To Accoount","Click on Continue To Account failed", "Fail");
                    return null;
                }else{
                    CommonFunctions.fCommonValidateDynamicPageDisplayed(controlElement, "");
                    continue;
                }
            }


            if (webControl.getText().contains("No, Thanks") || webControl.getText().contains("No Thanks") || webControl.getText().contains("No, thanks") ){
                if(CommonFunctions.fCommonJavascriptClick(lnkNoThanks, "Link No Thanks beside Remind Me Later") == false){
                    Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Click on No Thanks","Click on No Thanks failed", "Fail");
                    return null;
                }else{
                    CommonFunctions.fCommonValidateDynamicPageDisplayed(controlElement, "");
                    continue; 
                }
            }

            if(webControl.getAttribute("id").equals("rejectPBO")){
                if (CommonFunctions.fCommonClick(lnkRejectPaperlessBilling, "lnkRejectPaperlessBilling") == false){
                    Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Click on Reject Paperless Billing","Click on Reject Paperless Billing failed", "Fail");
                    return null;
                }else{
                    CommonFunctions.fCommonValidateDynamicPageDisplayed(controlElement, "");
                    continue;
                }
            }
            
            
            if(webControl.getAttribute("id").equals("remindMe")){
                if (CommonFunctions.fCommonClick(lnkContinueToMyAccountLink, "lnkContinueToMyAccountLink") == false){
                    Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - HandlePagesTillAccountOverview","Click on Continue to my account","Click on Continut to my account failed", "Fail");
                    return null;
                }else{
                    CommonFunctions.fCommonValidateDynamicPageDisplayed(controlElement, "");
                    continue;
                }
            }
        }

    }

    //*******************************************************************************************************************
    //*	NAME		    	: IsLoginFromOlamHardrockPageDisplayed
    //*	DESCRIPTION	    	: Is Login From Olam Hardrock Page Displayed
    //*	CREATED RELEASE 	: 1406
    //*	LAST MODIFIED IN	: 
    //*	AUTHOR				: Kapish Kumar
    //*	INPUT PARAMS		: 
    //*	RETURN VALUE		: Boolean object
    //* UPDATED ON 			: 29-Oct-14
    //*********************************************************************************************************************
    public boolean IsLoginFromOlamHardrockPageDisplayed(){
        if (CommonFunctions.fCommonValidateDynamicPageDisplayed(webElmtPageTitle, "Log in to manage your account") == null){
            Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - IsLoginFromOlamHardrockPageDisplayed","OLAM Hardrock Login Page should be displayed","OLAM Hardrock Login Page is not displayed", "Fail");
            return false;
        }
        Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - IsLoginFromOlamHardrockPageDisplayed","OLAM Hardrock Login Page should be displayed","OLAM Hardrock Login Page is displayed", "Pass");
        return true;
    }

    //*******************************************************************************************************************
    //* NAME                : clickUverse
    //* DESCRIPTION         : Click Uverse
    //* CREATED RELEASE     : 1506
    //* LAST MODIFIED IN    : 
    //* AUTHOR              : Gavril Grigorean
    //* INPUT PARAMS        : 
    //* RETURN VALUE        : Boolean object
    //* UPDATED ON          : 06-July-15
    //*********************************************************************************************************************
    public boolean clickUverse(){
        if (CommonFunctions.fCommonClick(lnkUverse, "Uverse") == false){
            Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - clickUverse","Click Uverse","Uverse was not clicked successful", "Fail");
            return false;
        }
        Reporter.fnWriteToHtmlOutput("LoginFromOlamHardrock - clickUverse","Click Uverse","Uverse was clicked successful", "Pass");
        return true;
    }

    //*******************************************************************************************************************
    //* NAME                : ClickLoginButton_new
    //* DESCRIPTION         : click on login button for new MyAT&T login page
    //* CREATED RELEASE     : 1406
    //* LAST MODIFIED IN    : 
    //* AUTHOR              : Kaiqi Tang
    //* INPUT PARAMS        : 
    //* RETURN VALUE        : boolean
    //* UPDATED ON          : 22-Feb-2016
    //*********************************************************************************************************************
    public boolean ClickLoginButton_new()
    {
        if (CommonFunctions.fCommonClick(btnLogin_new, "btnLogin") == false){
            return false;
        }
        return true;
    }
    
    //*******************************************************************************************************************
    //* NAME                : EnterUserID
    //* DESCRIPTION         : enter user id in the edit box
    //* CREATED RELEASE     : 1406
    //* LAST MODIFIED IN    : 
    //* AUTHOR              : Dina Dodin
    //* INPUT PARAMS        : 
    //* RETURN VALUE        : boolean
    //* UPDATED ON          : 01-Oct-2014
    //*********************************************************************************************************************
    public boolean EnterUserID_new()
    {
        JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
        jsExecutor.executeScript("document.getElementById('userName').value=''");
        if (CommonFunctions.fCommonSetValueEditBox(webEdtUserID_new, "webEdtUserID_new", Dictionary.get("USER_ID"), "Y","") == false){return false;}

        return true;
    }

}
